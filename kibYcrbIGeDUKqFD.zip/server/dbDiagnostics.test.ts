import { afterEach, describe, expect, it, vi } from "vitest";
import mysql from "mysql2/promise";
import {
  diagnoseDatabaseConnection,
  extractRejectedHost,
  inspectDatabaseUrl,
  sanitizeDatabaseError,
} from "./dbDiagnostics";

vi.mock("mysql2/promise", () => ({ default: { createConnection: vi.fn() } }));

const originalEnabled = process.env.DB_DIAGNOSTICS_ENABLED;
const originalDatabaseUrl = process.env.DATABASE_URL;

afterEach(() => {
  vi.restoreAllMocks();
  if (originalEnabled === undefined) delete process.env.DB_DIAGNOSTICS_ENABLED;
  else process.env.DB_DIAGNOSTICS_ENABLED = originalEnabled;
  if (originalDatabaseUrl === undefined) delete process.env.DATABASE_URL;
  else process.env.DATABASE_URL = originalDatabaseUrl;
});

describe("diagnóstico MySQL sanitizado", () => {
  it("classifica erros conhecidos sem retornar mensagem ou credenciais", () => {
    const result = sanitizeDatabaseError({
      code: "ER_ACCESS_DENIED_ERROR",
      errno: 1045,
      sqlState: "28000",
      message: "Access denied for mysql://usuario:senha@host/banco",
    });
    expect(result).toEqual({
      category: "access_denied",
      code: "ER_ACCESS_DENIED_ERROR",
      errno: 1045,
      sqlState: "28000",
    });
    expect(JSON.stringify(result)).not.toContain("senha");
    expect(JSON.stringify(result)).not.toContain("usuario");
  });

  it("inspeciona a URL sem retornar usuário, banco ou senha", () => {
    const result = inspectDatabaseUrl(
      "mysql://usuario:Senha123456@localhost:3306/banco_comparemais",
    );
    expect(result).toMatchObject({
      parseable: true,
      protocol: "mysql",
      host: "localhost",
      port: 3306,
      passwordLength: 11,
      hasWhitespace: false,
    });
    const serialized = JSON.stringify(result);
    expect(serialized).not.toContain("usuario");
    expect(serialized).not.toContain("Senha123456");
    expect(serialized).not.toContain("banco_comparemais");
  });

  it("detecta espaços externos e senha codificada", () => {
    const result = inspectDatabaseUrl(" mysql://usuario:S%40nh%40@localhost:3306/banco\n");
    expect(result.passwordLength).toBe(5);
    expect(result.hasWhitespace).toBe(true);
  });

  it("extrai apenas o host rejeitado", () => {
    expect(
      extractRejectedHost({
        message: "Access denied for user 'usuario'@'10.0.0.5' (using password: YES)",
      }),
    ).toBe("10.0.0.5");
  });

  it("permanece desativado por padrão e não tenta conectar", async () => {
    delete process.env.DB_DIAGNOSTICS_ENABLED;
    process.env.DATABASE_URL = "mysql://usuario:senha@localhost/banco";
    await expect(diagnoseDatabaseConnection()).resolves.toMatchObject({
      enabled: false,
      configured: true,
      ok: false,
      category: "disabled",
      code: null,
      errno: null,
      sqlState: null,
    });
  });

  it("informa configuração ausente sem expor detalhes", async () => {
    process.env.DB_DIAGNOSTICS_ENABLED = "true";
    delete process.env.DATABASE_URL;
    await expect(diagnoseDatabaseConnection()).resolves.toMatchObject({
      enabled: true,
      configured: false,
      ok: false,
      category: "not_configured",
    });
  });

  it("não registra nem retorna credenciais quando a conexão falha", async () => {
    process.env.DB_DIAGNOSTICS_ENABLED = "true";
    process.env.DATABASE_URL = "mysql://usuario:senha-supersecreta@localhost/banco";
    vi.mocked(mysql.createConnection).mockRejectedValue({
      code: "ER_ACCESS_DENIED_ERROR",
      errno: 1045,
      sqlState: "28000",
      message: "Access denied for user 'usuario'@'10.0.0.5' (using password: YES)",
    });
    const warn = vi.spyOn(console, "warn").mockImplementation(() => undefined);
    const error = vi.spyOn(console, "error").mockImplementation(() => undefined);

    const result = await diagnoseDatabaseConnection();
    const serialized = JSON.stringify(result);
    expect(result).toMatchObject({
      enabled: true,
      configured: true,
      ok: false,
      category: "access_denied",
      code: "ER_ACCESS_DENIED_ERROR",
      errno: 1045,
      sqlState: "28000",
      rejectedHost: "10.0.0.5",
    });
    expect(serialized).not.toContain("usuario");
    expect(serialized).not.toContain("senha-supersecreta");
    expect(warn).not.toHaveBeenCalled();
    expect(error).not.toHaveBeenCalled();
  });
});
