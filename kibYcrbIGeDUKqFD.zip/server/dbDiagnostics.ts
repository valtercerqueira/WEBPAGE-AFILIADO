import { createHash } from "node:crypto";
import mysql from "mysql2/promise";

export type DatabaseDiagnosticCategory =
  | "connected"
  | "disabled"
  | "not_configured"
  | "access_denied"
  | "database_not_found"
  | "host_not_allowed"
  | "network_refused"
  | "network_timeout"
  | "dns_not_found"
  | "unknown";

export type DatabaseConfigurationDiagnostic = {
  parseable: boolean;
  protocol: string | null;
  host: string | null;
  port: number | null;
  usernameHash: string | null;
  databaseHash: string | null;
  passwordLength: number | null;
  hasWhitespace: boolean;
};

export type DatabaseDiagnostic = {
  enabled: boolean;
  configured: boolean;
  ok: boolean;
  category: DatabaseDiagnosticCategory;
  code: string | null;
  errno: number | null;
  sqlState: string | null;
  configuration: DatabaseConfigurationDiagnostic | null;
  rejectedHost: string | null;
};

type MysqlErrorShape = {
  code?: unknown;
  errno?: unknown;
  sqlState?: unknown;
  message?: unknown;
};

const CATEGORY_BY_CODE: Record<string, DatabaseDiagnosticCategory> = {
  ER_ACCESS_DENIED_ERROR: "access_denied",
  ER_BAD_DB_ERROR: "database_not_found",
  ER_HOST_NOT_PRIVILEGED: "host_not_allowed",
  ECONNREFUSED: "network_refused",
  ETIMEDOUT: "network_timeout",
  ENOTFOUND: "dns_not_found",
};

const fingerprint = (value: string) =>
  createHash("sha256").update(value).digest("hex").slice(0, 12);

export function sanitizeDatabaseError(
  error: unknown,
): Pick<DatabaseDiagnostic, "category" | "code" | "errno" | "sqlState"> {
  const source = error && typeof error === "object" ? (error as MysqlErrorShape) : {};
  const code = typeof source.code === "string" ? source.code.slice(0, 80) : null;
  const errno = typeof source.errno === "number" && Number.isFinite(source.errno) ? source.errno : null;
  const sqlState = typeof source.sqlState === "string" ? source.sqlState.slice(0, 20) : null;

  return {
    category: code ? (CATEGORY_BY_CODE[code] ?? "unknown") : "unknown",
    code,
    errno,
    sqlState,
  };
}

export function inspectDatabaseUrl(databaseUrl: string): DatabaseConfigurationDiagnostic {
  const hasWhitespace = databaseUrl !== databaseUrl.trim() || /[\r\n\t]/.test(databaseUrl);

  try {
    const parsed = new URL(databaseUrl.trim());
    const username = decodeURIComponent(parsed.username);
    const password = decodeURIComponent(parsed.password);
    const database = decodeURIComponent(parsed.pathname.replace(/^\//, ""));

    return {
      parseable: true,
      protocol: parsed.protocol.replace(/:$/, ""),
      host: parsed.hostname || null,
      port: parsed.port ? Number(parsed.port) : 3306,
      usernameHash: username ? fingerprint(username) : null,
      databaseHash: database ? fingerprint(database) : null,
      passwordLength: password.length,
      hasWhitespace,
    };
  } catch {
    return {
      parseable: false,
      protocol: null,
      host: null,
      port: null,
      usernameHash: null,
      databaseHash: null,
      passwordLength: null,
      hasWhitespace,
    };
  }
}

export function extractRejectedHost(error: unknown): string | null {
  const source = error && typeof error === "object" ? (error as MysqlErrorShape) : {};
  if (typeof source.message !== "string") return null;
  return source.message.match(/@'([^']+)'/)?.[1]?.slice(0, 255) ?? null;
}

export async function diagnoseDatabaseConnection(): Promise<DatabaseDiagnostic> {
  const enabled = process.env.DB_DIAGNOSTICS_ENABLED === "true";
  const databaseUrl = process.env.DATABASE_URL;
  const configuration = databaseUrl ? inspectDatabaseUrl(databaseUrl) : null;

  if (!enabled) {
    return {
      enabled: false,
      configured: Boolean(databaseUrl),
      ok: false,
      category: "disabled",
      code: null,
      errno: null,
      sqlState: null,
      configuration,
      rejectedHost: null,
    };
  }

  if (!databaseUrl) {
    return {
      enabled: true,
      configured: false,
      ok: false,
      category: "not_configured",
      code: null,
      errno: null,
      sqlState: null,
      configuration: null,
      rejectedHost: null,
    };
  }

  let connection: mysql.Connection | null = null;
  try {
    connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
    await connection.query("SELECT 1 AS ok");
    return {
      enabled: true,
      configured: true,
      ok: true,
      category: "connected",
      code: "OK",
      errno: null,
      sqlState: null,
      configuration,
      rejectedHost: null,
    };
  } catch (error) {
    return {
      enabled: true,
      configured: true,
      ok: false,
      ...sanitizeDatabaseError(error),
      configuration,
      rejectedHost: extractRejectedHost(error),
    };
  } finally {
    await connection?.end().catch(() => undefined);
  }
}
