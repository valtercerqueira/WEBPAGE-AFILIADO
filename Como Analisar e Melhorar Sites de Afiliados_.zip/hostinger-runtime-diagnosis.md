# Diagnóstico de produção na Hostinger

Data: 16 de julho de 2026.

## Ambiente verificado

- Aplicação: `https://goldenrod-mallard-360640.hostingersite.com/`
- Artigo com erro: `https://goldenrod-mallard-360640.hostingersite.com/melhor-cafeteira`
- Sitemap com erro: `https://goldenrod-mallard-360640.hostingersite.com/sitemap.xml`
- Logs: `https://hpanel.hostinger.com/websites/goldenrod-mallard-360640.hostingersite.com/runtime-logs`
- Banco: `u363137879_comparemais`, acessado pelo phpMyAdmin da Hostinger em `auth-db848.hstgr.io`.

## Fatos observados após a importação

O phpMyAdmin confirmou importação concluída sem erros. A homepage responde, porém renderiza apenas o shell estático. O artigo `/melhor-cafeteira` retorna `Internal Server Error`. O `sitemap.xml` também falha. O `robots.txt` responde.

Os logs mostram falha de consulta Drizzle nas tabelas importadas:

```text
Failed query: select `id`, `name`, `slug`, `description`, `imageUrl`, `isFeatured`, `sortOrder`, `createdAt`, `updatedAt`
from `categories`
order by `categories`.`sortOrder` asc, `categories`.`name` asc
```

Também aparece:

```text
Failed query: select `slug`, `updatedAt`
from `articles`
where `articles`.`status` = ?
order by `articles`.`updatedAt` desc
params: published
```

O log ainda registra `OAUTH_SERVER_URL is not configured`, mas esse aviso é independente das consultas públicas que estão falhando.

## Configuração confirmada

- O phpMyAdmin mostra as sete tabelas importadas e as contagens esperadas: 5 categorias, 6 artigos, 13 FAQs e 13 produtos.
- A Hostinger salvou `NODE_ENV`, `DATABASE_URL`, `CANONICAL_ORIGIN` e `JWT_SECRET`.
- A `DATABASE_URL` aponta para o banco e usuário corretos, usando `localhost` e a porta `3306`.
- O painel da Web App ainda exibe **Banco de dados → Conecte um banco de dados → Conectar**, indicando que o assistente oficial da aplicação não foi concluído.

## Referências oficiais adicionais

- [Hostinger — Connecting a Hostinger MySQL Database to a Node.js Application](https://www.hostinger.com/support/connecting-a-hostinger-mysql-database-to-a-node-js-application/): confirma `localhost`, porta `3306`, uso de `DATABASE_URL` e reinício da aplicação após alterações.
- [Hostinger — How to deploy a Node.js website](https://www.hostinger.com/support/how-to-deploy-a-nodejs-website-in-hostinger/): documenta o **Database Connect Wizard** disponível no painel da aplicação.
