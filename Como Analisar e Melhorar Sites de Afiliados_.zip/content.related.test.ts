import { describe, expect, it } from "vitest";

import { prioritizeRelatedArticles, RELATED_ARTICLES_LIMIT } from "./content";

describe("artigos relacionados", () => {
  it("limita a recomendação interna a seis artigos publicados", () => {
    expect(RELATED_ARTICLES_LIMIT).toBe(6);
  });

  it("prioriza a mesma categoria e preenche o restante com fallback", () => {
    const candidates = [
      { id: 1, categoryId: 2 },
      { id: 2, categoryId: 1 },
      { id: 3, categoryId: 2 },
      { id: 4, categoryId: 1 },
      { id: 5, categoryId: 3 },
      { id: 6, categoryId: 4 },
      { id: 7, categoryId: 5 },
    ];

    const result = prioritizeRelatedArticles(candidates, 1);

    expect(result.map(item => item.id)).toEqual([2, 4, 1, 3, 5, 6]);
    expect(result).toHaveLength(6);
  });
});
