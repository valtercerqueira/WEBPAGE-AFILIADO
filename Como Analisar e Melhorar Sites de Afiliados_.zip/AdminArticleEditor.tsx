import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Loader2, Plus, Save, Sparkles, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

type ProductDraft = { name: string; tagline: string; imageUrl: string; features: string[]; estimatedPrice: string | null; priceNote: string; badge: string | null; position: number; amazonUrl: string | null; mercadoLivreUrl: string | null };
type FaqDraft = { question: string; answer: string; position: number };
type ArticleDraft = { id?: number; categoryId: number; title: string; slug: string; excerpt: string; content: string; coverImageUrl: string; authorName: string; status: "draft" | "published"; isFeatured: boolean; seoTitle: string; seoDescription: string; quickSummary: string | null; quickPros: string[]; quickCons: string[]; quickSummaryModel: string | null; quickSummaryGeneratedAt: number | null; products: ProductDraft[]; faqs: FaqDraft[] };

const emptyProduct = (position: number): ProductDraft => ({ name: "", tagline: "", imageUrl: "", features: [""], estimatedPrice: null, priceNote: "Preço estimado; confirme na loja", badge: null, position, amazonUrl: null, mercadoLivreUrl: null });
const emptyFaq = (position: number): FaqDraft => ({ question: "", answer: "", position });
const emptyArticle: ArticleDraft = { categoryId: 0, title: "", slug: "", excerpt: "", content: "", coverImageUrl: "", authorName: "Equipe Compare Mais", status: "draft", isFeatured: false, seoTitle: "", seoDescription: "", quickSummary: null, quickPros: [], quickCons: [], quickSummaryModel: null, quickSummaryGeneratedAt: null, products: [emptyProduct(0)], faqs: [emptyFaq(0)] };

export default function AdminArticleEditor({ params }: { params: { id: string } }) {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const numericId = params.id === "novo" ? null : Number(params.id);
  const categories = trpc.content.categories.useQuery();
  const article = trpc.admin.article.useQuery({ id: numericId || 1 }, { enabled: Boolean(numericId) && user?.role === "admin" });
  const [draft, setDraft] = useState<ArticleDraft>(emptyArticle);
  const utils = trpc.useUtils();
  const save = trpc.admin.saveArticle.useMutation({
    onSuccess: async result => {
      await Promise.all([utils.admin.articles.invalidate(), utils.admin.overview.invalidate(), utils.content.home.invalidate()]);
      toast.success("Artigo salvo com sucesso.");
      navigate(`/admin/artigo/${result.id}`);
    },
    onError: error => toast.error(error.message),
  });
  const generateQuickSummary = trpc.admin.generateQuickSummary.useMutation({
    onSuccess: result => {
      setDraft(current => ({
        ...current,
        quickSummary: result.summary,
        quickPros: result.pros,
        quickCons: result.cons,
        quickSummaryModel: result.model,
        quickSummaryGeneratedAt: result.generatedAt,
      }));
      toast.success("Resumo gerado. Revise o texto antes de salvar.");
    },
    onError: error => toast.error(`Não foi possível gerar o resumo: ${error.message}`),
  });

  useEffect(() => {
    if (!numericId && draft.categoryId === 0 && categories.data?.[0]) setDraft(current => ({ ...current, categoryId: categories.data![0].id }));
  }, [categories.data, draft.categoryId, numericId]);

  useEffect(() => {
    if (!article.data) return;
    setDraft({
      id: article.data.id,
      categoryId: article.data.categoryId,
      title: article.data.title,
      slug: article.data.slug,
      excerpt: article.data.excerpt,
      content: article.data.content,
      coverImageUrl: article.data.coverImageUrl,
      authorName: article.data.authorName,
      status: article.data.status,
      isFeatured: article.data.isFeatured,
      seoTitle: article.data.seoTitle,
      seoDescription: article.data.seoDescription,
      quickSummary: article.data.quickSummary ?? null,
      quickPros: article.data.quickPros,
      quickCons: article.data.quickCons,
      quickSummaryModel: article.data.quickSummaryModel ?? null,
      quickSummaryGeneratedAt: article.data.quickSummaryGeneratedAt ?? null,
      products: article.data.products.map((product, index) => ({ ...product, features: product.features, estimatedPrice: product.estimatedPrice ? String(product.estimatedPrice) : null, badge: product.badge ?? null, amazonUrl: product.amazonUrl ?? null, mercadoLivreUrl: product.mercadoLivreUrl ?? null, position: index })),
      faqs: article.data.faqs.map((faq, index) => ({ question: faq.question, answer: faq.answer, position: index })),
    });
  }, [article.data]);

  const isLoading = Boolean(numericId) && article.isLoading;
  const titleLabel = useMemo(() => numericId ? "Editar artigo" : "Novo artigo", [numericId]);
  const setField = <K extends keyof ArticleDraft>(key: K, value: ArticleDraft[K]) => setDraft(current => ({ ...current, [key]: value }));
  const updateProduct = (index: number, patch: Partial<ProductDraft>) => setDraft(current => ({ ...current, products: current.products.map((product, itemIndex) => itemIndex === index ? { ...product, ...patch } : product) }));
  const updateFaq = (index: number, patch: Partial<FaqDraft>) => setDraft(current => ({ ...current, faqs: current.faqs.map((faq, itemIndex) => itemIndex === index ? { ...faq, ...patch } : faq) }));

  const requestQuickSummary = () => {
    if (draft.title.trim().length < 8 || draft.excerpt.trim().length < 40 || draft.content.trim().length < 80) {
      toast.error("Preencha título, resumo editorial e conteúdo principal antes de gerar com IA.");
      return;
    }
    const validProducts = draft.products
      .filter(product => product.name.trim().length >= 2 && product.tagline.trim().length >= 2)
      .map(product => ({
        name: product.name.trim(),
        tagline: product.tagline.trim(),
        features: product.features.map(feature => feature.trim()).filter(Boolean),
      }));
    generateQuickSummary.mutate({
      title: draft.title,
      excerpt: draft.excerpt,
      content: draft.content,
      products: validProducts,
    });
  };

  const submit = () => {
    const normalizedSlug = draft.slug
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
    const slug = normalizedSlug.startsWith("melhor-") ? normalizedSlug : `melhor-${normalizedSlug}`;
    const required = [draft.title, draft.excerpt, draft.content, draft.coverImageUrl, draft.authorName, draft.seoTitle, draft.seoDescription];
    if (!draft.categoryId || required.some(value => !value.trim())) {
      toast.error("Preencha todos os campos editoriais e de SEO obrigatórios.");
      return;
    }
    if (!/^melhor-[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) {
      toast.error("A URL deve seguir o padrão melhor-{produto}.");
      return;
    }
    if (draft.products.some(product => !product.name.trim() || !product.tagline.trim() || !product.imageUrl.trim() || product.features.every(feature => !feature.trim()))) {
      toast.error("Cada produto precisa de nome, resumo, imagem e ao menos uma característica.");
      return;
    }
    const invalidAffiliateUrl = draft.products.some(product => {
      try {
        const amazonHost = product.amazonUrl ? new URL(product.amazonUrl).hostname.toLowerCase() : null;
        const mercadoHost = product.mercadoLivreUrl ? new URL(product.mercadoLivreUrl).hostname.toLowerCase() : null;
        const amazonValid = !amazonHost || amazonHost === "amzn.to" || amazonHost === "amazon.com.br" || amazonHost.endsWith(".amazon.com.br");
        const mercadoValid = !mercadoHost || mercadoHost === "meli.la" || mercadoHost === "mercadolivre.com.br" || mercadoHost.endsWith(".mercadolivre.com.br");
        return !amazonValid || !mercadoValid;
      } catch {
        return true;
      }
    });
    if (invalidAffiliateUrl) {
      toast.error("Revise os links: aceite apenas URLs da Amazon Brasil, amzn.to, Mercado Livre Brasil ou meli.la.");
      return;
    }
    save.mutate({
      ...draft,
      slug,
      products: draft.products.map((product, index) => ({ ...product, position: index, estimatedPrice: product.estimatedPrice || null, badge: product.badge || null, amazonUrl: product.amazonUrl || null, mercadoLivreUrl: product.mercadoLivreUrl || null, features: product.features.filter(Boolean) })),
      faqs: draft.faqs.map((faq, index) => ({ ...faq, position: index })),
    });
  };

  if (user && user.role !== "admin") {
    return (
      <DashboardLayout>
        <div className="mx-auto max-w-2xl py-20 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary">Acesso restrito</p>
          <h1 className="mt-4 font-display text-4xl font-semibold">Esta conta não possui permissão editorial.</h1>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-6xl space-y-6 p-2 md:p-6">
        <header className="flex flex-col justify-between gap-4 border-b border-border/70 pb-6 md:flex-row md:items-end">
          <div>
            <button onClick={() => navigate("/admin")} className="mb-4 flex items-center gap-2 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="size-4" /> Voltar ao painel</button>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary">Editor de conteúdo</p>
            <h1 className="mt-2 font-display text-4xl font-semibold">{titleLabel}</h1>
          </div>
          <Button size="lg" onClick={submit} disabled={save.isPending || isLoading} className="gap-2">{save.isPending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} Salvar artigo</Button>
        </header>

        {isLoading ? <div className="py-20 text-center text-muted-foreground">Carregando conteúdo editorial...</div> : (
          <div className="space-y-6">
            <Card><CardHeader><CardTitle className="font-display text-2xl">Informações editoriais</CardTitle></CardHeader><CardContent className="grid gap-5 md:grid-cols-2">
              <div className="space-y-2 md:col-span-2"><Label>Título</Label><Input value={draft.title} onChange={event => setField("title", event.target.value)} placeholder="Ex.: Melhores cafeteiras para comprar" /></div>
              <div className="space-y-2"><Label>URL obrigatória</Label><Input value={draft.slug} onChange={event => setField("slug", event.target.value)} placeholder="melhor-cafeteira" /><p className="text-xs text-muted-foreground">O prefixo “melhor-” é aplicado automaticamente quando necessário.</p></div>
              <div className="space-y-2"><Label>Categoria</Label><Select value={draft.categoryId ? String(draft.categoryId) : undefined} onValueChange={value => setField("categoryId", Number(value))}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{categories.data?.map(category => <SelectItem key={category.id} value={String(category.id)}>{category.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="space-y-2"><Label>Autor</Label><Input value={draft.authorName} onChange={event => setField("authorName", event.target.value)} /></div>
              <div className="space-y-2"><Label>Imagem de capa (URL)</Label><Input value={draft.coverImageUrl} onChange={event => setField("coverImageUrl", event.target.value)} /></div>
              <div className="space-y-2 md:col-span-2"><Label>Resumo</Label><Textarea rows={3} value={draft.excerpt} onChange={event => setField("excerpt", event.target.value)} /></div>
              <div className="space-y-2 md:col-span-2"><Label>Conteúdo principal</Label><Textarea rows={12} value={draft.content} onChange={event => setField("content", event.target.value)} placeholder="Use linhas em branco para separar os parágrafos." /></div>
              <div className="space-y-2"><Label>Status</Label><Select value={draft.status} onValueChange={value => setField("status", value as ArticleDraft["status"])}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="draft">Rascunho</SelectItem><SelectItem value="published">Publicado</SelectItem></SelectContent></Select></div>
              <div className="flex items-center gap-3 pt-7"><Switch checked={draft.isFeatured} onCheckedChange={value => setField("isFeatured", value)} /><Label>Destacar na homepage</Label></div>
            </CardContent></Card>

            <Card className="overflow-hidden border-primary/20 bg-[linear-gradient(135deg,rgba(20,69,64,.06),rgba(197,159,71,.08))]">
              <CardHeader className="gap-4 md:flex-row md:items-start md:justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-primary"><Sparkles className="size-4" /> Assistente editorial</div>
                  <CardTitle className="mt-2 font-display text-2xl">Resumo rápido com IA</CardTitle>
                  <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">A IA usa apenas o conteúdo e os produtos deste formulário. Revise e edite o resultado antes de salvar ou publicar.</p>
                </div>
                <Button type="button" variant="outline" onClick={requestQuickSummary} disabled={generateQuickSummary.isPending} className="shrink-0 gap-2 bg-background">
                  {generateQuickSummary.isPending ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                  {draft.quickSummary ? "Gerar novamente" : "Gerar com IA"}
                </Button>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="space-y-2"><Label htmlFor="quick-summary">Síntese</Label><Textarea id="quick-summary" rows={4} value={draft.quickSummary ?? ""} onChange={event => setField("quickSummary", event.target.value || null)} placeholder="A síntese aparecerá no início do artigo." maxLength={600} /><p className="text-xs text-muted-foreground">{draft.quickSummary?.length ?? 0}/600 caracteres</p></div>
                <div className="grid gap-5 md:grid-cols-2">
                  <div className="space-y-2"><Label htmlFor="quick-pros">Principais prós</Label><Textarea id="quick-pros" rows={6} value={draft.quickPros.join("\n")} onChange={event => setField("quickPros", event.target.value.split("\n").map(item => item.trimStart()).slice(0, 6))} placeholder="Um ponto positivo por linha" /><p className="text-xs text-muted-foreground">Até 6 itens. Use afirmações verificáveis no artigo.</p></div>
                  <div className="space-y-2"><Label htmlFor="quick-cons">Principais contras</Label><Textarea id="quick-cons" rows={6} value={draft.quickCons.join("\n")} onChange={event => setField("quickCons", event.target.value.split("\n").map(item => item.trimStart()).slice(0, 6))} placeholder="Uma limitação por linha" /><p className="text-xs text-muted-foreground">Até 6 itens. Evite conclusões absolutas.</p></div>
                </div>
                {draft.quickSummaryGeneratedAt && <p className="text-xs text-muted-foreground">Última geração: {new Date(draft.quickSummaryGeneratedAt).toLocaleString("pt-BR")} · Modelo: {draft.quickSummaryModel ?? "não informado"}</p>}
              </CardContent>
            </Card>

            <Card><CardHeader><CardTitle className="font-display text-2xl">SEO e compartilhamento</CardTitle></CardHeader><CardContent className="space-y-5">
              <div className="space-y-2"><Label>Título SEO</Label><Input value={draft.seoTitle} onChange={event => setField("seoTitle", event.target.value)} /><p className="text-xs text-muted-foreground">{draft.seoTitle.length}/180 caracteres</p></div>
              <div className="space-y-2"><Label>Descrição SEO</Label><Textarea rows={3} value={draft.seoDescription} onChange={event => setField("seoDescription", event.target.value)} /><p className="text-xs text-muted-foreground">{draft.seoDescription.length}/320 caracteres</p></div>
            </CardContent></Card>

            <Card><CardHeader className="flex-row items-center justify-between"><CardTitle className="font-display text-2xl">Produtos e links afiliados</CardTitle><Button variant="outline" onClick={() => setDraft(current => ({ ...current, products: [...current.products, emptyProduct(current.products.length)] }))} className="gap-2"><Plus className="size-4" /> Produto</Button></CardHeader><CardContent className="space-y-6">
              {draft.products.map((product, index) => <div key={index} className="rounded-2xl border border-border/70 bg-muted/20 p-5"><div className="mb-5 flex items-center justify-between"><h3 className="font-semibold">Produto {index + 1}</h3><Button variant="ghost" size="icon" aria-label="Remover produto" onClick={() => setDraft(current => ({ ...current, products: current.products.filter((_, itemIndex) => itemIndex !== index) }))}><Trash2 className="size-4" /></Button></div><div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2"><Label>Nome</Label><Input value={product.name} onChange={event => updateProduct(index, { name: event.target.value })} /></div>
                <div className="space-y-2"><Label>Selo editorial</Label><Input value={product.badge ?? ""} onChange={event => updateProduct(index, { badge: event.target.value })} placeholder="Melhor escolha" /></div>
                <div className="space-y-2 md:col-span-2"><Label>Resumo curto</Label><Input value={product.tagline} onChange={event => updateProduct(index, { tagline: event.target.value })} /></div>
                <div className="space-y-2"><Label>Imagem (URL)</Label><Input value={product.imageUrl} onChange={event => updateProduct(index, { imageUrl: event.target.value })} /></div>
                <div className="space-y-2"><Label>Preço estimado</Label><Input value={product.estimatedPrice ?? ""} onChange={event => updateProduct(index, { estimatedPrice: event.target.value })} placeholder="499.90" /></div>
                <div className="space-y-2 md:col-span-2"><Label>Características (uma por linha)</Label><Textarea value={product.features.join("\n")} onChange={event => updateProduct(index, { features: event.target.value.split("\n") })} /></div>
                <div className="space-y-2"><Label>Link Amazon</Label><Input value={product.amazonUrl ?? ""} onChange={event => updateProduct(index, { amazonUrl: event.target.value })} placeholder="https://amazon.com.br/..." /></div>
                <div className="space-y-2"><Label>Link Mercado Livre</Label><Input value={product.mercadoLivreUrl ?? ""} onChange={event => updateProduct(index, { mercadoLivreUrl: event.target.value })} placeholder="https://mercadolivre.com.br/..." /></div>
              </div></div>)}
            </CardContent></Card>

            <Card><CardHeader className="flex-row items-center justify-between"><CardTitle className="font-display text-2xl">Perguntas frequentes</CardTitle><Button variant="outline" onClick={() => setDraft(current => ({ ...current, faqs: [...current.faqs, emptyFaq(current.faqs.length)] }))} className="gap-2"><Plus className="size-4" /> Pergunta</Button></CardHeader><CardContent className="space-y-5">
              {draft.faqs.map((faq, index) => <div key={index} className="grid gap-3 rounded-2xl border border-border/70 p-5"><div className="flex items-center justify-between"><Label>Pergunta {index + 1}</Label><Button variant="ghost" size="icon" aria-label="Remover pergunta" onClick={() => setDraft(current => ({ ...current, faqs: current.faqs.filter((_, itemIndex) => itemIndex !== index) }))}><Trash2 className="size-4" /></Button></div><Input value={faq.question} onChange={event => updateFaq(index, { question: event.target.value })} /><Textarea rows={4} value={faq.answer} onChange={event => updateFaq(index, { answer: event.target.value })} /></div>)}
            </CardContent></Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
