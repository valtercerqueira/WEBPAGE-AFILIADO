import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import ts from "typescript";

const projectRoot = path.resolve(import.meta.dirname, "..");
const seedPath = path.join(projectRoot, "server", "seed.ts");
const outputPath = path.join(projectRoot, "artifacts", "compare_mais_hostinger_import.sql");

function readLiteral(name) {
  const sourceText = fs.readFileSync(seedPath, "utf8");
  const sourceFile = ts.createSourceFile(seedPath, sourceText, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  let initializer;

  sourceFile.forEachChild(node => {
    if (!ts.isVariableStatement(node)) return;
    for (const declaration of node.declarationList.declarations) {
      if (ts.isIdentifier(declaration.name) && declaration.name.text === name) {
        initializer = declaration.initializer;
      }
    }
  });

  if (!initializer) throw new Error(`Literal ${name} não encontrado em ${seedPath}`);
  const printer = ts.createPrinter({ removeComments: true });
  const expression = printer.printNode(ts.EmitHint.Expression, initializer, sourceFile);
  return vm.runInNewContext(`(${expression})`, Object.create(null), { timeout: 1_000 });
}

function sqlString(value) {
  if (value === null || value === undefined) return "NULL";
  return `'${String(value)
    .replaceAll("\\", "\\\\")
    .replaceAll("'", "''")
    .replaceAll("\0", "\\0")}'`;
}

function normalizeMigration(filename) {
  return fs
    .readFileSync(path.join(projectRoot, "drizzle", filename), "utf8")
    .replaceAll("--> statement-breakpoint", "\n")
    .trim();
}

const categories = readLiteral("categoryRows");
const articles = readLiteral("articleRows");
const publishedAt = Date.now();
const categoryIds = new Map();
const statements = [
  "SET NAMES utf8mb4;",
  "SET FOREIGN_KEY_CHECKS = 0;",
  normalizeMigration("0000_awesome_zemo.sql"),
  normalizeMigration("0001_fluffy_tag.sql"),
  normalizeMigration("0002_vengeful_bedlam.sql"),
  "SET FOREIGN_KEY_CHECKS = 1;",
];

categories.forEach((category, index) => {
  const id = index + 1;
  categoryIds.set(category.slug, id);
  statements.push(
    `INSERT INTO \`categories\` (\`id\`, \`name\`, \`slug\`, \`description\`, \`imageUrl\`, \`isFeatured\`, \`sortOrder\`) VALUES (` +
      [id, sqlString(category.name), sqlString(category.slug), sqlString(category.description), sqlString(category.imageUrl), category.isFeatured ? 1 : 0, category.sortOrder].join(", ") +
      ");",
  );
});

let productId = 1;
let faqId = 1;

articles.forEach((article, index) => {
  const articleId = index + 1;
  const categoryId = categoryIds.get(article.categorySlug);
  if (!categoryId) throw new Error(`Categoria não encontrada: ${article.categorySlug}`);

  statements.push(
    `INSERT INTO \`articles\` (\`id\`, \`categoryId\`, \`title\`, \`slug\`, \`excerpt\`, \`content\`, \`coverImageUrl\`, \`authorName\`, \`status\`, \`isFeatured\`, \`seoTitle\`, \`seoDescription\`, \`publishedAt\`) VALUES (` +
      [
        articleId,
        categoryId,
        sqlString(article.title),
        sqlString(article.slug),
        sqlString(article.excerpt),
        sqlString(article.content),
        sqlString(article.coverImageUrl),
        sqlString("Equipe Compare Mais"),
        sqlString("published"),
        article.isFeatured ? 1 : 0,
        sqlString(article.seoTitle),
        sqlString(article.seoDescription),
        publishedAt,
      ].join(", ") +
      ");",
  );

  article.products.forEach((product, position) => {
    statements.push(
      `INSERT INTO \`products\` (\`id\`, \`articleId\`, \`name\`, \`tagline\`, \`imageUrl\`, \`featuresJson\`, \`estimatedPrice\`, \`priceNote\`, \`badge\`, \`position\`, \`amazonUrl\`, \`mercadoLivreUrl\`) VALUES (` +
        [
          productId++,
          articleId,
          sqlString(product.name),
          sqlString(product.tagline),
          sqlString(article.coverImageUrl),
          sqlString(JSON.stringify(product.features)),
          "NULL",
          sqlString("Preço e disponibilidade variam. Consulte a loja."),
          sqlString(product.badge),
          position + 1,
          sqlString(product.amazonUrl),
          sqlString(product.mercadoLivreUrl),
        ].join(", ") +
        ");",
    );
  });

  article.faqs.forEach((faq, position) => {
    statements.push(
      `INSERT INTO \`faqs\` (\`id\`, \`articleId\`, \`question\`, \`answer\`, \`position\`) VALUES (` +
        [faqId++, articleId, sqlString(faq.question), sqlString(faq.answer), position + 1].join(", ") +
        ");",
    );
  });
});

statements.push(
  "ALTER TABLE `categories` AUTO_INCREMENT = 6;",
  `ALTER TABLE \`articles\` AUTO_INCREMENT = ${articles.length + 1};`,
  `ALTER TABLE \`products\` AUTO_INCREMENT = ${productId};`,
  `ALTER TABLE \`faqs\` AUTO_INCREMENT = ${faqId};`,
);

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, `${statements.join("\n\n")}\n`, "utf8");
console.log(outputPath);
console.log(JSON.stringify({ categories: categories.length, articles: articles.length, products: productId - 1, faqs: faqId - 1 }));
