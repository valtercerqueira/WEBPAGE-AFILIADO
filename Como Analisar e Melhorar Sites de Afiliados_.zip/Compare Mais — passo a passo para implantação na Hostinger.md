# Compare Mais — passo a passo para implantação na Hostinger

**Autor:** Manus AI  
**Revisão:** 16 de julho de 2026  
**Projeto:** `compare_mais`

## 1. Objetivo e arquitetura que será implantada

Este roteiro implanta o Compare Mais como **aplicação Node.js SSR**, não como site estático. O projeto usa React 19 e Vite no cliente, Express no servidor, tRPC nos contratos, Drizzle ORM e MySQL/TiDB. O build produz o cliente em `dist/public`, o renderer SSR em `dist/server` e o processo Node em `dist/index.js`.

A Hostinger oferece aplicações Node.js gerenciadas nos planos Business Web Hosting e Cloud indicados em sua documentação. O fluxo aceita GitHub, arquivo ZIP ou Hostinger Connector e suporta React, Vite, Express.js e Node.js 22.[1] Este guia usa **GitHub**, pois é o caminho mais repetível para correções e novos deploys.

> **Decisão obrigatória antes de começar:** não alterar o DNS nem desligar o site atual até banco, imagens, OAuth, links afiliados, SSR e painel estarem aprovados no endereço temporário da Hostinger.

| Item | Configuração deste projeto |
|---|---|
| Tipo | Aplicação Node.js server-side |
| Framework | Express.js; usar `Other` se a detecção falhar |
| Node.js | 22.x |
| Gerenciador | pnpm 11.13.1 |
| Instalação | `pnpm install --frozen-lockfile` |
| Build | `pnpm build` |
| Start | `node dist/index.js` |
| Diretório de saída | `dist` |
| Entry file | `dist/index.js` |
| Porta | Não fixar; o código lê `PORT` da plataforma |

### Mapa rápido: onde executar cada etapa

| Ambiente | Etapas |
|---|---|
| Computador/terminal | Validar o projeto, preparar Git, exportar o banco, testar e diagnosticar |
| GitHub | Armazenar o repositório privado e a branch `main` usada no deploy |
| hPanel Hostinger | Criar MySQL, importar dados, cadastrar variáveis, criar a Web App e associar o domínio |
| Provedor OAuth | Autorizar os callbacks temporário e definitivo do painel |
| Google Search Console | Enviar sitemap e inspecionar as URLs depois do corte |

## 2. Bloqueadores que precisam ser resolvidos

Uma cópia do código não transfere automaticamente banco, conteúdo, usuários, imagens ou credenciais. O projeto atual também depende do OAuth e do storage do Manus. Sem os valores Forge, as URLs `/manus-storage/...` retornam erro e as imagens não carregam. Sem um callback OAuth autorizado no domínio da Hostinger, o site público funciona, mas o painel administrativo não permite login.

| Dependência | Risco fora do Manus | Condição para avançar |
|---|---|---|
| MySQL/TiDB | Banco vazio | Schema aplicado e dados importados ou seed executado |
| OAuth Manus | Callback externo recusado | Login aprovado no endereço temporário da Hostinger |
| Forge Storage | Imagens quebradas | Credenciais válidas ou imagens migradas para outro storage |
| Forge LLM | Resumo por IA indisponível | Credenciais válidas ou geração temporariamente desabilitada |
| Domínio/canonical | Indexação duplicada | `CANONICAL_ORIGIN` igual ao domínio final |
| Afiliados | Perda de receita | `/api/out` testado com 302 e clique registrado |

## 3. Pré-requisitos

Confirme um plano Hostinger com suporte a Node.js Web Apps, acesso ao hPanel, domínio sob controle, conta GitHub e credenciais das integrações. A documentação oficial lista Business Web Hosting e planos Cloud compatíveis.[1]

No repositório local, rode:

```bash
cd /caminho/compare_mais
pnpm install --frozen-lockfile
pnpm test
pnpm check
pnpm build
```

Só prossiga se os três últimos comandos terminarem sem erro. Não envie `.env`, dumps SQL ou segredos ao GitHub.

## 4. Criar o repositório GitHub

Crie um repositório privado, por exemplo `compare-mais`, sem README automático. Na raiz do projeto, conecte e envie o código:

```bash
git init
git add .
git commit -m "Preparar Compare Mais para Hostinger"
git branch -M main
git remote add origin git@github.com:SEU_USUARIO/compare-mais.git
git push -u origin main
```

Antes do push, confirme que `git status` não mostra `.env`, dumps ou arquivos com credenciais. O repositório precisa conter `package.json`, `pnpm-lock.yaml`, `drizzle/`, `client/`, `server/`, `shared/` e `vite.config.ts`.

> Como alternativa, a Hostinger aceita upload de um ZIP do projeto.[1] Use ZIP apenas para um teste isolado; com GitHub, os próximos deploys ficam auditáveis.

## 5. Escolher a estratégia de dados

Há duas estratégias. Para reproduzir o site atual, use **migração completa**. Para criar uma nova instância do modelo, use **schema + seed**.

| Estratégia | Resultado | Uso recomendado |
|---|---|---|
| Migração completa | Preserva artigos, produtos, FAQs, cliques, usuários e resumos por IA | Mover o Compare Mais atual |
| Schema + seed | Cria uma base inicial demonstrativa | Abrir outro site baseado no modelo |

### 5.1 Migração completa

Exporte o banco de origem em SQL usando as informações de conexão do ambiente atual. O arquivo deve incluir estrutura e dados. Em clientes MySQL, a forma geral é:

```bash
mysqldump \
  --host=HOST_ORIGEM \
  --port=PORTA_ORIGEM \
  --user=USUARIO_ORIGEM \
  --password \
  --single-transaction \
  NOME_BANCO > compare_mais_backup.sql
```

Não versione `compare_mais_backup.sql`. Guarde uma cópia criptografada e verifique se o dump contém as tabelas `categories`, `articles`, `products`, `faqs`, `relatedArticles`, `affiliateClicks` e `users`.

### 5.2 Schema + seed

Para uma instância nova, não exporte dados. O histórico Drizzle possui as migrações do schema e dos campos de resumo por IA. Após criar o banco Hostinger, aplique:

```bash
DATABASE_URL='mysql://USUARIO:SENHA@HOST:3306/BANCO' pnpm db:push
DATABASE_URL='mysql://USUARIO:SENHA@HOST:3306/BANCO' pnpm exec tsx server/seed.ts
```

O seed contém conteúdo editorial inicial. Revise títulos, imagens e links antes de indexar a nova instância.

## 6. Criar o MySQL na Hostinger

No hPanel, entre em **Databases → MySQL Databases → Create Database**. Defina nome, usuário e senha forte. A Hostinger orienta guardar nome, usuário, senha e host; para aplicações hospedadas na mesma conta, o host costuma ser `localhost` e a porta padrão é `3306`.[4]

Monte a conexão:

```text
mysql://USUARIO:SENHA_URL_ENCODED@HOST:3306/NOME_BANCO
```

Se a senha contiver `@`, `:`, `/`, `#` ou `%`, aplique URL encoding. Não inclua aspas no valor salvo no hPanel.

### 6.1 Importar o site atual

Abra o phpMyAdmin do banco novo, selecione o banco, entre em **Import**, escolha `compare_mais_backup.sql` e execute. A documentação da Hostinger permite criar tabelas e importar SQL pelo phpMyAdmin.[4]

Após a importação, confirme as contagens:

```sql
SELECT COUNT(*) AS categorias FROM categories;
SELECT COUNT(*) AS artigos FROM articles;
SELECT COUNT(*) AS produtos FROM products;
SELECT COUNT(*) AS faqs FROM faqs;
SELECT COUNT(*) AS cliques FROM affiliateClicks;
```

Se o dump ultrapassar o limite do phpMyAdmin, use o cliente MySQL ou SSH disponibilizado no plano, dividindo o arquivo sem alterar a ordem de criação e chaves estrangeiras.

## 7. Preparar os segredos e configurações

Gere um novo segredo de sessão; não reutilize um valor exposto em histórico ou chat:

```bash
openssl rand -base64 48
```

Crie uma planilha temporária local com as variáveis abaixo. Depois do cadastro, exclua a planilha. A Hostinger aceita cadastro manual ou importação de `.env` durante o deploy e não grava essas variáveis no repositório.[2]

| Variável | Obrigatoriedade | Valor esperado |
|---|---|---|
| `DATABASE_URL` | Obrigatória | URL do MySQL Hostinger |
| `JWT_SECRET` | Obrigatória | Saída nova do OpenSSL |
| `NODE_ENV` | Obrigatória | `production` |
| `CANONICAL_ORIGIN` | Obrigatória | Origem final, sem `/` no fim |
| `VITE_APP_ID` | Obrigatória para painel | ID do app OAuth |
| `OAUTH_SERVER_URL` | Obrigatória para painel | URL do servidor OAuth |
| `VITE_OAUTH_PORTAL_URL` | Obrigatória para painel | URL do portal de login |
| `OWNER_OPEN_ID` | Obrigatória para painel | Identificador do proprietário |
| `BUILT_IN_FORGE_API_URL` | Obrigatória para IA e imagens atuais | Endpoint Forge |
| `BUILT_IN_FORGE_API_KEY` | Obrigatória para IA e imagens atuais | Chave server-side |
| `VITE_FRONTEND_FORGE_API_URL` | Condicional | Apenas se o componente Map for usado |
| `VITE_FRONTEND_FORGE_API_KEY` | Condicional | Apenas se o componente Map for usado |
| `PORT` | Não cadastrar | A plataforma fornece em runtime |

Variáveis `VITE_*` são incorporadas ao bundle pelo Vite durante o build. Qualquer alteração nelas exige novo deploy. A Hostinger também exige rebuild depois de mudanças de variáveis.[3]

## 8. Resolver imagens e storage

O banco atual contém URLs como `/manus-storage/nome-do-arquivo.jpg`. O servidor transforma essas rotas em URLs assinadas usando `BUILT_IN_FORGE_API_URL` e `BUILT_IN_FORGE_API_KEY`.

Escolha uma das opções antes do corte:

| Opção | Vantagem | Risco |
|---|---|---|
| Manter Forge | Nenhuma alteração no banco | Depende de credenciais e serviço Manus fora da hospedagem |
| Migrar para S3/R2 | Portabilidade e controle | Exige upload, novo proxy/storage e atualização das URLs |
| Hospedar arquivos na Hostinger | Configuração simples para volume pequeno | Menor flexibilidade e requer estratégia de cache/backup |

Para o primeiro teste, mantenha Forge e valide todas as imagens no endereço temporário. Para independência definitiva, migre os assets para S3 ou Cloudflare R2 antes de desligar o ambiente Manus.

## 9. Configurar o OAuth administrativo

O frontend constrói o callback dinamicamente como:

```text
https://SEU-DOMINIO/api/oauth/callback
```

Cadastre o domínio temporário e, depois, o domínio final entre os callbacks autorizados do provedor OAuth. Mantenha HTTPS; o cookie de state usa `Secure` e `SameSite=None`.

> **Gate de corte:** abra `/admin`, conclua o login, edite um rascunho e salve. Se o callback não puder ser autorizado fora do Manus, não migre o painel ainda. Mantenha a publicação no Manus ou substitua a autenticação antes do corte.

## 10. Criar a aplicação Node.js no hPanel

No hPanel, acesse **Websites → Add Website → Deploy Web App → Import Git Repository**. Autorize o GitHub, selecione o repositório e a branch `main`.[1]

Na configuração de build, use:

| Campo no hPanel | Valor |
|---|---|
| Framework | `Express.js` ou `Other` |
| Node version | `22.x` |
| Root directory | Raiz do repositório |
| Install command | `pnpm install --frozen-lockfile` |
| Build command | `pnpm build` |
| Start command | `node dist/index.js` |
| Output directory | `dist` |
| Entry file | `dist/index.js` |

Se o hPanel não mostrar todos os campos, informe somente os solicitados. No tipo `Other`, a documentação indica que output e entry podem precisar ser preenchidos manualmente.[1]

Na etapa **Environment variables**, cadastre os valores da seção 7. Revise caracteres especiais, espaços e quebras de linha. Clique em **Deploy** e acompanhe os logs.

## 11. Aplicar migrations na ordem correta

Se você importou o dump completo, não rode `pnpm db:push` automaticamente. Primeiro compare o schema importado com `drizzle/schema.ts`; o dump já deve conter todas as tabelas e colunas.

Se criou banco vazio, rode as migrations uma única vez com `DATABASE_URL` apontando para a Hostinger. Isso pode ser feito localmente se o banco aceitar conexão externa, via SSH, ou por um processo controlado antes do primeiro start:

```bash
pnpm db:push
```

Não coloque migrations destrutivas no comando de start. Em produção, aplicar schema é uma operação separada do boot da aplicação.

## 12. Primeiro deploy e diagnóstico

Um deploy aprovado precisa gerar `dist/index.js`, `dist/public` e `dist/server`. Se o build falhar, abra o log do último deployment. O dashboard Node.js da Hostinger oferece detalhes do deployment, consumo de recursos, restart e atalhos para variáveis e redeploy.[1]

| Sintoma | Causa provável | Correção |
|---|---|---|
| Falha ao baixar pnpm via `npx` | Registro npm ou rede bloqueados no build | Repetir o deploy e conferir acesso a `registry.npmjs.org` |
| `DATABASE_URL is not set` | Variável ausente no build/runtime | Cadastrar e redeployar |
| `Access denied for user` | Usuário, senha ou permissão MySQL | Revisar associação do usuário ao banco |
| `Cannot connect` | Host ou porta incorretos | Confirmar host do hPanel e porta 3306 |
| Imagens 500/502 | Forge ausente ou inválido | Revisar as duas variáveis Forge |
| Login retorna erro | Callback OAuth não autorizado | Cadastrar origem e callback exatos |
| Página 403 | Roteamento do backend | Redeployar para regenerar `.htaccess`[1] |
| HTML vazio para crawler | SSR não executado | Confirmar entry `dist/index.js` e logs |

## 13. Checklist técnico no endereço temporário

Execute os testes abaixo antes de associar o domínio. Substitua `URL_TEMPORARIA` pela origem fornecida pela Hostinger.

> **Validação já realizada:** em 16 de julho de 2026, este fluxo foi reproduzido em uma cópia limpa do repositório. `pnpm install --frozen-lockfile`, 19 testes Vitest, TypeScript, build e `pnpm start` foram aprovados. Homepage, artigo, `robots.txt` e `sitemap.xml` retornaram HTTP 200; o HTML SSR continha title, canonical, três schemas JSON-LD, resumo, prós e pontos de atenção. Isso valida o projeto, mas não substitui o teste no endereço real da Hostinger.

```bash
curl -I https://URL_TEMPORARIA/
curl -I https://URL_TEMPORARIA/melhor-cafeteira
curl -I https://URL_TEMPORARIA/robots.txt
curl -I https://URL_TEMPORARIA/sitemap.xml
curl -s https://URL_TEMPORARIA/melhor-cafeteira | grep -E '<title>|canonical|application/ld\+json|Resumo rápido|Principais prós|Pontos de atenção'
```

Valide manualmente:

| Área | Critério de aprovação |
|---|---|
| Homepage | Hero, busca, categorias e cards carregam |
| Artigo | H1, disclaimer, resumo, produtos, FAQ e relacionados aparecem |
| Imagens | Nenhuma rota `/manus-storage` retorna erro |
| Afiliados | CTAs retornam 302 e abrem o marketplace correto |
| Tracking | Um clique de teste aparece em `affiliateClicks` |
| Busca | `/busca?q=cafeteira` retorna conteúdo e permanece `noindex` |
| Admin | Login, edição e salvamento funcionam |
| IA | Gerar resumo produz JSON válido e permite revisão |
| SEO | Canonical, Open Graph, JSON-LD, robots e sitemap estão corretos |
| Mobile | Navegação, prós/contras e CTAs não transbordam |

Para validar o redirecionamento afiliado sem depender do clique visual, use IDs existentes:

```bash
curl -I "https://URL_TEMPORARIA/api/out?articleId=ID_ARTIGO&productId=ID_PRODUTO&marketplace=amazon&source=/melhor-cafeteira"
```

O resultado esperado é `302` com `Location` em `amazon.com.br` ou `mercadolivre.com.br`.

## 14. Associar domínio e configurar canonical

Somente depois da aprovação no endereço temporário, associe o domínio no hPanel e aguarde HTTPS ativo. Atualize:

```text
CANONICAL_ORIGIN=https://seudominio.com.br
```

Atualize também o callback OAuth:

```text
https://seudominio.com.br/api/oauth/callback
```

Mudanças em variáveis exigem rebuild/redeploy na Hostinger.[3] Após o deploy, repita todos os health checks no domínio final.

## 15. Corte de DNS sem perda de indexação

Reduza o TTL do DNS antes da janela de migração, mantenha o site atual disponível e faça o apontamento somente após os testes. No domínio final, verifique que não há canonical para o endereço temporário nem para `manus.space`.

No Google Search Console, envie `https://seudominio.com.br/sitemap.xml` e inspecione a homepage e dois artigos. Não bloqueie crawlers durante o corte.

## 16. Rollback

O rollback precisa ser definido antes do DNS. Preserve o domínio anterior, o banco de origem, o dump SQL e o último commit aprovado.

| Falha após o corte | Ação imediata |
|---|---|
| Site indisponível | Reapontar DNS ao ambiente anterior |
| Banco inconsistente | Interromper escrita e restaurar o dump |
| Painel sem login | Reverter DNS ou manter edição no ambiente anterior |
| Imagens quebradas | Reativar Forge ou reverter até concluir migração de assets |
| Canonical incorreto | Corrigir variável e redeployar antes de novo crawl |

Não mantenha dois painéis escrevendo em bancos diferentes. Durante a virada, defina qual ambiente é a única fonte de verdade editorial.

## 17. Operação depois da publicação

Cada push na branch conectada pode disparar novo build quando a integração GitHub está habilitada.[1] Antes de enviar alterações, rode `pnpm test`, `pnpm check` e `pnpm build`. Para mudanças de banco, aplique migrations separadamente e faça backup antes.

Monitore logs, CPU, RAM e I/O pelo dashboard da aplicação. Se mudar uma variável, use **Settings & Redeploy**, confirme os valores e reconstrua a aplicação.[3]

## 18. Sequência executiva recomendada

| Ordem | Responsável | Entrega verificável |
|---|---|---|
| 1 | Técnico | Repositório privado com build aprovado |
| 2 | Proprietário | Plano Node.js e domínio disponíveis |
| 3 | Técnico | Banco Hostinger criado e backup preservado |
| 4 | Técnico | Dados importados ou seed executado |
| 5 | Proprietário/técnico | Segredos cadastrados no hPanel |
| 6 | Técnico | Deploy temporário com SSR e imagens |
| 7 | Proprietário/técnico | OAuth administrativo aprovado |
| 8 | Técnico | Afiliados, tracking, IA e SEO aprovados |
| 9 | Proprietário | Autorização do corte de DNS |
| 10 | Técnico | Domínio final, canonical e sitemap confirmados |

## Referências

[1]: https://www.hostinger.com/support/how-to-deploy-a-nodejs-website-in-hostinger/ "How to add a Node.js Web App in Hostinger"
[2]: https://www.hostinger.com/support/how-to-add-environment-variables-during-node-js-application-deployment/ "How to add environment variables during Node.js application deployment"
[3]: https://www.hostinger.com/support/how-to-edit-or-add-environment-variables-after-deployment/ "How to edit or add environment variables after deployment"
[4]: https://www.hostinger.com/support/connecting-a-hostinger-mysql-database-to-a-node-js-application/ "Connecting a Hostinger MySQL Database to a Node.js application"
