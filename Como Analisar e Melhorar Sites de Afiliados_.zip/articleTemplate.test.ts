import { describe, expect, it } from "vitest";
import {
  articleDisplayTitle,
  articleSeoDescription,
  articleSeoTitle,
  authoritySources,
  hasVerifiableAuthoritySource,
  keywordFirstParagraph,
  methodologyText,
  parseEditorialContent,
  productLimitations,
  publicationIssues,
} from "../shared/articleTemplate";

const article = {
  slug: "melhor-cafeteira",
  title: "Melhor cafeteira para a rotina",
  excerpt: "Um comparativo editorial suficientemente descritivo para orientar a escolha de compra.",
  content: "Melhor cafeteira depende da rotina.\n\n## Como escolher\n\nCompare método e manutenção.",
  categoryName: "Casa e Cozinha",
  categorySlug: "casa-e-cozinha",
  authorName: "Valter",
  seoTitle: "Qual melhor cafeteira? 2 opções analisadas",
  seoDescription: "Compare duas cafeteiras por método, manutenção, custo recorrente e praticidade. Veja prós, contras e critérios objetivos para escolher com segurança agora.",
  updatedAt: "2026-07-16",
  products: [
    { name: "Modelo A", tagline: "Compacta", features: ["Cápsulas", "Reservatório"], estimatedPrice: "499.90", amazonUrl: "https://www.amazon.com.br/dp/ABC123" },
    { name: "Modelo B", tagline: "Versátil", features: ["Espresso", "Leite"], estimatedPrice: "799.90", mercadoLivreUrl: "https://produto.mercadolivre.com.br/MLB-123" },
  ],
  faqs: Array.from({ length: 5 }, (_, index) => ({ question: `Pergunta ${index}?`, answer: "Resposta objetiva e verificável." })),
};

describe("articleTemplate", () => {
  it("gera título, metadados, seções e fontes sem alegar teste físico", () => {
    expect(articleDisplayTitle(article)).toBe("Qual o melhor cafeteira? 2 opções analisadas em 2026");
    expect(articleSeoTitle(article).length).toBeLessThanOrEqual(60);
    expect(articleSeoDescription(article).length).toBeGreaterThanOrEqual(150);
    expect(keywordFirstParagraph({ ...article, content: "Uma abertura genérica." })).toContain("melhor cafeteira");
    expect(parseEditorialContent(article.content).sections[0]).toMatchObject({ title: "Como escolher", id: "como-escolher" });
    expect(methodologyText()).toContain("Não realizamos teste físico");
    expect(authoritySources(article.categorySlug)[0].url).toContain("inmetro");
    expect(hasVerifiableAuthoritySource(article.categorySlug)).toBe(true);
  });

  it("expõe limitações reais de links de busca e ausência de preço", () => {
    expect(productLimitations({ name: "A", tagline: "B", features: [], amazonUrl: "https://www.amazon.com.br/s?k=produto" })).toEqual(expect.arrayContaining([expect.stringContaining("busca"), expect.stringContaining("faixa de preço")]));
  });

  it("bloqueia placeholders, alegações sem prova e publicação incompleta", () => {
    const issues = publicationIssues({ ...article, categorySlug: "", authorName: "Equipe Compare Mais", content: "Testamos {{produto}}.", faqs: article.faqs.slice(0, 2) });
    expect(issues).toEqual(expect.arrayContaining([expect.stringContaining("autor real"), expect.stringContaining("fonte oficial"), expect.stringContaining("5 e 8"), expect.stringContaining("placeholders"), expect.stringContaining("evidência real")]));
  });
});
