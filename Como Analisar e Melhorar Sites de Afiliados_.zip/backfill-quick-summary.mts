import { eq } from "drizzle-orm";
import { articles } from "../drizzle/schema";
import { generateArticleQuickSummary } from "../server/aiSummary";
import { getAdminArticle } from "../server/admin";
import { getDb } from "../server/db";

const db = await getDb();
if (!db) throw new Error("Banco de dados indisponível.");

const [target] = await db.select({ id: articles.id }).from(articles).where(eq(articles.slug, "melhor-cafeteira")).limit(1);
if (!target) throw new Error("Artigo melhor-cafeteira não encontrado.");

const article = await getAdminArticle(target.id);
if (!article) throw new Error("Artigo não encontrado.");

const generated = await generateArticleQuickSummary({
  title: article.title,
  excerpt: article.excerpt,
  content: article.content,
  products: article.products.map(product => ({ name: product.name, tagline: product.tagline, features: product.features })),
});

await db.update(articles).set({
  quickSummary: generated.summary,
  quickProsJson: JSON.stringify(generated.pros),
  quickConsJson: JSON.stringify(generated.cons),
  quickSummaryModel: generated.model,
  quickSummaryGeneratedAt: generated.generatedAt,
}).where(eq(articles.id, target.id));

console.log(JSON.stringify({ articleId: target.id, ...generated }, null, 2));
