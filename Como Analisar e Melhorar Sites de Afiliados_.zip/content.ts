import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import {
  getCategoryPage,
  getPublishedArticleBySlug,
  listCategories,
  listPublishedArticles,
  searchContent,
  trackAffiliateClick,
} from "../content";

export const contentRouter = router({
  categories: publicProcedure.query(() => listCategories()),
  home: publicProcedure.query(async () => {
    const [featured, latest, categoryList] = await Promise.all([
      listPublishedArticles({ featuredOnly: true, limit: 6 }),
      listPublishedArticles({ limit: 12 }),
      listCategories(),
    ]);
    return { featured, latest, categories: categoryList.filter(category => category.isFeatured).slice(0, 5) };
  }),
  category: publicProcedure
    .input(z.object({ slug: z.string().min(2).max(140) }))
    .query(({ input }) => getCategoryPage(input.slug)),
  latest: publicProcedure
    .input(
      z
        .object({
          limit: z.number().int().min(1).max(60).optional(),
          featuredOnly: z.boolean().optional(),
          categorySlug: z.string().max(140).optional(),
        })
        .optional(),
    )
    .query(({ input }) => listPublishedArticles(input)),
  articleBySlug: publicProcedure
    .input(z.object({ slug: z.string().min(1).max(255) }))
    .query(({ input }) => getPublishedArticleBySlug(input.slug)),
  article: publicProcedure
    .input(z.object({ slug: z.string().min(1).max(255) }))
    .query(({ input }) => getPublishedArticleBySlug(input.slug)),
  search: publicProcedure
    .input(z.object({ term: z.string().min(2).max(100) }))
    .query(({ input }) => searchContent(input.term)),
  trackClick: publicProcedure
    .input(
      z.object({
        articleId: z.number().int().positive(),
        productId: z.number().int().positive(),
        marketplace: z.enum(["amazon", "mercado_livre"]),
        sourcePath: z.string().max(512).optional(),
      }),
    )
    .mutation(({ ctx, input }) =>
      trackAffiliateClick({
        ...input,
        referrer: ctx.req.get("referer") ?? undefined,
        userAgent: ctx.req.get("user-agent") ?? undefined,
        ip: ctx.req.ip,
      }),
    ),
});
