import { AlertTriangle, CheckCircle2, Sparkles } from "lucide-react";
import React from "react";

type QuickSummaryProps = {
  summary: string;
  pros: string[];
  cons: string[];
};

export function QuickSummary({ summary, pros, cons }: QuickSummaryProps) {
  const visiblePros = pros.filter(Boolean).slice(0, 6);
  const visibleCons = cons.filter(Boolean).slice(0, 6);

  return (
    <section aria-labelledby="quick-summary-title" className="overflow-hidden rounded-[2rem] border border-[var(--petrol)]/15 bg-white shadow-[0_24px_70px_rgba(20,45,43,.08)]">
      <div className="border-b border-[var(--petrol)]/10 bg-[linear-gradient(115deg,rgba(20,69,64,.08),rgba(197,159,71,.12))] px-6 py-6 md:px-8">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[var(--petrol)]"><Sparkles aria-hidden="true" className="size-4 text-[var(--gold)]" /> Síntese assistida por IA</div>
        <h2 id="quick-summary-title" className="mt-3 font-display text-3xl tracking-[-.035em]">Resumo rápido</h2>
        <p className="mt-3 max-w-3xl text-base leading-7 text-[var(--muted)]">{summary}</p>
      </div>

      {(visiblePros.length > 0 || visibleCons.length > 0) && (
        <div className="grid md:grid-cols-2">
          {visiblePros.length > 0 && (
            <div className="px-6 py-6 md:px-8">
              <h3 className="flex items-center gap-2 font-semibold text-[var(--petrol)]"><CheckCircle2 aria-hidden="true" className="size-5 text-emerald-700" /> Principais prós</h3>
              <ul className="mt-4 space-y-3">
                {visiblePros.map((item, index) => <li key={`${item}-${index}`} className="flex gap-3 text-sm leading-6"><span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-emerald-700" /> <span>{item}</span></li>)}
              </ul>
            </div>
          )}
          {visibleCons.length > 0 && (
            <div className="border-t border-[var(--petrol)]/10 bg-[#fffaf0] px-6 py-6 md:border-l md:border-t-0 md:px-8">
              <h3 className="flex items-center gap-2 font-semibold text-[#795d22]"><AlertTriangle aria-hidden="true" className="size-5" /> Pontos de atenção</h3>
              <ul className="mt-4 space-y-3">
                {visibleCons.map((item, index) => <li key={`${item}-${index}`} className="flex gap-3 text-sm leading-6"><span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-[var(--gold)]" /> <span>{item}</span></li>)}
              </ul>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
