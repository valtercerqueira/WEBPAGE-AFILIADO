import { Menu, Search, ShieldCheck, X } from "lucide-react";
import { FormEvent, ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export function SiteShell({ children }: { children: ReactNode }) {
  const [, navigate] = useLocation();
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const { data: categories = [] } = trpc.content.categories.useQuery();

  function submitSearch(event: FormEvent) {
    event.preventDefault();
    const term = query.trim();
    if (term.length >= 2) navigate(`/busca?q=${encodeURIComponent(term)}`);
  }

  return (
    <div className="min-h-screen bg-[var(--paper)] text-[var(--ink)]">
      <header className="sticky top-0 z-50 border-b border-black/8 bg-[rgba(247,244,237,.92)] backdrop-blur-xl">
        <div className="container flex h-20 items-center justify-between gap-6">
          <Link href="/" className="group flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-full bg-[var(--petrol)] text-[var(--paper)] shadow-sm transition-transform group-hover:-rotate-6">C+</span>
            <span>
              <strong className="block font-display text-xl leading-none tracking-[-.03em]">Compare Mais</strong>
              <small className="mt-1 block text-[10px] font-bold uppercase tracking-[.2em] text-[var(--muted)]">Escolhas bem informadas</small>
            </span>
          </Link>

          <nav className="hidden items-center gap-7 lg:flex" aria-label="Navegação principal">
            {categories.slice(0, 5).map(category => (
              <Link key={category.id} href={`/categoria/${category.slug}`} className="nav-link">{category.name}</Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <form onSubmit={submitSearch} className="hidden items-center rounded-full border border-black/10 bg-white/70 px-4 py-2.5 md:flex">
              <Search className="mr-2 size-4 text-[var(--muted)]" />
              <input value={query} onChange={event => setQuery(event.target.value)} placeholder="Buscar análises" aria-label="Buscar análises" className="w-36 bg-transparent text-sm outline-none placeholder:text-[var(--muted)]" />
            </form>
            <button type="button" onClick={() => setMenuOpen(value => !value)} className="grid size-11 place-items-center rounded-full border border-black/10 bg-white/70 lg:hidden" aria-label={menuOpen ? "Fechar menu" : "Abrir menu"} aria-expanded={menuOpen} aria-controls="menu-mobile">
              {menuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div id="menu-mobile" className="border-t border-black/8 bg-[var(--paper)] px-5 py-5 lg:hidden">
            <form onSubmit={submitSearch} className="mb-5 flex items-center rounded-full border border-black/10 bg-white px-4 py-3">
              <Search className="mr-2 size-4" />
              <input value={query} onChange={event => setQuery(event.target.value)} placeholder="Buscar análises" aria-label="Buscar análises" className="flex-1 bg-transparent outline-none" />
            </form>
            <nav className="grid gap-2">
              {categories.map(category => <Link key={category.id} href={`/categoria/${category.slug}`} onClick={() => setMenuOpen(false)} className="rounded-xl px-3 py-2 font-semibold hover:bg-black/5">{category.name}</Link>)}
            </nav>
          </div>
        )}
      </header>

      <main>{children}</main>

      <footer className="mt-24 bg-[var(--petrol)] text-white">
        <div className="container grid gap-12 py-16 md:grid-cols-[1.2fr_.8fr_.8fr]">
          <div>
            <div className="mb-5 flex items-center gap-3"><span className="grid size-10 place-items-center rounded-full bg-white text-[var(--petrol)]">C+</span><strong className="font-display text-2xl">Compare Mais</strong></div>
            <p className="max-w-md text-sm leading-7 text-white/70">Guias de compra independentes para comparar características, entender diferenças e reduzir decisões por impulso.</p>
          </div>
          <div><h2 className="mb-4 text-xs font-bold uppercase tracking-[.2em] text-[var(--gold)]">Categorias</h2><div className="grid gap-3 text-sm text-white/75">{categories.slice(0, 5).map(category => <Link key={category.id} href={`/categoria/${category.slug}`}>{category.name}</Link>)}</div></div>
          <div><h2 className="mb-4 text-xs font-bold uppercase tracking-[.2em] text-[var(--gold)]">Transparência</h2><p className="text-sm leading-7 text-white/70">Podemos receber comissão quando uma compra é feita por nossos links, sem custo adicional para você.</p></div>
        </div>
        <div className="border-t border-white/10"><div className="container flex flex-col gap-3 py-6 text-xs text-white/55 sm:flex-row sm:items-center sm:justify-between"><span>© {new Date().getFullYear()} Compare Mais</span><span className="flex items-center gap-2"><ShieldCheck className="size-4" /> Critérios claros. Decisões melhores.</span></div></div>
      </footer>
    </div>
  );
}
