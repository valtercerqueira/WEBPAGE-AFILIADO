import { and, asc, desc, eq, sql } from "drizzle-orm";
import { articles, affiliateClicks, categories, faqs, products } from "../drizzle/schema";
import { normalizeArticleSlug } from "./content";
import { getDb } from "./db";

function requireDb<T>(db: T | null): asserts db is T {
  if (!db) throw new Error("Banco de dados indisponível.");
}

export async function getAdminOverview() {
  const db = await getDb();
  requireDb(db);
  const [[articleCount], [productCount], [clickCount], recentClicks] = await Promise.all([
    db.select({ value: sql<number>`count(*)` }).from(articles),
    db.select({ value: sql<number>`count(*)` }).from(products),
    db.select({ value: sql<number>`count(*)` }).from(affiliateClicks),
    db
      .select({
        id: affiliateClicks.id,
        clickedAt: affiliateClicks.clickedAt,
        marketplace: affiliateClicks.marketplace,
        productName: products.name,
        articleTitle: articles.title,
      })
      .from(affiliateClicks)
      .innerJoin(products, eq(affiliateClicks.productId, products.id))
      .innerJoin(articles, eq(affiliateClicks.articleId, articles.id))
      .orderBy(desc(affiliateClicks.clickedAt))
      .limit(12),
  ]);
  return {
    articleCount: Number(articleCount?.value ?? 0),
    productCount: Number(productCount?.value ?? 0),
    clickCount: Number(clickCount?.value ?? 0),
    recentClicks,
  };
}

export async function listAdminArticles() {
  const db = await getDb();
  requireDb(db);
  return db
    .select({
      id: articles.id,
      title: articles.title,
      slug: articles.slug,
      status: articles.status,
      isFeatured: articles.isFeatured,
      categoryName: categories.name,
      publishedAt: articles.publishedAt,
      updatedAt: articles.updatedAt,
    })
    .from(articles)
    .innerJoin(categories, eq(articles.categoryId, categories.id))
    .orderBy(desc(articles.updatedAt));
}

export type ArticleEditorInput = {
  id?: number;
  categoryId: number;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImageUrl: string;
  authorName: string;
  status: "draft" | "published";
  isFeatured: boolean;
  seoTitle: string;
  seoDescription: string;
  quickSummary?: string | null;
  quickPros: string[];
  quickCons: string[];
  quickSummaryModel?: string | null;
  quickSummaryGeneratedAt?: number | null;
  products: Array<{
    id?: number;
    name: string;
    tagline: string;
    imageUrl: string;
    features: string[];
    estimatedPrice?: string | null;
    priceNote: string;
    badge?: string | null;
    position: number;
    amazonUrl?: string | null;
    mercadoLivreUrl?: string | null;
  }>;
  faqs: Array<{ id?: number; question: string; answer: string; position: number }>;
};

export async function getAdminArticle(id: number) {
  const db = await getDb();
  requireDb(db);
  const [article] = await db.select().from(articles).where(eq(articles.id, id)).limit(1);
  if (!article) return null;
  const [articleProducts, articleFaqs] = await Promise.all([
    db.select().from(products).where(eq(products.articleId, id)).orderBy(asc(products.position)),
    db.select().from(faqs).where(eq(faqs.articleId, id)).orderBy(asc(faqs.position)),
  ]);
  return {
    ...article,
    quickPros: safeParseStringList(article.quickProsJson),
    quickCons: safeParseStringList(article.quickConsJson),
    products: articleProducts.map(product => ({
      ...product,
      features: JSON.parse(product.featuresJson) as string[],
    })),
    faqs: articleFaqs,
  };
}

export async function saveArticle(input: ArticleEditorInput) {
  const db = await getDb();
  requireDb(db);
  const slug = normalizeArticleSlug(input.slug);
  const now = Date.now();

  return db.transaction(async tx => {
    const articleValues = {
      categoryId: input.categoryId,
      title: input.title.trim(),
      slug,
      excerpt: input.excerpt.trim(),
      content: input.content.trim(),
      coverImageUrl: input.coverImageUrl.trim(),
      authorName: input.authorName.trim(),
      status: input.status,
      isFeatured: input.isFeatured,
      seoTitle: input.seoTitle.trim(),
      seoDescription: input.seoDescription.trim(),
      quickSummary: input.quickSummary?.trim() || null,
      quickProsJson: JSON.stringify(input.quickPros.filter(Boolean).map(item => item.trim())),
      quickConsJson: JSON.stringify(input.quickCons.filter(Boolean).map(item => item.trim())),
      quickSummaryModel: input.quickSummaryModel?.trim() || null,
      quickSummaryGeneratedAt: input.quickSummaryGeneratedAt ?? null,
      publishedAt: input.status === "published" ? now : null,
    } as const;

    let articleId = input.id;
    if (articleId) {
      await tx.update(articles).set(articleValues).where(eq(articles.id, articleId));
      await tx.delete(products).where(eq(products.articleId, articleId));
      await tx.delete(faqs).where(eq(faqs.articleId, articleId));
    } else {
      const result = await tx.insert(articles).values(articleValues);
      articleId = Number(result[0].insertId);
    }

    if (input.products.length) {
      await tx.insert(products).values(
        input.products.map(product => ({
          articleId: articleId!,
          name: product.name.trim(),
          tagline: product.tagline.trim(),
          imageUrl: product.imageUrl.trim(),
          featuresJson: JSON.stringify(product.features.filter(Boolean)),
          estimatedPrice: product.estimatedPrice || null,
          priceNote: product.priceNote.trim(),
          badge: product.badge?.trim() || null,
          position: product.position,
          amazonUrl: product.amazonUrl?.trim() || null,
          mercadoLivreUrl: product.mercadoLivreUrl?.trim() || null,
        })),
      );
    }
    if (input.faqs.length) {
      await tx.insert(faqs).values(
        input.faqs.map(faq => ({
          articleId: articleId!,
          question: faq.question.trim(),
          answer: faq.answer.trim(),
          position: faq.position,
        })),
      );
    }
    return { id: articleId, slug };
  });
}

function safeParseStringList(value: string | null): string[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter(item => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export async function saveCategory(input: {
  id?: number;
  name: string;
  slug: string;
  description: string;
  imageUrl?: string | null;
  isFeatured: boolean;
  sortOrder: number;
}) {
  const db = await getDb();
  requireDb(db);
  const values = {
    name: input.name.trim(),
    slug: input.slug.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""),
    description: input.description.trim(),
    imageUrl: input.imageUrl?.trim() || null,
    isFeatured: input.isFeatured,
    sortOrder: input.sortOrder,
  };
  if (input.id) {
    await db.update(categories).set(values).where(eq(categories.id, input.id));
    return { id: input.id, slug: values.slug };
  }
  const result = await db.insert(categories).values(values);
  return { id: Number(result[0].insertId), slug: values.slug };
}
