import type { QueryClient } from "@tanstack/react-query";
import { getQueryKey } from "@trpc/react-query";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../server/routers";
import { trpc } from "@/lib/trpc";
import { articleDisplayTitle, articleSeoDescription, articleSeoTitle, expandedFaqs, resolveAuthor } from "../../../shared/articleTemplate";

type RouterOutputs = inferRouterOutputs<AppRouter>;

export type HeadMeta = {
  title: string;
  description: string;
  canonicalPath: string;
  ogType?: "website" | "article";
  ogImage?: string | null;
  publishedTime?: string;
  modifiedTime?: string;
  noindex?: boolean;
  notFound?: boolean;
  jsonLd?: unknown[];
};

export type SsrPrefetch = {
  categories: () => Promise<RouterOutputs["content"]["categories"]>;
  home: () => Promise<RouterOutputs["content"]["home"]>;
  category: (input: { slug: string }) => Promise<RouterOutputs["content"]["category"]>;
  article: (input: { slug: string }) => Promise<RouterOutputs["content"]["article"]>;
  search: (input: { term: string }) => Promise<RouterOutputs["content"]["search"]>;
};

const SITE = "Compare Mais";
const DEFAULT_DESCRIPTION = "Comparativos independentes, critérios claros e atalhos confiáveis para escolher produtos com mais segurança.";

function setQueryData(queryClient: QueryClient, key: unknown, data: unknown) {
  (queryClient.setQueryData as (queryKey: unknown, value: unknown) => void)(key, data);
}

export function articleSchemas(article: NonNullable<RouterOutputs["content"]["article"]>) {
  const articlePath = `/${article.slug}`;
  const breadcrumbItems = [
    { "@type": "ListItem", position: 1, name: "Início", item: "/" },
    { "@type": "ListItem", position: 2, name: article.categoryName, item: `/categoria/${article.categorySlug}` },
    { "@type": "ListItem", position: 3, name: article.title, item: articlePath },
  ];
  const author = resolveAuthor(article.authorName);
  const productItems = article.products.map((product, index) => ({
    "@type": "ListItem",
    position: index + 1,
    item: {
      "@type": "Product",
      name: product.name,
      image: product.imageUrl,
      description: product.tagline,
      url: product.mercadoLivreUrl || product.amazonUrl || articlePath,
      ...(product.estimatedPrice ? { offers: { "@type": "AggregateOffer", priceCurrency: "BRL", lowPrice: product.estimatedPrice, highPrice: product.estimatedPrice, url: product.mercadoLivreUrl || product.amazonUrl || articlePath } } : {}),
    },
  }));

  return [{
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Article",
        headline: articleDisplayTitle(article),
        description: article.seoDescription ?? article.excerpt,
        image: article.coverImageUrl ? [article.coverImageUrl] : undefined,
        datePublished: article.publishedAt ? new Date(article.publishedAt).toISOString() : undefined,
        dateModified: article.updatedAt ? new Date(article.updatedAt).toISOString() : undefined,
        author: { "@type": "Person", name: author.name, jobTitle: author.jobTitle, url: author.url },
        publisher: { "@type": "Organization", name: SITE, logo: { "@type": "ImageObject", url: "/favicon.svg" } },
        mainEntityOfPage: articlePath,
      },
      { "@type": "BreadcrumbList", itemListElement: breadcrumbItems },
      { "@type": "ItemList", numberOfItems: productItems.length, itemListElement: productItems },
      { "@type": "FAQPage", mainEntity: expandedFaqs(article).map(faq => ({ "@type": "Question", name: faq.question, acceptedAnswer: { "@type": "Answer", text: faq.answer } })) },
    ],
  }];
}

export async function prefetchForPath(url: string, queryClient: QueryClient, prefetch: SsrPrefetch): Promise<HeadMeta> {
  const queryIndex = url.indexOf("?");
  const rawPath = queryIndex === -1 ? url : url.slice(0, queryIndex);
  const rawSearch = queryIndex === -1 ? "" : url.slice(queryIndex + 1);
  let decodedPath = rawPath;
  try { decodedPath = decodeURI(rawPath); } catch { /* preserve malformed path for 404 */ }
  const path = decodedPath.replace(/\/+$/, "") || "/";

  const categories = await prefetch.categories();
  setQueryData(queryClient, getQueryKey(trpc.content.categories, undefined, "query"), categories);

  if (path === "/") {
    const data = await prefetch.home();
    setQueryData(queryClient, getQueryKey(trpc.content.home, undefined, "query"), data);
    return { title: `${SITE} — Escolhas inteligentes começam com bons critérios`, description: DEFAULT_DESCRIPTION, canonicalPath: "/", ogType: "website", ogImage: data.featured[0]?.coverImageUrl };
  }

  if (path === "/busca") {
    const term = new URLSearchParams(rawSearch).get("q")?.trim() ?? "";
    if (term.length >= 2) {
      const data = await prefetch.search({ term });
      setQueryData(queryClient, getQueryKey(trpc.content.search, { term }, "query"), data);
    }
    return { title: term ? `Busca por “${term}” — ${SITE}` : `Busca — ${SITE}`, description: "Busque artigos e produtos analisados pelo Compare Mais.", canonicalPath: "/busca", noindex: true };
  }

  if (path === "/admin" || path.startsWith("/admin/")) {
    return { title: `Painel editorial — ${SITE}`, description: "Área administrativa do Compare Mais.", canonicalPath: path, noindex: true };
  }

  if (path === "/metodologia") return { title: `Metodologia editorial — ${SITE}`, description: "Entenda como o Compare Mais seleciona, compara e revisa produtos sem alegações de teste físico não comprovadas.", canonicalPath: path, ogType: "website" };
  if (path === "/autor/valter") return { title: `Valter, responsável editorial — ${SITE}`, description: "Conheça o responsável editorial pelo Compare Mais e os compromissos de transparência usados nos comparativos.", canonicalPath: path, ogType: "website" };

  const categoryMatch = path.match(/^\/categoria\/([^/]+)$/);
  if (categoryMatch) {
    const input = { slug: categoryMatch[1] };
    const data = await prefetch.category(input);
    setQueryData(queryClient, getQueryKey(trpc.content.category, input, "query"), data);
    if (!data) return { title: `Categoria não encontrada — ${SITE}`, description: DEFAULT_DESCRIPTION, canonicalPath: path, noindex: true, notFound: true };
    return { title: `${data.category.name}: melhores produtos e comparativos — ${SITE}`, description: data.category.description ?? DEFAULT_DESCRIPTION, canonicalPath: path, ogType: "website", ogImage: data.articles[0]?.coverImageUrl };
  }

  if (/^\/melhor-[^/]+$/.test(path)) {
    const input = { slug: path.slice("/melhor-".length) };
    const data = await prefetch.article(input);
    setQueryData(queryClient, getQueryKey(trpc.content.article, input, "query"), data);
    if (!data) return { title: `Análise não encontrada — ${SITE}`, description: DEFAULT_DESCRIPTION, canonicalPath: path, noindex: true, notFound: true };
    return {
      title: articleSeoTitle(data),
      description: data.seoDescription && data.seoDescription.length >= 150 && data.seoDescription.length <= 160 ? data.seoDescription : articleSeoDescription(data),
      canonicalPath: path,
      ogType: "article",
      ogImage: data.coverImageUrl,
      publishedTime: data.publishedAt ? new Date(data.publishedAt).toISOString() : undefined,
      modifiedTime: data.updatedAt ? new Date(data.updatedAt).toISOString() : undefined,
      jsonLd: articleSchemas(data),
    };
  }

  return { title: `Página não encontrada — ${SITE}`, description: DEFAULT_DESCRIPTION, canonicalPath: path, noindex: true, notFound: true };
}
