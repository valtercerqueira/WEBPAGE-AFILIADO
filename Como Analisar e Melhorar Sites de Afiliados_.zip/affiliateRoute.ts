import type { Express } from "express";
import { trackAffiliateClick } from "./content";

export function registerAffiliateRoute(app: Express) {
  app.get("/api/out", async (req, res) => {
    try {
      const articleId = Number(req.query.articleId);
      const productId = Number(req.query.productId);
      const marketplace = req.query.marketplace;
      if (
        !Number.isInteger(articleId) ||
        articleId <= 0 ||
        !Number.isInteger(productId) ||
        productId <= 0 ||
        (marketplace !== "amazon" && marketplace !== "mercado_livre")
      ) {
        res.status(400).send("Parâmetros de redirecionamento inválidos.");
        return;
      }

      const result = await trackAffiliateClick({
        articleId,
        productId,
        marketplace,
        sourcePath: typeof req.query.source === "string" ? req.query.source : undefined,
        referrer: req.get("referer") ?? undefined,
        userAgent: req.get("user-agent") ?? undefined,
        ip: req.ip,
      });

      res.setHeader("Cache-Control", "no-store");
      res.redirect(302, result.url);
    } catch (error) {
      console.error("[Affiliate redirect]", error);
      res.status(404).send("Link de afiliado indisponível.");
    }
  });
}
