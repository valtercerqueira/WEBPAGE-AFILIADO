import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./_core/llm", () => ({
  listLLMModels: vi.fn(),
  invokeLLM: vi.fn(),
}));

import { invokeLLM, listLLMModels } from "./_core/llm";
import { buildQuickSummaryPrompt, generateArticleQuickSummary } from "./aiSummary";

const source = {
  title: "Melhores cafeteiras para comprar",
  excerpt: "Uma análise equilibrada para comparar preparo, manutenção e custo total antes da compra.",
  content: "Este guia compara capacidade, facilidade de limpeza, pressão e adequação a diferentes rotinas de uso. ".repeat(4),
  products: [
    {
      name: "Cafeteira Exemplo",
      tagline: "Modelo compacto para rotinas simples",
      features: ["Reservatório removível", "Painel intuitivo", "Ocupa pouco espaço"],
    },
  ],
};

describe("resumo rápido por IA", () => {
  beforeEach(() => vi.clearAllMocks());

  it("limita o conteúdo enviado e preserva os dados editoriais relevantes", () => {
    const prompt = buildQuickSummaryPrompt({ ...source, content: "a".repeat(20000) });
    expect(prompt).toContain(source.title);
    expect(prompt).toContain("Cafeteira Exemplo");
    expect(prompt.length).toBeLessThan(15500);
  });

  it("seleciona um modelo econômico disponível e valida a resposta estruturada", async () => {
    vi.mocked(listLLMModels).mockResolvedValue({ data: [{ id: "gpt-5-mini" }] } as never);
    vi.mocked(invokeLLM).mockResolvedValue({
      choices: [
        {
          message: {
            content: JSON.stringify({
              summary: "O comparativo prioriza facilidade de uso, manutenção e adequação à rotina, ajudando a identificar qual perfil de cafeteira faz mais sentido antes da compra.",
              pros: ["Comparação por critérios práticos", "Considera manutenção", "Diferencia perfis de uso"],
              cons: ["A escolha depende da rotina", "Preços precisam ser confirmados na loja"],
            }),
          },
        },
      ],
    } as never);

    const result = await generateArticleQuickSummary(source);

    expect(result.model).toBe("gpt-5-mini");
    expect(result.pros).toHaveLength(3);
    expect(result.cons).toHaveLength(2);
    expect(result.generatedAt).toEqual(expect.any(Number));
    expect(invokeLLM).toHaveBeenCalledWith(expect.objectContaining({ model: "gpt-5-mini", response_format: expect.any(Object) }));
  });

  it("rejeita respostas fora do schema editorial", async () => {
    vi.mocked(listLLMModels).mockResolvedValue({ data: [{ id: "gpt-5-mini" }] } as never);
    vi.mocked(invokeLLM).mockResolvedValue({ choices: [{ message: { content: JSON.stringify({ summary: "Curto", pros: [], cons: [] }) } }] } as never);
    await expect(generateArticleQuickSummary(source)).rejects.toThrow();
  });
});
