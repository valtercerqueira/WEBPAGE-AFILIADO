import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "../_core/context";

vi.mock("../aiSummary", () => ({
  generateArticleQuickSummary: vi.fn().mockResolvedValue({
    summary: "Resumo estruturado e validado para orientar a leitura do comparativo antes da decisão de compra.",
    pros: ["Pró 1", "Pró 2", "Pró 3"],
    cons: ["Contra 1", "Contra 2"],
    model: "gpt-5-mini",
    generatedAt: 1710000000000,
  }),
}));

import { appRouter } from "../routers";

const input = {
  title: "Melhores cafeteiras para comprar",
  excerpt: "Uma análise equilibrada para comparar preparo, manutenção e custo total antes da compra.",
  content: "Este conteúdo editorial possui informações suficientes para gerar uma síntese útil, factual e equilibrada para o leitor.",
  products: [],
};

function context(role: "admin" | "user" | null): TrpcContext {
  return {
    user: role
      ? {
          id: 1,
          openId: "editor",
          email: "editor@example.com",
          name: "Editor",
          loginMethod: "manus",
          role,
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        }
      : null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("admin.generateQuickSummary", () => {
  it("rejeita usuários sem papel administrativo", async () => {
    await expect(appRouter.createCaller(context("user")).admin.generateQuickSummary(input)).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("retorna o resumo estruturado para administradores", async () => {
    const result = await appRouter.createCaller(context("admin")).admin.generateQuickSummary(input);
    expect(result.model).toBe("gpt-5-mini");
    expect(result.pros).toHaveLength(3);
  });
});
