import { timingSafeEqual } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { diagnoseDatabaseConnection } from "../dbDiagnostics";
import { notifyOwner } from "./notification";
import { adminProcedure, publicProcedure, router } from "./trpc";

export function hasValidDatabaseDiagnosticToken(candidate: string) {
  const expected = process.env.DB_DIAGNOSTIC_TOKEN;
  if (!expected || candidate.length !== expected.length) return false;
  return timingSafeEqual(Buffer.from(candidate), Buffer.from(expected));
}

export const systemRouter = router({
  health: publicProcedure
    .input(
      z.object({
        timestamp: z.number().min(0, "timestamp cannot be negative"),
      })
    )
    .query(() => ({
      ok: true,
    })),

  databaseHealth: publicProcedure
    .input(z.object({ token: z.string().min(32).max(256) }))
    .mutation(({ input }) => {
      if (!hasValidDatabaseDiagnosticToken(input.token)) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Diagnóstico não autorizado." });
      }
      return diagnoseDatabaseConnection();
    }),

  notifyOwner: adminProcedure
    .input(
      z.object({
        title: z.string().min(1, "title is required"),
        content: z.string().min(1, "content is required"),
      })
    )
    .mutation(async ({ input }) => {
      const delivered = await notifyOwner(input);
      return {
        success: delivered,
      } as const;
    }),
});
