import { describe, expect, it } from "vitest";
import { ARTICLE_SLUG_PATTERN, normalizeArticleSlug, validateAffiliateDestination } from "./content";
import { articleSchema } from "./routers/admin";

const validArticle = {
  categoryId: 1,
  title: "Melhor cafeteira para uma rotina prática",
  slug: "melhor-cafeteira",
  excerpt: "Um comparativo editorial com critérios objetivos para orientar uma compra mais segura.",
  content: "Este conteúdo apresenta critérios de capacidade, manutenção, ergonomia e custo total para comparar diferentes propostas de cafeteiras domésticas.",
  coverImageUrl: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd",
  authorName: "Equipe Compare Mais",
  status: "published" as const,
  isFeatured: true,
  seoTitle: "Melhor cafeteira: critérios para escolher",
  seoDescription: "Compare cafeteiras por capacidade, manutenção, praticidade e custo antes de decidir qual modelo faz sentido para sua rotina.",
  quickSummary: null,
  quickPros: [],
  quickCons: [],
  quickSummaryModel: null,
  quickSummaryGeneratedAt: null,
  products: [{
    name: "Cafeteira compacta",
    tagline: "Uma opção prática para o uso diário.",
    imageUrl: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085",
    features: ["Reservatório removível"],
    estimatedPrice: "399.90",
    priceNote: "Preço estimado; confirme na loja.",
    badge: "Escolha equilibrada",
    position: 0,
    amazonUrl: "https://www.amazon.com.br/dp/exemplo",
    mercadoLivreUrl: "https://www.mercadolivre.com.br/produto-exemplo",
  }],
  faqs: [{ question: "Como escolher a capacidade correta?", answer: "Relacione o volume do reservatório ao número de doses preparadas por dia e à frequência de limpeza desejada.", position: 0 }],
};

describe("slugs editoriais", () => {
  it("normaliza acentos e aplica o prefixo obrigatório", () => {
    expect(normalizeArticleSlug("Cafeteira Elétrica Premium")).toBe("melhor-cafeteira-eletrica-premium");
    expect(ARTICLE_SLUG_PATTERN.test(normalizeArticleSlug("melhor-smart-tv"))).toBe(true);
  });
});

describe("destinos afiliados", () => {
  it("aceita apenas HTTPS e hosts permitidos por marketplace", () => {
    expect(validateAffiliateDestination("https://amzn.to/exemplo", "amazon").hostname).toBe("amzn.to");
    expect(validateAffiliateDestination("https://www.mercadolivre.com.br/produto", "mercado_livre").hostname).toBe("www.mercadolivre.com.br");
    expect(() => validateAffiliateDestination("https://exemplo.com/phishing", "amazon")).toThrow("Destino de afiliado inválido");
    expect(() => validateAffiliateDestination("http://amazon.com.br/inseguro", "amazon")).toThrow("Destino de afiliado inválido");
  });
});

describe("validação administrativa", () => {
  it("aceita um artigo completo e rejeita slug ou domínio afiliado inválidos", () => {
    expect(articleSchema.safeParse(validArticle).success).toBe(true);
    expect(articleSchema.safeParse({ ...validArticle, slug: "URL Com Espaços" }).success).toBe(false);
    const products = [{ ...validArticle.products[0], amazonUrl: "https://exemplo.com/produto" }];
    expect(articleSchema.safeParse({ ...validArticle, products }).success).toBe(false);
  });
});
