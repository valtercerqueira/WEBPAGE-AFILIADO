# Referências oficiais para deploy na Hostinger

Consulta realizada em **16 de julho de 2026**.

## Fatos confirmados

A Hostinger informa que aplicações Node.js podem ser implantadas pelo hPanel por três caminhos: integração com repositório GitHub, upload de arquivo ZIP ou Hostinger Connector. A documentação lista **React, Vite e Express.js** entre as tecnologias aceitas e informa suporte às versões Node.js **18.x, 20.x, 22.x e 24.x**. Para aplicações não detectadas automaticamente, o preset `Other` permite indicar diretório de saída e arquivo de entrada.[1]

No fluxo gerenciado, o hPanel sugere configurações de build, permite cadastrar variáveis de ambiente, executa o build e disponibiliza logs de implantação. A documentação também descreve redeploy automático quando a aplicação é conectada a um repositório GitHub.[1] [2]

Para implantação manual em VPS, a documentação recomenda preparar scripts de produção, manter segredos em variáveis de ambiente, executar o processo Node.js com um gerenciador como PM2, encaminhar tráfego por NGINX e habilitar HTTPS.[2]

## Referências

[1]: https://www.hostinger.com/support/how-to-deploy-a-nodejs-website-in-hostinger/ "How to add a Node.js Web App in Hostinger"
[2]: https://www.hostinger.com/tutorials/deploy-node-js-application "How to deploy a Node.js application"
