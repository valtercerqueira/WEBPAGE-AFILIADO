# Fontes oficiais Hostinger consultadas em 16/07/2026

## Deploy de aplicação Node.js

Fonte: https://www.hostinger.com/support/how-to-deploy-a-nodejs-website-in-hostinger/

- Aplicações Node.js gerenciadas estão disponíveis nos planos Business Web Hosting e Cloud listados pela Hostinger.
- Métodos: integração GitHub, upload ZIP ou Hostinger Connector.
- Tecnologias suportadas incluem React, Vite e Express.js; versões Node.js 18, 20, 22 e 24.
- O fluxo no hPanel é Websites → Add Website → Deploy Web App.
- Em tipo `Other`, pode ser necessário informar diretório de saída e entry file.
- Para este projeto: saída `dist`, entry `dist/index.js`, Node 22.
- O dashboard oferece deployments, environment variables, settings/redeploy, logs, gráficos de recursos e restart.
- Builds de backend são armazenados fora de `public_html`; o roteamento é criado pela Hostinger.

## Variáveis durante o deploy

Fonte: https://www.hostinger.com/support/how-to-add-environment-variables-during-node-js-application-deployment/

- Podem ser importadas de `.env` ou cadastradas manualmente.
- Não são armazenadas no repositório.
- Segredos nunca devem ser commitados no GitHub.
- Alterações posteriores podem exigir rebuild/redeploy.

## Variáveis após o deploy

Fonte: https://www.hostinger.com/support/how-to-edit-or-add-environment-variables-after-deployment/

- Acessar Website Dashboard ou Deployments → Settings & Redeploy.
- Mudanças em environment variables exigem rebuild para entrar em vigor.
- Em deploy por ZIP, é possível reutilizar o último arquivo enviado ao alterar apenas variáveis.

## MySQL com Node.js

Fonte: https://www.hostinger.com/support/connecting-a-hostinger-mysql-database-to-a-node-js-application/

- Criar em Databases → MySQL Databases e guardar nome, usuário, senha e host.
- A Hostinger mostra `DATABASE_URL=mysql://usuario:senha@localhost:3306/banco` como opção válida.
- Após alterar a conexão, reiniciar/reconstruir a aplicação.
- Tabelas podem ser aplicadas via phpMyAdmin ou pela aplicação.
- Erros comuns: usuário/senha, usuário não associado ao banco, host/porta e variáveis não recarregadas.
