SET NAMES utf8mb4;

SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);

CREATE TABLE `affiliateClicks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`articleId` int NOT NULL,
	`productId` int NOT NULL,
	`marketplace` enum('amazon','mercado_livre') NOT NULL,
	`sourcePath` varchar(512),
	`referrer` text,
	`userAgent` text,
	`ipHash` varchar(128),
	`clickedAt` bigint NOT NULL,
	CONSTRAINT `affiliateClicks_id` PRIMARY KEY(`id`)
);


CREATE TABLE `articles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`categoryId` int NOT NULL,
	`title` varchar(240) NOT NULL,
	`slug` varchar(255) NOT NULL,
	`excerpt` text NOT NULL,
	`content` text NOT NULL,
	`coverImageUrl` varchar(1024) NOT NULL,
	`authorName` varchar(120) NOT NULL DEFAULT 'Equipe Compare Mais',
	`status` enum('draft','published') NOT NULL DEFAULT 'draft',
	`isFeatured` boolean NOT NULL DEFAULT false,
	`seoTitle` varchar(180) NOT NULL,
	`seoDescription` varchar(320) NOT NULL,
	`publishedAt` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `articles_id` PRIMARY KEY(`id`),
	CONSTRAINT `articles_slug_unique` UNIQUE(`slug`)
);


CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`slug` varchar(140) NOT NULL,
	`description` text NOT NULL,
	`imageUrl` varchar(1024),
	`isFeatured` boolean NOT NULL DEFAULT false,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `categories_slug_unique` UNIQUE(`slug`)
);


CREATE TABLE `faqs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`articleId` int NOT NULL,
	`question` varchar(320) NOT NULL,
	`answer` text NOT NULL,
	`position` int NOT NULL DEFAULT 0,
	CONSTRAINT `faqs_id` PRIMARY KEY(`id`)
);


CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`articleId` int NOT NULL,
	`name` varchar(220) NOT NULL,
	`tagline` varchar(280) NOT NULL,
	`imageUrl` varchar(1024) NOT NULL,
	`featuresJson` text NOT NULL,
	`estimatedPrice` decimal(10,2),
	`priceNote` varchar(180) NOT NULL DEFAULT 'Preço estimado; pode variar.',
	`badge` varchar(80),
	`position` int NOT NULL DEFAULT 0,
	`amazonUrl` text,
	`mercadoLivreUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);


CREATE TABLE `relatedArticles` (
	`articleId` int NOT NULL,
	`relatedArticleId` int NOT NULL,
	CONSTRAINT `relatedArticles_articleId_relatedArticleId_pk` PRIMARY KEY(`articleId`,`relatedArticleId`)
);


ALTER TABLE `affiliateClicks` ADD CONSTRAINT `affiliateClicks_articleId_articles_id_fk` FOREIGN KEY (`articleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;

ALTER TABLE `affiliateClicks` ADD CONSTRAINT `affiliateClicks_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE no action;

ALTER TABLE `articles` ADD CONSTRAINT `articles_categoryId_categories_id_fk` FOREIGN KEY (`categoryId`) REFERENCES `categories`(`id`) ON DELETE restrict ON UPDATE no action;

ALTER TABLE `faqs` ADD CONSTRAINT `faqs_articleId_articles_id_fk` FOREIGN KEY (`articleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;

ALTER TABLE `products` ADD CONSTRAINT `products_articleId_articles_id_fk` FOREIGN KEY (`articleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;

ALTER TABLE `relatedArticles` ADD CONSTRAINT `relatedArticles_articleId_articles_id_fk` FOREIGN KEY (`articleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;

ALTER TABLE `relatedArticles` ADD CONSTRAINT `relatedArticles_relatedArticleId_articles_id_fk` FOREIGN KEY (`relatedArticleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;

CREATE INDEX `affiliate_clicks_article_idx` ON `affiliateClicks` (`articleId`);

CREATE INDEX `affiliate_clicks_product_idx` ON `affiliateClicks` (`productId`);

CREATE INDEX `affiliate_clicks_marketplace_idx` ON `affiliateClicks` (`marketplace`);

CREATE INDEX `affiliate_clicks_date_idx` ON `affiliateClicks` (`clickedAt`);

CREATE INDEX `articles_category_idx` ON `articles` (`categoryId`);

CREATE INDEX `articles_status_idx` ON `articles` (`status`);

CREATE INDEX `faqs_article_idx` ON `faqs` (`articleId`);

CREATE INDEX `products_article_idx` ON `products` (`articleId`);

ALTER TABLE `articles` ADD `quickSummary` text;

ALTER TABLE `articles` ADD `quickProsJson` text;

ALTER TABLE `articles` ADD `quickConsJson` text;

ALTER TABLE `articles` ADD `quickSummaryModel` varchar(120);

ALTER TABLE `articles` ADD `quickSummaryGeneratedAt` bigint;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `imageUrl`, `isFeatured`, `sortOrder`) VALUES (1, 'Casa e Cozinha', 'casa-e-cozinha', 'Guias objetivos para escolher eletroportáteis, utensílios e soluções para a casa.', '/manus-storage/home_90156953.jpg', 1, 1);

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `imageUrl`, `isFeatured`, `sortOrder`) VALUES (2, 'Eletrônicos', 'eletronicos', 'Comparativos de áudio, imagem, informática e tecnologia de uso diário.', '/manus-storage/technology_b443779e.jpg', 1, 2);

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `imageUrl`, `isFeatured`, `sortOrder`) VALUES (3, 'Beleza e Saúde', 'beleza-e-saude', 'Critérios práticos para avaliar cuidados pessoais, beleza e bem-estar.', '/manus-storage/home_90156953.jpg', 1, 3);

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `imageUrl`, `isFeatured`, `sortOrder`) VALUES (4, 'Esportes', 'esportes', 'Equipamentos para treino, corrida, lazer e desempenho esportivo.', '/manus-storage/automotive_5faf8abe.jpg', 0, 4);

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `imageUrl`, `isFeatured`, `sortOrder`) VALUES (5, 'Automotivo', 'automotivo', 'Acessórios, ferramentas e tecnologia para carros e mobilidade.', '/manus-storage/automotive_5faf8abe.jpg', 0, 5);

INSERT INTO `articles` (`id`, `categoryId`, `title`, `slug`, `excerpt`, `content`, `coverImageUrl`, `authorName`, `status`, `isFeatured`, `seoTitle`, `seoDescription`, `publishedAt`) VALUES (1, 2, 'Melhores fones Bluetooth: como escolher o modelo certo', 'melhor-fone-bluetooth', 'Compare autonomia, conforto, codecs e cancelamento de ruído antes de escolher um fone Bluetooth para trabalho, viagem ou lazer.', 'Escolher um fone Bluetooth exige mais do que comparar aparência. Autonomia real, conforto em uso prolongado, qualidade dos microfones e estabilidade da conexão mudam bastante entre as faixas de preço. Neste guia, organizamos os critérios que merecem prioridade e apresentamos modelos conhecidos do mercado para facilitar sua pesquisa.

## O que avaliar antes da compra

Para trabalho e chamadas, priorize microfones consistentes e conexão multiponto. Em viagens, o cancelamento ativo de ruído e a autonomia ganham importância. Para uso doméstico, conforto e assinatura sonora podem pesar mais do que recursos adicionais.

## Como comparamos

A seleção considera especificações publicadas pelos fabricantes, recursos disponíveis e adequação a diferentes perfis de uso. Preços e disponibilidade variam; confirme as condições na loja antes de concluir a compra.', '/manus-storage/headphones_bcff34ca.jpg', 'Equipe Compare Mais', 'published', 1, 'Melhores fones Bluetooth: guia de compra atualizado | Compare Mais', 'Veja os critérios essenciais para comparar fones Bluetooth, incluindo autonomia, conforto, microfone e cancelamento de ruído.', 1784250212870);

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (1, 1, 'JBL Tune 770NC', 'Opção versátil com cancelamento de ruído para uso diário.', '/manus-storage/headphones_bcff34ca.jpg', '["Cancelamento ativo de ruído","Conexão Bluetooth","Formato over-ear"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Versátil', 1, 'https://www.amazon.com.br/s?k=JBL+Tune+770NC', 'https://lista.mercadolivre.com.br/jbl-tune-770nc');

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (2, 1, 'Edifier W820NB Plus', 'Alternativa over-ear focada em conforto e recursos de áudio.', '/manus-storage/headphones_bcff34ca.jpg', '["Cancelamento ativo de ruído","Formato circum-aural","Aplicativo de controle"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Conforto', 2, 'https://www.amazon.com.br/s?k=Edifier+W820NB+Plus', 'https://lista.mercadolivre.com.br/edifier-w820nb-plus');

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (3, 1, 'Soundcore Life Q30', 'Modelo popular para quem busca recursos e autonomia.', '/manus-storage/headphones_bcff34ca.jpg', '["Perfis de cancelamento de ruído","Equalização por aplicativo","Conexão multiponto"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Recursos', 3, 'https://www.amazon.com.br/s?k=Soundcore+Life+Q30', 'https://lista.mercadolivre.com.br/soundcore-life-q30');

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (1, 1, 'Fone Bluetooth com cancelamento de ruído vale a pena?', 'Pode valer para viagens, escritórios compartilhados e ambientes constantes de ruído. O benefício depende do tipo de som externo e do ajuste do fone no ouvido.', 1);

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (2, 1, 'Qual autonomia é adequada para uso diário?', 'Para a maioria das rotinas, modelos que cobrem uma semana de deslocamentos sem recarga frequente oferecem boa conveniência. Confirme a autonomia declarada com e sem cancelamento de ruído.', 2);

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (3, 1, 'O que é conexão multiponto?', 'É a capacidade de manter o fone conectado a dois dispositivos compatíveis, facilitando alternar entre computador e celular.', 3);

INSERT INTO `articles` (`id`, `categoryId`, `title`, `slug`, `excerpt`, `content`, `coverImageUrl`, `authorName`, `status`, `isFeatured`, `seoTitle`, `seoDescription`, `publishedAt`) VALUES (2, 2, 'Melhores smart TVs: critérios para acertar no tamanho e painel', 'melhor-smart-tv', 'Entenda resolução, tipo de painel, sistema operacional e conectividade para comparar smart TVs sem pagar por recursos desnecessários.', 'A melhor smart TV depende da distância de visualização, da iluminação do ambiente e do conteúdo consumido. Tamanho maior nem sempre significa experiência melhor quando o espaço é limitado.

## Tamanho e distância

Antes de comparar marcas, meça a parede e a distância do sofá. Em salas claras, brilho e controle de reflexos merecem atenção. Para filmes à noite, contraste e uniformidade do painel se tornam mais relevantes.

## Sistema e conexões

Verifique se os aplicativos usados pela sua família estão disponíveis e se há entradas HDMI suficientes para consoles, soundbars e outros dispositivos.', '/manus-storage/technology_b443779e.jpg', 'Equipe Compare Mais', 'published', 1, 'Melhores smart TVs: tamanho, painel e sistema | Compare Mais', 'Aprenda a comparar smart TVs por tamanho, resolução, painel, sistema e conectividade antes de comprar.', 1784250212870);

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (4, 2, 'Samsung Crystal UHD', 'Linha 4K com ampla oferta de tamanhos e plataforma integrada.', '/manus-storage/technology_b443779e.jpg', '["Resolução 4K","Plataforma de streaming","Múltiplas opções de tamanho"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Uso geral', 1, 'https://www.amazon.com.br/s?k=Samsung+Crystal+UHD', 'https://lista.mercadolivre.com.br/samsung-crystal-uhd');

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (5, 2, 'LG UHD AI ThinQ', 'Linha 4K com sistema webOS e recursos conectados.', '/manus-storage/technology_b443779e.jpg', '["Resolução 4K","Sistema webOS","Integração com dispositivos"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Sistema', 2, 'https://www.amazon.com.br/s?k=LG+UHD+AI+ThinQ', 'https://lista.mercadolivre.com.br/lg-uhd-ai-thinq');

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (4, 2, 'Qual tamanho de TV escolher?', 'Use a distância de visualização, a resolução e o espaço disponível como referência. Uma medição prévia evita que a tela fique desproporcional ao ambiente.', 1);

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (5, 2, 'Toda TV 4K oferece a mesma qualidade?', 'Não. Brilho, contraste, processamento de imagem, uniformidade e tipo de painel também influenciam o resultado.', 2);

INSERT INTO `articles` (`id`, `categoryId`, `title`, `slug`, `excerpt`, `content`, `coverImageUrl`, `authorName`, `status`, `isFeatured`, `seoTitle`, `seoDescription`, `publishedAt`) VALUES (3, 1, 'Melhores air fryers: capacidade, potência e facilidade de limpeza', 'melhor-air-fryer', 'Veja como comparar tamanho do cesto, potência, controles e limpeza para escolher uma air fryer adequada à sua rotina.', 'A capacidade anunciada não conta toda a história. O formato do cesto, a área útil e a circulação de ar influenciam quanto alimento pode ser preparado de uma vez.

## Capacidade útil

Famílias maiores tendem a aproveitar cestos amplos, enquanto cozinhas compactas pedem equilíbrio entre capacidade e espaço de bancada.

## Limpeza e operação

Peças removíveis, revestimento e controles intuitivos reduzem atrito no uso diário. Compare também a potência com a instalação elétrica disponível.', '/manus-storage/home_90156953.jpg', 'Equipe Compare Mais', 'published', 1, 'Melhores air fryers: capacidade e potência | Compare Mais', 'Compare air fryers por capacidade útil, potência, controles e facilidade de limpeza antes de escolher.', 1784250212870);

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (6, 3, 'Philips Walita Airfryer', 'Linha tradicional com foco em circulação de ar e uso cotidiano.', '/manus-storage/home_90156953.jpg', '["Cesto removível","Controle de temperatura","Timer"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Tradicional', 1, 'https://www.amazon.com.br/s?k=Philips+Walita+Airfryer', 'https://lista.mercadolivre.com.br/philips-walita-airfryer');

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (7, 3, 'Mondial Family', 'Linha com opções de capacidade para diferentes tamanhos de família.', '/manus-storage/home_90156953.jpg', '["Controle de temperatura","Timer","Cesto removível"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Capacidade', 2, 'https://www.amazon.com.br/s?k=Mondial+Air+Fryer+Family', 'https://lista.mercadolivre.com.br/mondial-air-fryer-family');

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (6, 3, 'Quantos litros uma air fryer precisa ter?', 'Depende do número de pessoas e do tipo de preparo. Compare a área útil do cesto, não apenas o volume informado.', 1);

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (7, 3, 'Air fryer consome muita energia?', 'A potência pode ser alta, mas o tempo de uso costuma ser menor que o de alguns fornos. O consumo real depende da potência, duração e frequência.', 2);

INSERT INTO `articles` (`id`, `categoryId`, `title`, `slug`, `excerpt`, `content`, `coverImageUrl`, `authorName`, `status`, `isFeatured`, `seoTitle`, `seoDescription`, `publishedAt`) VALUES (4, 1, 'Melhores cafeteiras: encontre o método ideal para sua rotina', 'melhor-cafeteira', 'Compare cafeteiras elétricas, cápsulas e espresso pelo custo por xícara, praticidade e controle de preparo.', 'O método de preparo muda o sabor, o custo recorrente e o tempo gasto por xícara. Antes de escolher, defina quantas pessoas serão atendidas e quanto controle você deseja sobre o café.

## Custo recorrente

Máquinas de cápsula priorizam conveniência, enquanto modelos com filtro atendem volumes maiores. Máquinas espresso exigem mais atenção a moagem e limpeza, mas ampliam o controle.

## Espaço e manutenção

Considere altura, profundidade, acesso ao reservatório e facilidade para remover peças. Uma máquina adequada ao espaço tende a ser usada com maior frequência.', '/manus-storage/home_90156953.jpg', 'Equipe Compare Mais', 'published', 0, 'Melhores cafeteiras: elétrica, cápsula ou espresso | Compare Mais', 'Entenda as diferenças entre cafeteiras elétricas, de cápsula e espresso, incluindo custo e manutenção.', 1784250212870);

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (8, 4, 'Nespresso Essenza Mini', 'Máquina compacta para preparo rápido com cápsulas compatíveis.', '/manus-storage/home_90156953.jpg', '["Formato compacto","Sistema de cápsulas","Reservatório removível"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Compacta', 1, 'https://www.amazon.com.br/s?k=Nespresso+Essenza+Mini', 'https://lista.mercadolivre.com.br/nespresso-essenza-mini');

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (9, 4, 'Oster PrimaLatte', 'Linha voltada a bebidas espresso com opções de leite.', '/manus-storage/home_90156953.jpg', '["Preparo de espresso","Reservatório de leite","Controles frontais"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Bebidas com leite', 2, 'https://www.amazon.com.br/s?k=Oster+PrimaLatte', 'https://lista.mercadolivre.com.br/oster-primalatte');

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (8, 4, 'Cafeteira de cápsula é mais cara no longo prazo?', 'O custo por xícara costuma ser superior ao do café filtrado. A diferença depende da marca das cápsulas, do consumo e das promoções disponíveis.', 1);

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (9, 4, 'Qual cafeteira exige menos manutenção?', 'Modelos de filtro simples tendem a ter menos componentes. Toda cafeteira exige limpeza periódica e, em alguns casos, descalcificação.', 2);

INSERT INTO `articles` (`id`, `categoryId`, `title`, `slug`, `excerpt`, `content`, `coverImageUrl`, `authorName`, `status`, `isFeatured`, `seoTitle`, `seoDescription`, `publishedAt`) VALUES (5, 3, 'Melhores protetores solares: como comparar textura e proteção', 'melhor-protetor-solar', 'Entenda FPS, proteção UVA, textura e resistência à água para escolher um protetor solar adequado à pele e ao uso.', 'A proteção adequada depende da aplicação correta e da reaplicação. Textura, acabamento e compatibilidade com a pele são importantes porque influenciam a consistência de uso.

## Proteção e acabamento

Compare o FPS, as informações de proteção UVA e a resistência à água. Para o rosto, acabamento e conforto podem ser decisivos.

## Uso responsável

Siga as instruções do rótulo e procure orientação profissional quando houver condição dermatológica, sensibilidade ou dúvida específica.', '/manus-storage/home_90156953.jpg', 'Equipe Compare Mais', 'published', 0, 'Melhores protetores solares: FPS, UVA e textura | Compare Mais', 'Saiba comparar protetores solares por FPS, proteção UVA, textura, resistência à água e tipo de uso.', 1784250212870);

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (10, 5, 'La Roche-Posay Anthelios', 'Linha facial com diferentes acabamentos e níveis de proteção.', '/manus-storage/home_90156953.jpg', '["Opções faciais","Proteção UVA e UVB","Diferentes acabamentos"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Uso facial', 1, 'https://www.amazon.com.br/s?k=La+Roche+Posay+Anthelios', 'https://lista.mercadolivre.com.br/la-roche-posay-anthelios');

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (11, 5, 'Neutrogena Sun Fresh', 'Linha corporal e facial com opções para uso cotidiano.', '/manus-storage/home_90156953.jpg', '["Proteção UVA e UVB","Opções corporais","Variações de FPS"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Uso diário', 2, 'https://www.amazon.com.br/s?k=Neutrogena+Sun+Fresh', 'https://lista.mercadolivre.com.br/neutrogena-sun-fresh');

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (10, 5, 'FPS maior elimina a necessidade de reaplicar?', 'Não. Reaplicação e quantidade adequada continuam importantes, especialmente após suor, água ou fricção. Siga o rótulo do produto.', 1);

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (11, 5, 'Posso usar protetor corporal no rosto?', 'Algumas pessoas toleram, mas fórmulas faciais podem oferecer acabamento mais confortável. Peles sensíveis ou com condições específicas exigem orientação profissional.', 2);

INSERT INTO `articles` (`id`, `categoryId`, `title`, `slug`, `excerpt`, `content`, `coverImageUrl`, `authorName`, `status`, `isFeatured`, `seoTitle`, `seoDescription`, `publishedAt`) VALUES (6, 4, 'Melhores tênis de corrida: conforto, ajuste e tipo de treino', 'melhor-tenis-corrida', 'Use ajuste, estabilidade, amortecimento e tipo de treino como critérios para pesquisar seu próximo tênis de corrida.', 'Não existe um único tênis ideal para todos. Formato do pé, volume de treino, terreno e preferência de sensação mudam a escolha.

## Ajuste primeiro

O tênis precisa acomodar o pé sem pontos de pressão. Sempre confira a política de troca e, quando possível, experimente o modelo.

## Treino e terreno

Modelos para asfalto, trilha e treinos rápidos priorizam características diferentes. Considere como o produto será usado na maior parte do tempo.', '/manus-storage/automotive_5faf8abe.jpg', 'Equipe Compare Mais', 'published', 0, 'Melhores tênis de corrida: ajuste e tipo de treino | Compare Mais', 'Veja como comparar tênis de corrida por ajuste, estabilidade, amortecimento, terreno e rotina de treino.', 1784250212870);

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (12, 6, 'Nike Pegasus', 'Linha de treino diário conhecida pela proposta versátil.', '/manus-storage/automotive_5faf8abe.jpg', '["Uso em asfalto","Treino diário","Cabedal respirável"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Versátil', 1, 'https://www.amazon.com.br/s?k=Nike+Pegasus', 'https://lista.mercadolivre.com.br/nike-pegasus');

INSERT INTO `products` (`id`, `articleId`, `name`, `tagline`, `imageUrl`, `featuresJson`, `estimatedPrice`, `priceNote`, `badge`, `position`, `amazonUrl`, `mercadoLivreUrl`) VALUES (13, 6, 'Asics Gel-Cumulus', 'Linha de rodagem diária com foco em conforto.', '/manus-storage/automotive_5faf8abe.jpg', '["Uso em asfalto","Amortecimento","Treino diário"]', NULL, 'Preço e disponibilidade variam. Consulte a loja.', 'Conforto', 2, 'https://www.amazon.com.br/s?k=Asics+Gel+Cumulus', 'https://lista.mercadolivre.com.br/asics-gel-cumulus');

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (12, 6, 'Tênis mais macio é sempre melhor?', 'Não. A preferência por maciez, firmeza e estabilidade varia. Ajuste, conforto e adequação ao treino são mais importantes do que um único atributo.', 1);

INSERT INTO `faqs` (`id`, `articleId`, `question`, `answer`, `position`) VALUES (13, 6, 'Quando trocar o tênis de corrida?', 'Observe desgaste da sola, perda de conforto, deformações e mudanças de sensação. A durabilidade varia conforme uso, terreno, peso e construção.', 2);

ALTER TABLE `categories` AUTO_INCREMENT = 6;

ALTER TABLE `articles` AUTO_INCREMENT = 7;

ALTER TABLE `products` AUTO_INCREMENT = 14;

ALTER TABLE `faqs` AUTO_INCREMENT = 14;
