# Compare Mais — Direção visual e referências

## Conceito

O portal deve parecer uma publicação editorial premium, não uma vitrine promocional. A composição combina fundo marfim, azul-petróleo profundo, verde-sálvia e pequenos acentos dourados. A tipografia usa uma serifada de alto contraste nos títulos e uma sans-serif limpa na navegação, especificações e CTAs. A hierarquia privilegia leitura, confiança e comparação objetiva.

## Princípios de interface

O cabeçalho deve ser leve e editorial, com busca visível e categorias acessíveis. A homepage deve usar um hero assimétrico, carrossel de destaques e um grid de análises com bastante respiro. Cards de produto devem evitar aparência genérica de marketplace: a informação essencial vem primeiro, seguida de características e dos dois CTAs obrigatórios. A página de artigo deve sustentar leitura longa, com índice, disclaimer destacado, comparativo claro, FAQ e artigos relacionados.

## Ativos visuais externos

As imagens foram encontradas por pesquisa visual em páginas de coleção do Unsplash e publicadas no armazenamento do projeto. Elas funcionam apenas como fotografia editorial de contexto; não representam avaliações, notas ou depoimentos de usuários.

| Uso | Referência de origem | Caminho publicado |
|---|---|---|
| Eletrônicos / áudio | [Product Pictures — Unsplash](https://unsplash.com/s/photos/product) | `/manus-storage/headphones_bcff34ca.jpg` |
| Tecnologia | [Product Review Pictures — Unsplash](https://unsplash.com/s/photos/product-review) | `/manus-storage/technology_b443779e.jpg` |
| Casa e cozinha | [High End Home Pictures — Unsplash](https://unsplash.com/s/photos/high-end-home) | `/manus-storage/home_90156953.jpg` |
| Automotivo / mobilidade | [Home Technology Pictures — Unsplash](https://unsplash.com/s/photos/home-technology) | `/manus-storage/automotive_5faf8abe.jpg` |

## Restrições editoriais

Não criar, simular ou exibir avaliações, estrelas, contagens de compradores ou depoimentos inexistentes. Preços devem ser identificados como estimados. O disclaimer de afiliados aparece em todo artigo. Os CTAs usam exatamente “Ver na Amazon” e “Ver no Mercado Livre”.
