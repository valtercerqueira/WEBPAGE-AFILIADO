import { z } from "zod";
import { invokeLLM, listLLMModels } from "./_core/llm";

export const quickSummaryResultSchema = z.object({
  summary: z.string().min(80).max(600),
  pros: z.array(z.string().min(2).max(180)).min(3).max(5),
  cons: z.array(z.string().min(2).max(180)).min(2).max(4),
});

export type QuickSummarySource = {
  title: string;
  excerpt: string;
  content: string;
  products: Array<{ name: string; tagline: string; features: string[] }>;
};

const responseFormat = {
  type: "json_schema" as const,
  json_schema: {
    name: "article_quick_summary",
    strict: true,
    schema: {
      type: "object",
      properties: {
        summary: {
          type: "string",
          minLength: 80,
          maxLength: 600,
          description: "Resumo factual em português do Brasil, com 2 ou 3 frases e no máximo 600 caracteres.",
        },
        pros: {
          type: "array",
          minItems: 3,
          maxItems: 5,
          items: { type: "string", minLength: 2, maxLength: 180 },
          description: "Principais vantagens sustentadas exclusivamente pelo conteúdo fornecido.",
        },
        cons: {
          type: "array",
          minItems: 2,
          maxItems: 4,
          items: { type: "string", minLength: 2, maxLength: 180 },
          description: "Limitações, concessões ou situações em que a escolha pode não ser adequada.",
        },
      },
      required: ["summary", "pros", "cons"],
      additionalProperties: false,
    },
  },
};

export function buildQuickSummaryPrompt(source: QuickSummarySource) {
  const safeProducts = source.products.slice(0, 12).map(product => ({
    name: product.name,
    tagline: product.tagline,
    features: product.features.slice(0, 12),
  }));

  return [
    "TÍTULO:",
    source.title,
    "\nRESUMO EDITORIAL:",
    source.excerpt,
    "\nCONTEÚDO:",
    source.content.slice(0, 14000),
    "\nPRODUTOS E CARACTERÍSTICAS:",
    JSON.stringify(safeProducts),
  ].join("\n");
}

export async function generateArticleQuickSummary(source: QuickSummarySource) {
  const catalog = await listLLMModels();
  const availableIds = catalog.data.map(model => model.id);
  const model = availableIds.includes("gpt-5-mini")
    ? "gpt-5-mini"
    : availableIds.includes("gpt-5-nano")
      ? "gpt-5-nano"
      : availableIds[0];

  if (!model) throw new Error("Nenhum modelo de IA está disponível no momento.");

  const response = await invokeLLM({
    model,
    messages: [
      {
        role: "system",
        content:
          "Você é um editor sênior de guias de compra. Gere um resumo rápido equilibrado em português do Brasil. Use apenas fatos presentes no material recebido. Não invente testes, avaliações, notas, preços, consenso de usuários ou superioridade absoluta. Trate os contras com utilidade prática e sem linguagem promocional. Retorne somente o JSON solicitado.",
      },
      { role: "user", content: buildQuickSummaryPrompt(source) },
    ],
    response_format: responseFormat,
  });

  const raw = response.choices[0]?.message?.content;
  if (typeof raw !== "string") throw new Error("A IA não retornou um resumo utilizável.");

  const parsed = quickSummaryResultSchema.parse(JSON.parse(raw));
  return {
    ...parsed,
    model,
    generatedAt: Date.now(),
  };
}
