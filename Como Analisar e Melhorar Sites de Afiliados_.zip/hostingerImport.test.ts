import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const sqlPath = path.resolve(process.cwd(), "artifacts", "compare_mais_hostinger_import.sql");

describe("pacote SQL da Hostinger", () => {
  it("contém o schema completo e o conteúdo editorial inicial", () => {
    const sql = fs.readFileSync(sqlPath, "utf8");

    expect(sql.match(/^CREATE TABLE/gm)).toHaveLength(7);
    expect(sql.match(/^INSERT INTO `categories`/gm)).toHaveLength(5);
    expect(sql.match(/^INSERT INTO `articles`/gm)).toHaveLength(6);
    expect(sql.match(/^INSERT INTO `products`/gm)).toHaveLength(13);
    expect(sql.match(/^INSERT INTO `faqs`/gm)).toHaveLength(13);
    expect(sql).toContain("ALTER TABLE `articles` ADD `quickSummary` text;");
    expect(sql).not.toMatch(/statement-breakpoint|set this to|undefined/);
  });
});
