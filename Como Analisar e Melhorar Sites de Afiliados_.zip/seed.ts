import { eq } from "drizzle-orm";
import { articles, categories, faqs, products } from "../drizzle/schema";
import { getDb } from "./db";

const categoryRows = [
  { name: "Casa e Cozinha", slug: "casa-e-cozinha", description: "Guias objetivos para escolher eletroportáteis, utensílios e soluções para a casa.", imageUrl: "/manus-storage/home_90156953.jpg", isFeatured: true, sortOrder: 1 },
  { name: "Eletrônicos", slug: "eletronicos", description: "Comparativos de áudio, imagem, informática e tecnologia de uso diário.", imageUrl: "/manus-storage/technology_b443779e.jpg", isFeatured: true, sortOrder: 2 },
  { name: "Beleza e Saúde", slug: "beleza-e-saude", description: "Critérios práticos para avaliar cuidados pessoais, beleza e bem-estar.", imageUrl: "/manus-storage/home_90156953.jpg", isFeatured: true, sortOrder: 3 },
  { name: "Esportes", slug: "esportes", description: "Equipamentos para treino, corrida, lazer e desempenho esportivo.", imageUrl: "/manus-storage/automotive_5faf8abe.jpg", isFeatured: false, sortOrder: 4 },
  { name: "Automotivo", slug: "automotivo", description: "Acessórios, ferramentas e tecnologia para carros e mobilidade.", imageUrl: "/manus-storage/automotive_5faf8abe.jpg", isFeatured: false, sortOrder: 5 },
];

const articleRows = [
  {
    categorySlug: "eletronicos",
    title: "Melhores fones Bluetooth: como escolher o modelo certo",
    slug: "melhor-fone-bluetooth",
    excerpt: "Compare autonomia, conforto, codecs e cancelamento de ruído antes de escolher um fone Bluetooth para trabalho, viagem ou lazer.",
    content: "Escolher um fone Bluetooth exige mais do que comparar aparência. Autonomia real, conforto em uso prolongado, qualidade dos microfones e estabilidade da conexão mudam bastante entre as faixas de preço. Neste guia, organizamos os critérios que merecem prioridade e apresentamos modelos conhecidos do mercado para facilitar sua pesquisa.\n\n## O que avaliar antes da compra\n\nPara trabalho e chamadas, priorize microfones consistentes e conexão multiponto. Em viagens, o cancelamento ativo de ruído e a autonomia ganham importância. Para uso doméstico, conforto e assinatura sonora podem pesar mais do que recursos adicionais.\n\n## Como comparamos\n\nA seleção considera especificações publicadas pelos fabricantes, recursos disponíveis e adequação a diferentes perfis de uso. Preços e disponibilidade variam; confirme as condições na loja antes de concluir a compra.",
    coverImageUrl: "/manus-storage/headphones_bcff34ca.jpg",
    isFeatured: true,
    seoTitle: "Melhores fones Bluetooth: guia de compra atualizado | Compare Mais",
    seoDescription: "Veja os critérios essenciais para comparar fones Bluetooth, incluindo autonomia, conforto, microfone e cancelamento de ruído.",
    products: [
      { name: "JBL Tune 770NC", tagline: "Opção versátil com cancelamento de ruído para uso diário.", features: ["Cancelamento ativo de ruído", "Conexão Bluetooth", "Formato over-ear"], badge: "Versátil", amazonUrl: "https://www.amazon.com.br/s?k=JBL+Tune+770NC", mercadoLivreUrl: "https://lista.mercadolivre.com.br/jbl-tune-770nc" },
      { name: "Edifier W820NB Plus", tagline: "Alternativa over-ear focada em conforto e recursos de áudio.", features: ["Cancelamento ativo de ruído", "Formato circum-aural", "Aplicativo de controle"], badge: "Conforto", amazonUrl: "https://www.amazon.com.br/s?k=Edifier+W820NB+Plus", mercadoLivreUrl: "https://lista.mercadolivre.com.br/edifier-w820nb-plus" },
      { name: "Soundcore Life Q30", tagline: "Modelo popular para quem busca recursos e autonomia.", features: ["Perfis de cancelamento de ruído", "Equalização por aplicativo", "Conexão multiponto"], badge: "Recursos", amazonUrl: "https://www.amazon.com.br/s?k=Soundcore+Life+Q30", mercadoLivreUrl: "https://lista.mercadolivre.com.br/soundcore-life-q30" },
    ],
    faqs: [
      { question: "Fone Bluetooth com cancelamento de ruído vale a pena?", answer: "Pode valer para viagens, escritórios compartilhados e ambientes constantes de ruído. O benefício depende do tipo de som externo e do ajuste do fone no ouvido." },
      { question: "Qual autonomia é adequada para uso diário?", answer: "Para a maioria das rotinas, modelos que cobrem uma semana de deslocamentos sem recarga frequente oferecem boa conveniência. Confirme a autonomia declarada com e sem cancelamento de ruído." },
      { question: "O que é conexão multiponto?", answer: "É a capacidade de manter o fone conectado a dois dispositivos compatíveis, facilitando alternar entre computador e celular." },
    ],
  },
  {
    categorySlug: "eletronicos",
    title: "Melhores smart TVs: critérios para acertar no tamanho e painel",
    slug: "melhor-smart-tv",
    excerpt: "Entenda resolução, tipo de painel, sistema operacional e conectividade para comparar smart TVs sem pagar por recursos desnecessários.",
    content: "A melhor smart TV depende da distância de visualização, da iluminação do ambiente e do conteúdo consumido. Tamanho maior nem sempre significa experiência melhor quando o espaço é limitado.\n\n## Tamanho e distância\n\nAntes de comparar marcas, meça a parede e a distância do sofá. Em salas claras, brilho e controle de reflexos merecem atenção. Para filmes à noite, contraste e uniformidade do painel se tornam mais relevantes.\n\n## Sistema e conexões\n\nVerifique se os aplicativos usados pela sua família estão disponíveis e se há entradas HDMI suficientes para consoles, soundbars e outros dispositivos.",
    coverImageUrl: "/manus-storage/technology_b443779e.jpg",
    isFeatured: true,
    seoTitle: "Melhores smart TVs: tamanho, painel e sistema | Compare Mais",
    seoDescription: "Aprenda a comparar smart TVs por tamanho, resolução, painel, sistema e conectividade antes de comprar.",
    products: [
      { name: "Samsung Crystal UHD", tagline: "Linha 4K com ampla oferta de tamanhos e plataforma integrada.", features: ["Resolução 4K", "Plataforma de streaming", "Múltiplas opções de tamanho"], badge: "Uso geral", amazonUrl: "https://www.amazon.com.br/s?k=Samsung+Crystal+UHD", mercadoLivreUrl: "https://lista.mercadolivre.com.br/samsung-crystal-uhd" },
      { name: "LG UHD AI ThinQ", tagline: "Linha 4K com sistema webOS e recursos conectados.", features: ["Resolução 4K", "Sistema webOS", "Integração com dispositivos"], badge: "Sistema", amazonUrl: "https://www.amazon.com.br/s?k=LG+UHD+AI+ThinQ", mercadoLivreUrl: "https://lista.mercadolivre.com.br/lg-uhd-ai-thinq" },
    ],
    faqs: [
      { question: "Qual tamanho de TV escolher?", answer: "Use a distância de visualização, a resolução e o espaço disponível como referência. Uma medição prévia evita que a tela fique desproporcional ao ambiente." },
      { question: "Toda TV 4K oferece a mesma qualidade?", answer: "Não. Brilho, contraste, processamento de imagem, uniformidade e tipo de painel também influenciam o resultado." },
    ],
  },
  {
    categorySlug: "casa-e-cozinha",
    title: "Melhores air fryers: capacidade, potência e facilidade de limpeza",
    slug: "melhor-air-fryer",
    excerpt: "Veja como comparar tamanho do cesto, potência, controles e limpeza para escolher uma air fryer adequada à sua rotina.",
    content: "A capacidade anunciada não conta toda a história. O formato do cesto, a área útil e a circulação de ar influenciam quanto alimento pode ser preparado de uma vez.\n\n## Capacidade útil\n\nFamílias maiores tendem a aproveitar cestos amplos, enquanto cozinhas compactas pedem equilíbrio entre capacidade e espaço de bancada.\n\n## Limpeza e operação\n\nPeças removíveis, revestimento e controles intuitivos reduzem atrito no uso diário. Compare também a potência com a instalação elétrica disponível.",
    coverImageUrl: "/manus-storage/home_90156953.jpg",
    isFeatured: true,
    seoTitle: "Melhores air fryers: capacidade e potência | Compare Mais",
    seoDescription: "Compare air fryers por capacidade útil, potência, controles e facilidade de limpeza antes de escolher.",
    products: [
      { name: "Philips Walita Airfryer", tagline: "Linha tradicional com foco em circulação de ar e uso cotidiano.", features: ["Cesto removível", "Controle de temperatura", "Timer"], badge: "Tradicional", amazonUrl: "https://www.amazon.com.br/s?k=Philips+Walita+Airfryer", mercadoLivreUrl: "https://lista.mercadolivre.com.br/philips-walita-airfryer" },
      { name: "Mondial Family", tagline: "Linha com opções de capacidade para diferentes tamanhos de família.", features: ["Controle de temperatura", "Timer", "Cesto removível"], badge: "Capacidade", amazonUrl: "https://www.amazon.com.br/s?k=Mondial+Air+Fryer+Family", mercadoLivreUrl: "https://lista.mercadolivre.com.br/mondial-air-fryer-family" },
    ],
    faqs: [
      { question: "Quantos litros uma air fryer precisa ter?", answer: "Depende do número de pessoas e do tipo de preparo. Compare a área útil do cesto, não apenas o volume informado." },
      { question: "Air fryer consome muita energia?", answer: "A potência pode ser alta, mas o tempo de uso costuma ser menor que o de alguns fornos. O consumo real depende da potência, duração e frequência." },
    ],
  },
  {
    categorySlug: "casa-e-cozinha",
    title: "Melhores cafeteiras: encontre o método ideal para sua rotina",
    slug: "melhor-cafeteira",
    excerpt: "Compare cafeteiras elétricas, cápsulas e espresso pelo custo por xícara, praticidade e controle de preparo.",
    content: "O método de preparo muda o sabor, o custo recorrente e o tempo gasto por xícara. Antes de escolher, defina quantas pessoas serão atendidas e quanto controle você deseja sobre o café.\n\n## Custo recorrente\n\nMáquinas de cápsula priorizam conveniência, enquanto modelos com filtro atendem volumes maiores. Máquinas espresso exigem mais atenção a moagem e limpeza, mas ampliam o controle.\n\n## Espaço e manutenção\n\nConsidere altura, profundidade, acesso ao reservatório e facilidade para remover peças. Uma máquina adequada ao espaço tende a ser usada com maior frequência.",
    coverImageUrl: "/manus-storage/home_90156953.jpg",
    isFeatured: false,
    seoTitle: "Melhores cafeteiras: elétrica, cápsula ou espresso | Compare Mais",
    seoDescription: "Entenda as diferenças entre cafeteiras elétricas, de cápsula e espresso, incluindo custo e manutenção.",
    products: [
      { name: "Nespresso Essenza Mini", tagline: "Máquina compacta para preparo rápido com cápsulas compatíveis.", features: ["Formato compacto", "Sistema de cápsulas", "Reservatório removível"], badge: "Compacta", amazonUrl: "https://www.amazon.com.br/s?k=Nespresso+Essenza+Mini", mercadoLivreUrl: "https://lista.mercadolivre.com.br/nespresso-essenza-mini" },
      { name: "Oster PrimaLatte", tagline: "Linha voltada a bebidas espresso com opções de leite.", features: ["Preparo de espresso", "Reservatório de leite", "Controles frontais"], badge: "Bebidas com leite", amazonUrl: "https://www.amazon.com.br/s?k=Oster+PrimaLatte", mercadoLivreUrl: "https://lista.mercadolivre.com.br/oster-primalatte" },
    ],
    faqs: [
      { question: "Cafeteira de cápsula é mais cara no longo prazo?", answer: "O custo por xícara costuma ser superior ao do café filtrado. A diferença depende da marca das cápsulas, do consumo e das promoções disponíveis." },
      { question: "Qual cafeteira exige menos manutenção?", answer: "Modelos de filtro simples tendem a ter menos componentes. Toda cafeteira exige limpeza periódica e, em alguns casos, descalcificação." },
    ],
  },
  {
    categorySlug: "beleza-e-saude",
    title: "Melhores protetores solares: como comparar textura e proteção",
    slug: "melhor-protetor-solar",
    excerpt: "Entenda FPS, proteção UVA, textura e resistência à água para escolher um protetor solar adequado à pele e ao uso.",
    content: "A proteção adequada depende da aplicação correta e da reaplicação. Textura, acabamento e compatibilidade com a pele são importantes porque influenciam a consistência de uso.\n\n## Proteção e acabamento\n\nCompare o FPS, as informações de proteção UVA e a resistência à água. Para o rosto, acabamento e conforto podem ser decisivos.\n\n## Uso responsável\n\nSiga as instruções do rótulo e procure orientação profissional quando houver condição dermatológica, sensibilidade ou dúvida específica.",
    coverImageUrl: "/manus-storage/home_90156953.jpg",
    isFeatured: false,
    seoTitle: "Melhores protetores solares: FPS, UVA e textura | Compare Mais",
    seoDescription: "Saiba comparar protetores solares por FPS, proteção UVA, textura, resistência à água e tipo de uso.",
    products: [
      { name: "La Roche-Posay Anthelios", tagline: "Linha facial com diferentes acabamentos e níveis de proteção.", features: ["Opções faciais", "Proteção UVA e UVB", "Diferentes acabamentos"], badge: "Uso facial", amazonUrl: "https://www.amazon.com.br/s?k=La+Roche+Posay+Anthelios", mercadoLivreUrl: "https://lista.mercadolivre.com.br/la-roche-posay-anthelios" },
      { name: "Neutrogena Sun Fresh", tagline: "Linha corporal e facial com opções para uso cotidiano.", features: ["Proteção UVA e UVB", "Opções corporais", "Variações de FPS"], badge: "Uso diário", amazonUrl: "https://www.amazon.com.br/s?k=Neutrogena+Sun+Fresh", mercadoLivreUrl: "https://lista.mercadolivre.com.br/neutrogena-sun-fresh" },
    ],
    faqs: [
      { question: "FPS maior elimina a necessidade de reaplicar?", answer: "Não. Reaplicação e quantidade adequada continuam importantes, especialmente após suor, água ou fricção. Siga o rótulo do produto." },
      { question: "Posso usar protetor corporal no rosto?", answer: "Algumas pessoas toleram, mas fórmulas faciais podem oferecer acabamento mais confortável. Peles sensíveis ou com condições específicas exigem orientação profissional." },
    ],
  },
  {
    categorySlug: "esportes",
    title: "Melhores tênis de corrida: conforto, ajuste e tipo de treino",
    slug: "melhor-tenis-corrida",
    excerpt: "Use ajuste, estabilidade, amortecimento e tipo de treino como critérios para pesquisar seu próximo tênis de corrida.",
    content: "Não existe um único tênis ideal para todos. Formato do pé, volume de treino, terreno e preferência de sensação mudam a escolha.\n\n## Ajuste primeiro\n\nO tênis precisa acomodar o pé sem pontos de pressão. Sempre confira a política de troca e, quando possível, experimente o modelo.\n\n## Treino e terreno\n\nModelos para asfalto, trilha e treinos rápidos priorizam características diferentes. Considere como o produto será usado na maior parte do tempo.",
    coverImageUrl: "/manus-storage/automotive_5faf8abe.jpg",
    isFeatured: false,
    seoTitle: "Melhores tênis de corrida: ajuste e tipo de treino | Compare Mais",
    seoDescription: "Veja como comparar tênis de corrida por ajuste, estabilidade, amortecimento, terreno e rotina de treino.",
    products: [
      { name: "Nike Pegasus", tagline: "Linha de treino diário conhecida pela proposta versátil.", features: ["Uso em asfalto", "Treino diário", "Cabedal respirável"], badge: "Versátil", amazonUrl: "https://www.amazon.com.br/s?k=Nike+Pegasus", mercadoLivreUrl: "https://lista.mercadolivre.com.br/nike-pegasus" },
      { name: "Asics Gel-Cumulus", tagline: "Linha de rodagem diária com foco em conforto.", features: ["Uso em asfalto", "Amortecimento", "Treino diário"], badge: "Conforto", amazonUrl: "https://www.amazon.com.br/s?k=Asics+Gel+Cumulus", mercadoLivreUrl: "https://lista.mercadolivre.com.br/asics-gel-cumulus" },
    ],
    faqs: [
      { question: "Tênis mais macio é sempre melhor?", answer: "Não. A preferência por maciez, firmeza e estabilidade varia. Ajuste, conforto e adequação ao treino são mais importantes do que um único atributo." },
      { question: "Quando trocar o tênis de corrida?", answer: "Observe desgaste da sola, perda de conforto, deformações e mudanças de sensação. A durabilidade varia conforme uso, terreno, peso e construção." },
    ],
  },
];

async function seed() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL indisponível");

  for (const category of categoryRows) {
    await db.insert(categories).values(category).onDuplicateKeyUpdate({ set: category });
  }

  for (const article of articleRows) {
    const [category] = await db.select({ id: categories.id }).from(categories).where(eq(categories.slug, article.categorySlug)).limit(1);
    if (!category) continue;
    const existing = await db.select({ id: articles.id }).from(articles).where(eq(articles.slug, article.slug)).limit(1);
    if (existing.length) continue;
    const result = await db.insert(articles).values({
      categoryId: category.id,
      title: article.title,
      slug: article.slug,
      excerpt: article.excerpt,
      content: article.content,
      coverImageUrl: article.coverImageUrl,
      authorName: "Equipe Compare Mais",
      status: "published",
      isFeatured: article.isFeatured,
      seoTitle: article.seoTitle,
      seoDescription: article.seoDescription,
      publishedAt: Date.now(),
    });
    const articleId = Number(result[0].insertId);
    await db.insert(products).values(article.products.map((product, index) => ({
      articleId,
      name: product.name,
      tagline: product.tagline,
      imageUrl: article.coverImageUrl,
      featuresJson: JSON.stringify(product.features),
      estimatedPrice: null,
      priceNote: "Preço e disponibilidade variam. Consulte a loja.",
      badge: product.badge,
      position: index + 1,
      amazonUrl: product.amazonUrl,
      mercadoLivreUrl: product.mercadoLivreUrl,
    })));
    await db.insert(faqs).values(article.faqs.map((faq, index) => ({
      articleId,
      question: faq.question,
      answer: faq.answer,
      position: index + 1,
    })));
  }
}

seed().then(() => {
  console.log("Conteúdo inicial criado.");
  process.exit(0);
}).catch(error => {
  console.error(error);
  process.exit(1);
});
