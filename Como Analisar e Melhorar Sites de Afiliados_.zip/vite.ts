import express, { type Express } from "express";
import fs from "fs";
import { type Server } from "http";
import path from "path";
import { pathToFileURL } from "node:url";
import { createServer as createViteServer } from "vite";
import viteConfig from "../../vite.config";
import { buildSsrPrefetch } from "./ssrCaller";
import { composeSsrHtml } from "./ssrHtml";

export async function setupVite(app: Express, server: Server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    server: serverOptions,
    appType: "custom",
  });

  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    if (req.originalUrl.startsWith("/api/")) return next();
    const url = req.originalUrl;

    try {
      const clientTemplate = path.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );

      // always reload the index.html file from disk incase it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = await vite.transformIndexHtml(url, template);
      const { render } = await vite.ssrLoadModule("/src/entry-server.tsx");
      const prefetch = await buildSsrPrefetch(req, res);
      const result = await render(url, prefetch);
      const page = composeSsrHtml(template, result, req);
      res.status(result.head.notFound ? 404 : 200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  const distPath =
    process.env.NODE_ENV === "development"
      ? path.resolve(import.meta.dirname, "../..", "dist", "public")
      : path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }

  app.use(express.static(distPath));

  const serverEntry = path.resolve(import.meta.dirname, "server", "entry-server.js");
  let rendererPromise: Promise<{ render: (url: string, prefetch: Awaited<ReturnType<typeof buildSsrPrefetch>>) => Promise<any> }> | null = null;

  app.use("*", async (req, res, next) => {
    if (req.originalUrl.startsWith("/api/")) return next();
    try {
      const template = await fs.promises.readFile(path.resolve(distPath, "index.html"), "utf-8");
      rendererPromise ??= import(pathToFileURL(serverEntry).href);
      const { render } = await rendererPromise;
      const prefetch = await buildSsrPrefetch(req, res);
      const result = await render(req.originalUrl, prefetch);
      const page = composeSsrHtml(template, result, req);
      res.status(result.head.notFound ? 404 : 200).set({ "Content-Type": "text/html" }).end(page);
    } catch (error) {
      next(error);
    }
  });
}
