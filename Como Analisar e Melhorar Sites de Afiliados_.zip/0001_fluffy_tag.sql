CREATE TABLE `affiliateClicks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`articleId` int NOT NULL,
	`productId` int NOT NULL,
	`marketplace` enum('amazon','mercado_livre') NOT NULL,
	`sourcePath` varchar(512),
	`referrer` text,
	`userAgent` text,
	`ipHash` varchar(128),
	`clickedAt` bigint NOT NULL,
	CONSTRAINT `affiliateClicks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `articles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`categoryId` int NOT NULL,
	`title` varchar(240) NOT NULL,
	`slug` varchar(255) NOT NULL,
	`excerpt` text NOT NULL,
	`content` text NOT NULL,
	`coverImageUrl` varchar(1024) NOT NULL,
	`authorName` varchar(120) NOT NULL DEFAULT 'Equipe Compare Mais',
	`status` enum('draft','published') NOT NULL DEFAULT 'draft',
	`isFeatured` boolean NOT NULL DEFAULT false,
	`seoTitle` varchar(180) NOT NULL,
	`seoDescription` varchar(320) NOT NULL,
	`publishedAt` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `articles_id` PRIMARY KEY(`id`),
	CONSTRAINT `articles_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`slug` varchar(140) NOT NULL,
	`description` text NOT NULL,
	`imageUrl` varchar(1024),
	`isFeatured` boolean NOT NULL DEFAULT false,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `categories_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `faqs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`articleId` int NOT NULL,
	`question` varchar(320) NOT NULL,
	`answer` text NOT NULL,
	`position` int NOT NULL DEFAULT 0,
	CONSTRAINT `faqs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`articleId` int NOT NULL,
	`name` varchar(220) NOT NULL,
	`tagline` varchar(280) NOT NULL,
	`imageUrl` varchar(1024) NOT NULL,
	`featuresJson` text NOT NULL,
	`estimatedPrice` decimal(10,2),
	`priceNote` varchar(180) NOT NULL DEFAULT 'Preço estimado; pode variar.',
	`badge` varchar(80),
	`position` int NOT NULL DEFAULT 0,
	`amazonUrl` text,
	`mercadoLivreUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `relatedArticles` (
	`articleId` int NOT NULL,
	`relatedArticleId` int NOT NULL,
	CONSTRAINT `relatedArticles_articleId_relatedArticleId_pk` PRIMARY KEY(`articleId`,`relatedArticleId`)
);
--> statement-breakpoint
ALTER TABLE `affiliateClicks` ADD CONSTRAINT `affiliateClicks_articleId_articles_id_fk` FOREIGN KEY (`articleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `affiliateClicks` ADD CONSTRAINT `affiliateClicks_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `articles` ADD CONSTRAINT `articles_categoryId_categories_id_fk` FOREIGN KEY (`categoryId`) REFERENCES `categories`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `faqs` ADD CONSTRAINT `faqs_articleId_articles_id_fk` FOREIGN KEY (`articleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `products` ADD CONSTRAINT `products_articleId_articles_id_fk` FOREIGN KEY (`articleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `relatedArticles` ADD CONSTRAINT `relatedArticles_articleId_articles_id_fk` FOREIGN KEY (`articleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `relatedArticles` ADD CONSTRAINT `relatedArticles_relatedArticleId_articles_id_fk` FOREIGN KEY (`relatedArticleId`) REFERENCES `articles`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `affiliate_clicks_article_idx` ON `affiliateClicks` (`articleId`);--> statement-breakpoint
CREATE INDEX `affiliate_clicks_product_idx` ON `affiliateClicks` (`productId`);--> statement-breakpoint
CREATE INDEX `affiliate_clicks_marketplace_idx` ON `affiliateClicks` (`marketplace`);--> statement-breakpoint
CREATE INDEX `affiliate_clicks_date_idx` ON `affiliateClicks` (`clickedAt`);--> statement-breakpoint
CREATE INDEX `articles_category_idx` ON `articles` (`categoryId`);--> statement-breakpoint
CREATE INDEX `articles_status_idx` ON `articles` (`status`);--> statement-breakpoint
CREATE INDEX `faqs_article_idx` ON `faqs` (`articleId`);--> statement-breakpoint
CREATE INDEX `products_article_idx` ON `products` (`articleId`);