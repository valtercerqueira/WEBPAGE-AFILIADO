import { AlertCircle, BookOpenCheck, CalendarDays, Check, Clock3, ExternalLink, Info, Scale, ShieldCheck, UserRound } from "lucide-react";
import { Link, useParams } from "wouter";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArticleCard } from "@/components/site/ArticleCard";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { ProductCard } from "@/components/site/ProductCard";
import { trpc } from "@/lib/trpc";
import { articleDisplayTitle, articleTopic, authoritySources, buildSelectionCriteria, expandedFaqs, formatEstimatedPrice, keywordFirstParagraph, methodologyText, parseEditorialContent, resolveAuthor } from "../../../shared/articleTemplate";
import NotFound from "./NotFound";

export default function Article() {
  const params = useParams<{ slug: string }>();
  const isArticlePath = params.slug?.startsWith("melhor-");
  const slug = isArticlePath ? params.slug.slice("melhor-".length) : "pagina-invalida";
  const { data, isLoading, error } = trpc.content.article.useQuery({ slug }, { enabled: isArticlePath });

  if (!isArticlePath) return <NotFound />;
  if (isLoading) return <div className="container py-24"><div className="h-[70vh] animate-pulse rounded-[2rem] bg-black/5" /></div>;
  if (error || !data) return <div className="container py-28 text-center"><AlertCircle className="mx-auto size-10 text-[var(--muted)]" /><h1 className="mt-5 font-display text-4xl">Análise não encontrada</h1><p className="mt-3 text-[var(--muted)]">Este conteúdo pode ter sido movido ou ainda não foi publicado.</p></div>;
  const article = data;
  const { products, related } = data;
  const title = articleDisplayTitle(article);
  const topic = articleTopic(article.slug);
  const editorial = parseEditorialContent(article.content);
  const criteria = buildSelectionCriteria(products);
  const faqs = expandedFaqs(article);
  const author = resolveAuthor(article.authorName);
  const updatedAt = new Date(article.updatedAt ?? article.publishedAt ?? Date.now());
  const publishedAt = new Date(article.publishedAt ?? article.updatedAt ?? Date.now());
  const readingTime = Math.max(5, Math.ceil(`${article.content} ${products.map(product => `${product.name} ${product.tagline} ${product.features.join(" ")}`).join(" ")} ${faqs.map(faq => `${faq.question} ${faq.answer}`).join(" ")}`.split(/\s+/).length / 180));
  const educationalSections = editorial.sections.slice(0, 2);
  const defaultSections = [
    { id: "erros-ao-escolher", title: `Erros comuns ao escolher ${topic}`, body: "Comprar apenas pelo menor preço pode ocultar custos recorrentes, limitações de compatibilidade e manutenção. Compare o que realmente muda entre os modelos e descarte recursos que não atendem à sua rotina." },
    { id: "quando-investir", title: `Quando vale investir mais em ${topic}`, body: "Um valor maior só faz sentido quando entrega um recurso verificável que reduz trabalho, amplia a vida útil ou resolve uma necessidade recorrente. Confirme garantia, assistência, consumíveis e peças antes de pagar pela diferença." },
  ];
  const guideSections = [...educationalSections, ...defaultSections].slice(0, 2);

  return (
    <article>
      <header className="container pt-12 lg:pt-20">
        <Breadcrumbs items={[{ label: article.categoryName, href: `/categoria/${article.categorySlug}` }, { label: article.title }]} />
        <div className="mt-10 grid items-end gap-10 lg:grid-cols-[.88fr_1.12fr]">
          <div className="pb-3">
            <span className="eyebrow">{article.categoryName}</span>
            <h1 className="mt-5 text-balance font-display text-[clamp(3rem,6vw,5.8rem)] leading-[.96] tracking-[-.055em]">{title}</h1>
            <p className="mt-6 text-lg leading-8 text-[var(--muted)]">{keywordFirstParagraph(article)}</p>
            <div className="mt-8 flex flex-wrap gap-5 text-xs font-semibold text-[var(--muted)]"><Link href={author.url} className="flex items-center gap-2 underline decoration-[var(--gold)] underline-offset-4"><UserRound className="size-4" /> Por {author.name}</Link><span className="flex items-center gap-2"><CalendarDays className="size-4" /> Publicado: {publishedAt.toLocaleDateString("pt-BR")} · Atualizado: {updatedAt.toLocaleDateString("pt-BR")}</span><span className="flex items-center gap-2"><Clock3 className="size-4" /> Leitura de {readingTime} min</span></div>
          </div>
          <div className="relative overflow-hidden rounded-[2.5rem] bg-[var(--petrol)]"><img src={article.coverImageUrl} alt={`Comparativo para escolher ${topic}`} className="aspect-[4/3] w-full object-cover" /></div>
        </div>
        <div className="article-scroll mt-10 flex snap-x gap-4 overflow-x-auto pb-3">{products.slice(0, 4).map((product, index) => <a key={product.id} href={`#produto-${product.id}`} className="min-w-[230px] snap-start rounded-2xl bg-white p-4 shadow-[0_12px_36px_rgba(20,45,43,.08)]"><span className="text-[10px] font-bold uppercase tracking-[.14em] text-[var(--muted)]">#{index + 1} {product.badge ?? "Destaque"}</span><strong className="mt-2 block">{product.name}</strong><span className="mt-1 block text-xs text-[var(--muted)]">{product.tagline}</span></a>)}</div>
      </header>

      <div className="container mt-12 grid gap-8 lg:grid-cols-[minmax(0,1fr)_300px] lg:items-start"><div>
        <aside className="flex gap-4 rounded-[1.5rem] border border-[var(--gold)]/35 bg-[#fff9e9] p-5 text-sm leading-6"><Info className="mt-0.5 size-5 shrink-0 text-[#8b6924]" /><p><strong>Como analisamos:</strong> {methodologyText()} <Link href="/metodologia" className="font-bold underline">Leia a metodologia completa.</Link></p></aside>
        <section className="mt-10"><span className="eyebrow">Introdução</span><p className="mt-4 text-lg leading-8 text-[var(--muted)]">{article.excerpt}</p></section>
      </div><nav aria-label="Sumário do artigo" className="rounded-[1.5rem] bg-[var(--petrol)] p-6 text-white lg:sticky lg:top-28"><BookOpenCheck className="size-7 text-[var(--gold)]" /><h2 className="mt-4 font-display text-2xl">Neste guia</h2><ol className="mt-4 grid gap-3 text-sm text-white/75"><li><a href="#comparativo">1. Comparativo rápido</a></li><li><a href="#criterios">2. Como escolher</a></li><li><a href="#produtos">3. Produtos analisados</a></li>{guideSections.map((section, index) => <li key={section.id}><a href={`#${section.id}`}>{index + 4}. {section.title}</a></li>)}<li><a href="#faq">Perguntas frequentes</a></li><li><a href="#fontes">Fontes e autor</a></li></ol></nav></div>

      <section id="comparativo" className="article-anchor container mt-20"><span className="eyebrow">Comparativo rápido</span><h2 className="mt-4 max-w-3xl font-display text-5xl tracking-[-.045em]">Compare antes de abrir a loja</h2><div className="article-scroll mt-8 overflow-x-auto rounded-[1.5rem] bg-white shadow-[0_20px_60px_rgba(20,45,43,.07)]"><table className="article-table"><thead><tr><th>Produto</th><th>Indicado para</th><th>Faixa estimada</th><th>Diferencial principal</th><th>Melhor uso</th></tr></thead><tbody>{products.map(product => <tr key={product.id}><td><a className="font-bold underline decoration-[var(--gold)]" href={`#produto-${product.id}`}>{product.name}</a></td><td>{product.tagline}</td><td>{formatEstimatedPrice(product)}</td><td>{product.features[0] ?? "Confirme na ficha oficial"}</td><td>{product.badge ?? "Comparação geral"}</td></tr>)}</tbody></table></div></section>

      <section id="criterios" className="article-anchor container mt-20"><span className="eyebrow">Como escolher</span><h2 className="mt-4 max-w-3xl font-display text-5xl tracking-[-.045em]">Critérios que mudam a decisão</h2><div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{criteria.map(item => <article key={item.label} className="rounded-[1.5rem] bg-white p-6 shadow-[0_16px_44px_rgba(20,45,43,.06)]"><Scale className="size-6 text-[var(--petrol)]" /><h3 className="mt-4 text-lg font-bold">{item.label}</h3><p className="mt-2 text-sm leading-7 text-[var(--muted)]">{item.explanation}</p></article>)}</div></section>

      <section id="produtos" className="article-anchor container mt-20"><span className="eyebrow">Análises individuais</span><h2 className="mt-4 max-w-3xl font-display text-5xl tracking-[-.045em]">Produtos para considerar</h2><div className="mt-10 grid gap-8">{products.map((product, index) => <ProductCard key={product.id} articleId={article.id} product={product} position={index + 1} topic={topic} />)}</div></section>

      <section className="container mt-24 grid gap-7 lg:grid-cols-2">{guideSections.map(section => <article id={section.id} key={section.id} className="article-anchor rounded-[2rem] bg-[var(--mist)] p-7 md:p-10"><span className="eyebrow">Guia de compra</span><h2 className="mt-4 font-display text-4xl tracking-[-.04em]">{section.title}</h2><p className="mt-5 leading-8 text-[var(--muted)]">{section.body.replace(/\n+/g, " ")}</p></article>)}</section>

      <section id="faq" className="article-anchor container mt-24 max-w-4xl"><div className="text-center"><span className="eyebrow">Dúvidas frequentes</span><h2 className="mt-4 font-display text-5xl tracking-[-.045em]">Perguntas antes de comprar</h2></div><Accordion type="single" collapsible className="mt-10 rounded-[2rem] bg-white px-6 shadow-[0_20px_60px_rgba(20,45,43,.07)] md:px-10">{faqs.map((faq, index) => <AccordionItem key={faq.question} value={`faq-${index}`}><AccordionTrigger className="py-6 text-left text-base font-bold">{faq.question}</AccordionTrigger><AccordionContent className="pb-6 text-sm leading-7 text-[var(--muted)]">{faq.answer}</AccordionContent></AccordionItem>)}</Accordion></section>

      <section id="fontes" className="article-anchor container mt-24 grid gap-7 lg:grid-cols-[.9fr_1.1fr]"><div className="rounded-[2rem] border border-[var(--petrol)]/10 p-7"><span className="eyebrow">Fontes consultadas</span><ul className="mt-5 grid gap-3 text-sm leading-6">{authoritySources(article.categorySlug).map(source => <li key={source.label}>{source.url ? <a href={source.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 font-semibold underline">{source.label}<ExternalLink className="size-4" /></a> : source.label}</li>)}{products.map(product => <li key={product.id}>Ficha e manual oficial a confirmar para {product.name}.</li>)}</ul></div><div className="rounded-[2rem] bg-[var(--petrol)] p-7 text-white"><ShieldCheck className="size-7 text-[var(--gold)]" /><h2 className="mt-4 font-display text-3xl">Sobre o autor</h2><p className="mt-3 font-semibold">{author.name} · {author.jobTitle}</p><p className="mt-4 text-sm leading-7 text-white/70">{author.bio}</p><Link href={author.url} className="mt-5 inline-flex items-center gap-2 font-bold text-[var(--gold)]">Ver perfil editorial <ExternalLink className="size-4" /></Link></div></section>

      <section className="container mt-24"><span className="eyebrow">Continue pesquisando</span><h2 className="mt-4 font-display text-4xl tracking-[-.04em]">6 conteúdos relacionados</h2><div className="mt-8 grid gap-7 md:grid-cols-2 lg:grid-cols-3"><Link href={`/categoria/${article.categorySlug}`} className="rounded-[2rem] bg-[var(--petrol)] p-7 text-white"><Check className="size-6 text-[var(--gold)]" /><span className="mt-10 block text-xs font-bold uppercase tracking-[.14em] text-white/60">Guia da categoria</span><strong className="mt-3 block font-display text-3xl">Mais comparativos de {article.categoryName}</strong></Link>{related.map(item => <ArticleCard key={item.id} article={item} />)}</div></section>
    </article>
  );
}
