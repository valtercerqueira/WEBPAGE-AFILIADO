import { Check, ExternalLink, X } from "lucide-react";
import { formatEstimatedPrice, productLimitations } from "../../../../shared/articleTemplate";

type ProductCardProps = {
  articleId: number;
  product: {
    id: number;
    name: string;
    tagline: string;
    imageUrl: string;
    features: string[];
    estimatedPrice?: string | null;
    priceNote: string;
    badge?: string | null;
    amazonUrl?: string | null;
    mercadoLivreUrl?: string | null;
    updatedAt?: Date | string | number | null;
  };
  position: number;
  topic: string;
};

export function ProductCard({ articleId, product, position, topic }: ProductCardProps) {
  const sourcePath = "";
  const out = (marketplace: "amazon" | "mercado_livre") => `/api/out?articleId=${articleId}&productId=${product.id}&marketplace=${marketplace}&source=${encodeURIComponent(sourcePath)}`;
  const primaryMarketplace = product.mercadoLivreUrl ? "mercado_livre" : product.amazonUrl ? "amazon" : null;
  const limitations = productLimitations(product);
  const updated = product.updatedAt ? new Date(product.updatedAt).toLocaleDateString("pt-BR") : new Date().toLocaleDateString("pt-BR");
  return (
    <article id={`produto-${product.id}`} className="product-card scroll-mt-28">
      <div className="relative overflow-hidden rounded-[1.35rem] bg-[var(--mist)]">
        {product.badge && <span className="absolute left-4 top-4 z-10 rounded-full bg-[var(--petrol)] px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.14em] text-white">{product.badge}</span>}
        {primaryMarketplace ? <a href={out(primaryMarketplace)} target="_blank" rel="nofollow sponsored noopener" aria-label={`Ver ${product.name} na loja`}><img src={product.imageUrl} alt={`${product.name} no comparativo de ${topic}`} loading="lazy" className="aspect-square h-full w-full object-cover" /></a> : <img src={product.imageUrl} alt={`${product.name} no comparativo de ${topic}`} loading="lazy" className="aspect-square h-full w-full object-cover" />}
      </div>
      <div className="flex flex-1 flex-col py-2 md:py-4">
        <p className="text-xs font-bold uppercase tracking-[.14em] text-[var(--muted)]">Recomendado · Atualizado: {updated}</p>
        <h3 className="mt-2 font-display text-3xl leading-tight tracking-[-.03em]">{position}. {product.name}: {product.badge ?? "opção para comparar"}</h3>
        <p className="mt-3 text-sm font-semibold">Confira os detalhes e o preço atual nos nossos parceiros.</p>
        <p className="mt-3 text-sm leading-7 text-[var(--muted)]">{product.tagline} Os recursos abaixo foram organizados a partir do cadastro editorial e devem ser confirmados na ficha oficial do modelo.</p>
        <div className="mt-5 grid gap-5 sm:grid-cols-2">
          <div><h4 className="text-sm font-bold">Prós</h4><ul className="mt-3 grid gap-2.5">{product.features.slice(0, 4).map(feature => <li key={feature} className="flex items-start gap-2 text-sm"><span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-[var(--sage)]/20 text-[var(--petrol)]"><Check className="size-3" /></span>{feature}</li>)}</ul></div>
          <div><h4 className="text-sm font-bold">Contras</h4><ul className="mt-3 grid gap-2.5">{limitations.map(item => <li key={item} className="flex items-start gap-2 text-sm"><span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-red-50 text-red-700"><X className="size-3" /></span>{item}</li>)}</ul></div>
        </div>
        <div className="mt-auto pt-6">
          <div className="mb-4"><span className="text-xs font-bold uppercase tracking-[.14em] text-[var(--muted)]">Faixa estimada</span><p className="mt-1 font-display text-xl">{formatEstimatedPrice(product)}</p><small className="text-xs text-[var(--muted)]">{product.priceNote} Valores não são atualizados em tempo real.</small></div>
          <div className="grid gap-2 sm:grid-cols-2">
            {product.amazonUrl && <a href={out("amazon")} target="_blank" rel="nofollow sponsored noopener" className="cta-amazon">Ver na Amazon <ExternalLink className="size-4" /></a>}
            {product.mercadoLivreUrl && <a href={out("mercado_livre")} target="_blank" rel="nofollow sponsored noopener" className="cta-ml">Ver no Mercado Livre <ExternalLink className="size-4" /></a>}
          </div>
        </div>
      </div>
    </article>
  );
}
