export type TemplateProduct = {
  id?: number;
  name: string;
  tagline: string;
  features: string[];
  estimatedPrice?: string | null;
  priceNote?: string | null;
  badge?: string | null;
  amazonUrl?: string | null;
  mercadoLivreUrl?: string | null;
};

export type TemplateArticle = {
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  categoryName: string;
  categorySlug: string;
  authorName?: string | null;
  seoTitle?: string | null;
  seoDescription?: string | null;
  publishedAt?: number | Date | string | null;
  updatedAt?: number | Date | string | null;
  products: TemplateProduct[];
  faqs: Array<{ question: string; answer: string }>;
};

export type EditorialSection = { title: string; id: string; body: string };

const AUTHORITY_SOURCES: Record<string, Array<{ label: string; url?: string }>> = {
  "casa-e-cozinha": [
    { label: "Programa Brasileiro de Etiquetagem — Inmetro", url: "https://www.gov.br/inmetro/pt-br/assuntos/avaliacao-da-conformidade/programa-brasileiro-de-etiquetagem" },
    { label: "Páginas e manuais oficiais dos fabricantes citados" },
  ],
  eletronicos: [
    { label: "Consulta de produtos homologados — Anatel", url: "https://informacoes.anatel.gov.br/paineis/certificacao-de-produtos/consulta-de-produtos" },
    { label: "Páginas e manuais oficiais dos fabricantes citados" },
  ],
  "beleza-e-saude": [
    { label: "Consultas de cosméticos — Anvisa", url: "https://consultas.anvisa.gov.br/#/cosmeticos/registrados/" },
    { label: "Rótulos e páginas oficiais dos fabricantes citados" },
  ],
  esportes: [
    { label: "Avaliação da conformidade — Inmetro", url: "https://www.gov.br/inmetro/pt-br/assuntos/avaliacao-da-conformidade" },
    { label: "Páginas e fichas técnicas oficiais dos fabricantes citados" },
  ],
  automotivo: [
    { label: "Programa Brasileiro de Etiquetagem — Inmetro", url: "https://www.gov.br/inmetro/pt-br/assuntos/avaliacao-da-conformidade/programa-brasileiro-de-etiquetagem" },
    { label: "Manuais oficiais dos fabricantes citados" },
  ],
};

export function slugifyAnchor(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

export function articleTopic(slug: string) {
  return slug.replace(/^qual-melhor-/, "").replace(/^melhor-/, "").replace(/-/g, " ");
}

export function articleDisplayTitle(article: Pick<TemplateArticle, "slug" | "products" | "updatedAt" | "publishedAt">) {
  const topic = articleTopic(article.slug);
  const date = article.updatedAt ?? article.publishedAt ?? Date.now();
  const year = new Date(date).getFullYear();
  return `Qual o melhor ${topic}? ${article.products.length} opções analisadas em ${year}`;
}

export function articleSeoTitle(article: Pick<TemplateArticle, "slug" | "products" | "updatedAt" | "publishedAt">) {
  const year = new Date(article.updatedAt ?? article.publishedAt ?? Date.now()).getFullYear();
  const title = `Melhor ${articleTopic(article.slug)} em ${year}: ${article.products.length} opções | Compare Mais`;
  return title.length <= 60 ? title : `${title.slice(0, 57).trimEnd()}...`;
}

export function articleSeoDescription(article: Pick<TemplateArticle, "slug" | "products">) {
  const topic = articleTopic(article.slug);
  const base = `Compare ${article.products.length} opções de ${topic} por uso, recursos, limitações e faixa de preço. Veja critérios objetivos, prós e contras antes de comprar.`;
  if (base.length >= 150) return `${base.slice(0, 157).trimEnd().replace(/[.,;:]$/, "")}.`;
  return `${base} Análise editorial transparente e atualizada.`.slice(0, 160);
}

export function keywordFirstParagraph(article: Pick<TemplateArticle, "slug" | "content" | "excerpt">) {
  const topic = articleTopic(article.slug);
  const intro = parseEditorialContent(article.content).intro || article.excerpt;
  return intro.toLowerCase().includes(topic.toLowerCase()) ? intro : `Escolher o melhor ${topic} depende da rotina, dos recursos realmente necessários e dos custos ao longo do uso. ${intro}`;
}

export function parseEditorialContent(content: string) {
  const chunks = content.trim().split(/^##\s+/gm);
  const intro = (chunks.shift() ?? "").trim();
  const sections: EditorialSection[] = chunks.map(chunk => {
    const [heading, ...body] = chunk.trim().split("\n");
    return { title: heading.trim(), id: slugifyAnchor(heading), body: body.join("\n").trim() };
  }).filter(section => section.title && section.body);
  return { intro, sections };
}

export function buildSelectionCriteria(products: TemplateProduct[]) {
  const features = products.flatMap(product => product.features).filter((feature, index, all) => all.findIndex(item => item.toLowerCase() === feature.toLowerCase()) === index).slice(0, 6);
  const fallbacks = ["Adequação ao uso", "Facilidade de manutenção", "Disponibilidade de peças", "Custo total", "Dimensões e instalação", "Garantia do fabricante"];
  return [...features, ...fallbacks].slice(0, 6).map(label => ({
    label,
    explanation: `Compare como cada modelo atende a “${label.toLowerCase()}” e confirme o dado na página ou no manual oficial antes da compra.`,
  }));
}

export function methodologyText() {
  return "Esta é uma seleção e análise editorial baseada nas especificações publicadas pelos fabricantes, em fontes regulatórias aplicáveis e na adequação declarada a diferentes perfis de uso. Não realizamos teste físico ou medição laboratorial destes itens; preços, estoque e características devem ser confirmados na loja e no manual oficial.";
}

export function formatEstimatedPrice(product: TemplateProduct) {
  if (!product.estimatedPrice) return "Faixa não informada · confirme na loja";
  const value = Number(product.estimatedPrice);
  if (!Number.isFinite(value)) return "Faixa não informada · confirme na loja";
  return `${value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })} estimados · confirme na loja`;
}

export function productLimitations(product: TemplateProduct) {
  const limitations = ["Preço e disponibilidade podem mudar sem aviso."];
  const destinations = [product.amazonUrl, product.mercadoLivreUrl].filter(Boolean) as string[];
  if (destinations.some(url => url.includes("/s?") || url.includes("lista.mercadolivre.com.br"))) {
    limitations.push("O link disponível leva a uma busca; confirme modelo, vendedor e SKU antes de comprar.");
  }
  if (!product.estimatedPrice) limitations.push("O cadastro ainda não possui uma faixa de preço verificável.");
  return limitations.slice(0, 3);
}

export function authoritySources(categorySlug: string) {
  return AUTHORITY_SOURCES[categorySlug] ?? [
    { label: "Avaliação da conformidade — Inmetro", url: "https://www.gov.br/inmetro/pt-br/assuntos/avaliacao-da-conformidade" },
    { label: "Páginas e manuais oficiais dos fabricantes citados" },
  ];
}

export function hasVerifiableAuthoritySource(categorySlug: string) {
  const registeredSources = AUTHORITY_SOURCES[categorySlug];
  if (!registeredSources) return false;
  return registeredSources.some(source => {
    if (!source.url) return false;
    try {
      const url = new URL(source.url);
      return url.protocol === "https:" && Boolean(url.hostname);
    } catch {
      return false;
    }
  });
}

export function resolveAuthor(authorName?: string | null) {
  const generic = !authorName || /equipe compare mais/i.test(authorName);
  return {
    name: generic ? "Valter" : authorName,
    jobTitle: "Responsável editorial e proprietário do Compare Mais",
    url: "/autor/valter",
    bio: "Coordena a curadoria dos comparativos e a revisão dos critérios de compra. As páginas distinguem análise documental de teste físico e não publicam avaliações ou notas inventadas.",
  };
}

export function expandedFaqs(article: Pick<TemplateArticle, "slug" | "products" | "faqs">) {
  const topic = articleTopic(article.slug);
  const generated = [
    { question: `Como escolher ${topic}?`, answer: `Defina o perfil de uso, compare os critérios técnicos relevantes e confirme dimensões, garantia, manutenção e compatibilidade no manual oficial antes da compra.` },
    { question: `O produto mais caro é sempre a melhor escolha de ${topic}?`, answer: "Não. O melhor custo-benefício depende do uso real, da frequência, dos custos recorrentes e dos recursos que você de fato utilizará." },
    { question: "Os preços desta página são atualizados em tempo real?", answer: "Não. As faixas são apenas referências editoriais e podem mudar. O valor válido é o exibido pela loja no momento da compra." },
    { question: "Os links desta página são afiliados?", answer: "Alguns links podem gerar comissão para o Compare Mais sem custo adicional para você. Isso não autoriza avaliações, notas ou testes inventados." },
    { question: "O Compare Mais testou fisicamente estes produtos?", answer: "Não neste comparativo. A análise é documental, baseada em especificações publicadas, fontes aplicáveis e adequação declarada a diferentes perfis de uso." },
    { question: `Quantas opções de ${topic} foram comparadas?`, answer: `Esta página organiza ${article.products.length} opções cadastradas. A disponibilidade e o catálogo podem mudar ao longo do tempo.` },
  ];
  const merged = [...article.faqs, ...generated].filter((faq, index, all) => all.findIndex(item => item.question.toLowerCase() === faq.question.toLowerCase()) === index);
  return merged.slice(0, 8);
}

export function directMarketplaceUrl(url?: string | null) {
  if (!url) return false;
  return !url.includes("amazon.com.br/s?") && !url.includes("lista.mercadolivre.com.br");
}

export function publicationIssues(article: Pick<TemplateArticle, "slug" | "title" | "excerpt" | "content" | "categorySlug" | "authorName" | "seoTitle" | "seoDescription" | "products" | "faqs">) {
  const issues: string[] = [];
  const topic = articleTopic(article.slug).toLowerCase();
  const firstParagraph = article.content.split(/\n\s*\n/)[0]?.toLowerCase() ?? "";
  if (!article.slug.startsWith("melhor-") && !article.slug.startsWith("qual-melhor-")) issues.push("O slug deve começar com a keyword principal.");
  if (!article.title.toLowerCase().includes("melhor")) issues.push("O H1 deve conter a keyword principal.");
  if (!firstParagraph.includes(topic.split(" ")[0])) issues.push("O primeiro parágrafo deve conter a keyword principal.");
  if (!article.seoTitle || article.seoTitle.length > 60) issues.push("O title deve ter no máximo 60 caracteres.");
  if (!article.seoDescription || article.seoDescription.length < 150 || article.seoDescription.length > 160) issues.push("A meta description deve ter entre 150 e 160 caracteres.");
  if (!article.authorName || /equipe compare mais/i.test(article.authorName)) issues.push("Informe um autor real em vez de uma equipe genérica.");
  if (!hasVerifiableAuthoritySource(article.categorySlug)) issues.push("Inclua ao menos uma fonte oficial identificada com URL HTTPS verificável.");
  if (article.faqs.length < 5 || article.faqs.length > 8) issues.push("Inclua entre 5 e 8 perguntas frequentes.");
  if (article.products.length < 2) issues.push("Inclua pelo menos dois produtos comparáveis.");
  if (article.products.some(product => !product.estimatedPrice)) issues.push("Informe uma faixa ou preço estimado verificável para cada produto.");
  if (article.products.some(product => !directMarketplaceUrl(product.amazonUrl) && !directMarketplaceUrl(product.mercadoLivreUrl))) issues.push("Cada produto precisa de pelo menos um link direto para o SKU, não uma busca.");
  if (/\{\{|\bplaceholder\b/i.test(`${article.title} ${article.excerpt} ${article.content}`)) issues.push("Remova placeholders antes da publicação.");
  if (/\b(testamos|medimos|teste laboratorial)\b/i.test(article.content)) issues.push("Alegações de teste ou medição exigem evidência real e não podem ser publicadas neste cadastro.");
  return issues;
}
