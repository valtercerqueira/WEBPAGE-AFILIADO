import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";

export type ArticleCardData = {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  coverImageUrl: string;
  categoryName: string;
  publishedAt?: number | null;
};

export function ArticleCard({ article, large = false }: { article: ArticleCardData; large?: boolean }) {
  return (
    <article className={`group overflow-hidden rounded-[1.75rem] bg-white shadow-[0_18px_55px_rgba(20,45,43,.08)] ${large ? "md:grid md:grid-cols-[1.15fr_.85fr]" : ""}`}>
      <Link href={`/${article.slug}`} className={`block overflow-hidden ${large ? "min-h-[360px]" : "aspect-[4/3]"}`}>
        <span className="sr-only">Abrir análise: {article.title}</span>
        <img src={article.coverImageUrl} alt="" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.035]" />
      </Link>
      <div className={`flex flex-col ${large ? "justify-center p-8 lg:p-12" : "p-6"}`}>
        <span className="eyebrow">{article.categoryName}</span>
        <h3 className={`${large ? "mt-5 font-display text-4xl" : "mt-3 font-display text-2xl"} text-balance leading-[1.08] tracking-[-.035em]`}>
          <Link href={`/${article.slug}`}>{article.title}</Link>
        </h3>
        <p className="mt-4 line-clamp-3 text-sm leading-7 text-[var(--muted)]">{article.excerpt}</p>
        <Link href={`/${article.slug}`} className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-[var(--petrol)]">Ler análise <ArrowUpRight className="size-4 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></Link>
      </div>
    </article>
  );
}
