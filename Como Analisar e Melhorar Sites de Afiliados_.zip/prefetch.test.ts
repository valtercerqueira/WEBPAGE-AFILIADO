import { describe, expect, it } from "vitest";
import { articleSchemas } from "./prefetch";

describe("schemas estruturados de artigo", () => {
  it("gera Article, BreadcrumbList, ItemList e FAQPage em um único @graph", () => {
    const schemas = articleSchemas({
      id: 1,
      categoryId: 2,
      title: "Melhor cafeteira",
      slug: "melhor-cafeteira",
      excerpt: "Resumo editorial",
      content: "Conteúdo editorial",
      coverImageUrl: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd",
      authorName: "Equipe Compare Mais",
      seoTitle: "Melhor cafeteira",
      seoDescription: "Descrição de busca",
      publishedAt: 1710000000000,
      updatedAt: 1711000000000,
      categoryName: "Casa e Cozinha",
      categorySlug: "casa-e-cozinha",
      products: [],
      faqs: [{ id: 1, articleId: 1, question: "Qual capacidade escolher?", answer: "Considere o número de doses diárias.", position: 0, createdAt: 1710000000000, updatedAt: 1710000000000 }],
      related: [],
    } as never);

    expect(schemas).toHaveLength(1);
    const graph = schemas[0]["@graph"] as Array<Record<string, unknown>>;
    expect(graph.map(schema => schema["@type"])).toEqual(["Article", "BreadcrumbList", "ItemList", "FAQPage"]);
    expect((graph[1] as { itemListElement: unknown[] }).itemListElement).toHaveLength(3);
    expect((graph[3] as { mainEntity: unknown[] }).mainEntity.length).toBeGreaterThanOrEqual(5);
  });
});
