import mysql from "mysql2/promise";

export type DatabaseDiagnosticCategory =
  | "connected"
  | "disabled"
  | "not_configured"
  | "access_denied"
  | "database_not_found"
  | "host_not_allowed"
  | "network_refused"
  | "network_timeout"
  | "dns_not_found"
  | "unknown";

export type DatabaseDiagnostic = {
  enabled: boolean;
  configured: boolean;
  ok: boolean;
  category: DatabaseDiagnosticCategory;
  code: string | null;
  errno: number | null;
  sqlState: string | null;
};

type MysqlErrorShape = {
  code?: unknown;
  errno?: unknown;
  sqlState?: unknown;
};

const CATEGORY_BY_CODE: Record<string, DatabaseDiagnosticCategory> = {
  ER_ACCESS_DENIED_ERROR: "access_denied",
  ER_BAD_DB_ERROR: "database_not_found",
  ER_HOST_NOT_PRIVILEGED: "host_not_allowed",
  ECONNREFUSED: "network_refused",
  ETIMEDOUT: "network_timeout",
  ENOTFOUND: "dns_not_found",
};

export function sanitizeDatabaseError(error: unknown): Pick<DatabaseDiagnostic, "category" | "code" | "errno" | "sqlState"> {
  const source = error && typeof error === "object" ? (error as MysqlErrorShape) : {};
  const code = typeof source.code === "string" ? source.code.slice(0, 80) : null;
  const errno = typeof source.errno === "number" && Number.isFinite(source.errno) ? source.errno : null;
  const sqlState = typeof source.sqlState === "string" ? source.sqlState.slice(0, 20) : null;

  return {
    category: code ? (CATEGORY_BY_CODE[code] ?? "unknown") : "unknown",
    code,
    errno,
    sqlState,
  };
}

export async function diagnoseDatabaseConnection(): Promise<DatabaseDiagnostic> {
  const enabled = process.env.DB_DIAGNOSTICS_ENABLED === "true";
  const databaseUrl = process.env.DATABASE_URL;

  if (!enabled) {
    return {
      enabled: false,
      configured: Boolean(databaseUrl),
      ok: false,
      category: "disabled",
      code: null,
      errno: null,
      sqlState: null,
    };
  }

  if (!databaseUrl) {
    return {
      enabled: true,
      configured: false,
      ok: false,
      category: "not_configured",
      code: null,
      errno: null,
      sqlState: null,
    };
  }

  let connection: mysql.Connection | null = null;
  try {
    connection = await mysql.createConnection({
      uri: databaseUrl,
      connectTimeout: 5_000,
    });
    await connection.query("SELECT 1 AS ok");
    return {
      enabled: true,
      configured: true,
      ok: true,
      category: "connected",
      code: "OK",
      errno: null,
      sqlState: null,
    };
  } catch (error) {
    return {
      enabled: true,
      configured: true,
      ok: false,
      ...sanitizeDatabaseError(error),
    };
  } finally {
    await connection?.end().catch(() => undefined);
  }
}
