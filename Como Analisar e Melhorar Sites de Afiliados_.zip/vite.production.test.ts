import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

import { createPlugins } from "../vite.config";

describe("Vite production plugins", () => {
  it("excludes the JSX location development plugin from production builds", () => {
    const getPluginNames = (plugins: unknown[]) =>
      plugins
        .flat(Infinity)
        .map((plugin) =>
          plugin && typeof plugin === "object" && "name" in plugin
            ? String(plugin.name)
            : "",
        )
        .filter(Boolean);

    const productionPluginNames = getPluginNames(createPlugins(false));
    const developmentPluginNames = getPluginNames(createPlugins(true));

    expect(developmentPluginNames.some((name) => name.includes("jsx"))).toBe(true);
    expect(productionPluginNames.some((name) => name.includes("jsx-loc"))).toBe(false);
  });

  it("forces NODE_ENV=production for every production bundle command", () => {
    const packageJson = JSON.parse(
      readFileSync(new URL("../package.json", import.meta.url), "utf8"),
    ) as { scripts: { build: string } };

    const productionAssignments = packageJson.scripts.build.match(
      /NODE_ENV=production/g,
    );

    expect(productionAssignments).toHaveLength(3);
  });
});
