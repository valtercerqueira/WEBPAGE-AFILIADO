import { beforeEach, describe, expect, it, vi } from "vitest";
import { articles } from "../drizzle/schema";

vi.mock("./db", () => ({ getDb: vi.fn() }));

import { getAdminArticle, saveArticle, type ArticleEditorInput } from "./admin";
import { getDb } from "./db";

describe("persistência do resumo rápido", () => {
  let persisted: Record<string, unknown>;

  beforeEach(() => {
    persisted = { id: 7 };

    const transaction = vi.fn(async callback => callback({
      update: vi.fn(() => ({
        set: vi.fn((values: Record<string, unknown>) => ({
          where: vi.fn(async () => {
            persisted = { ...persisted, ...values };
          }),
        })),
      })),
      delete: vi.fn(() => ({ where: vi.fn(async () => undefined) })),
      insert: vi.fn(() => ({ values: vi.fn(async () => [{ insertId: 7 }]) })),
    }));

    const select = vi.fn(() => ({
      from: vi.fn((table: unknown) => table === articles
        ? { where: vi.fn(() => ({ limit: vi.fn(async () => [persisted]) })) }
        : { where: vi.fn(() => ({ orderBy: vi.fn(async () => []) })) }),
    }));

    vi.mocked(getDb).mockResolvedValue({ transaction, select } as never);
  });

  it("salva listas como JSON e as devolve novamente como arrays", async () => {
    const input: ArticleEditorInput = {
      id: 7,
      categoryId: 1,
      title: "Melhores cafeteiras para comprar",
      slug: "melhor-cafeteira",
      excerpt: "Comparativo editorial para orientar a escolha.",
      content: "Conteúdo editorial completo.",
      coverImageUrl: "https://example.com/cafeteira.jpg",
      authorName: "Equipe Compare Mais",
      status: "published",
      isFeatured: true,
      seoTitle: "Melhores cafeteiras",
      seoDescription: "Compare os principais critérios antes da compra.",
      quickSummary: "  Síntese objetiva para orientar a leitura do comparativo.  ",
      quickPros: [" Fácil manutenção ", "Critérios claros", ""],
      quickCons: [" Confirmar o preço na loja ", "Exige avaliar a rotina"],
      quickSummaryModel: " gpt-5-mini ",
      quickSummaryGeneratedAt: 1710000000000,
      products: [],
      faqs: [],
    };

    await saveArticle(input);

    expect(persisted).toMatchObject({
      quickSummary: "Síntese objetiva para orientar a leitura do comparativo.",
      quickProsJson: JSON.stringify(["Fácil manutenção", "Critérios claros"]),
      quickConsJson: JSON.stringify(["Confirmar o preço na loja", "Exige avaliar a rotina"]),
      quickSummaryModel: "gpt-5-mini",
      quickSummaryGeneratedAt: 1710000000000,
    });

    const reloaded = await getAdminArticle(7);
    expect(reloaded?.quickPros).toEqual(["Fácil manutenção", "Critérios claros"]);
    expect(reloaded?.quickCons).toEqual(["Confirmar o preço na loja", "Exige avaliar a rotina"]);
    expect(reloaded?.quickSummary).toBe("Síntese objetiva para orientar a leitura do comparativo.");
  });
});
