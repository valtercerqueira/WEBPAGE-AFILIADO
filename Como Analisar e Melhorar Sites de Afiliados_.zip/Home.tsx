import { ArrowRight, Compass, Search, Sparkles } from "lucide-react";
import { FormEvent, useState } from "react";
import { Link, useLocation } from "wouter";
import { ArticleCard } from "@/components/site/ArticleCard";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { data, isLoading } = trpc.content.home.useQuery();
  const [query, setQuery] = useState("");
  const [, navigate] = useLocation();
  const hero = data?.featured[0] ?? data?.latest[0];

  function search(event: FormEvent) {
    event.preventDefault();
    if (query.trim().length >= 2) navigate(`/busca?q=${encodeURIComponent(query.trim())}`);
  }

  if (isLoading) return <HomeSkeleton />;

  return (
    <>
      <section className="relative overflow-hidden pb-20 pt-16 lg:pb-28 lg:pt-24">
        <div className="pointer-events-none absolute -right-40 -top-48 size-[560px] rounded-full bg-[var(--sage)]/18 blur-3xl" />
        <div className="container relative grid items-center gap-14 lg:grid-cols-[.88fr_1.12fr]">
          <div className="relative z-10">
            <span className="eyebrow inline-flex items-center gap-2"><Sparkles className="size-3.5" /> Escolhas sem ruído</span>
            <h1 className="mt-7 max-w-2xl font-display text-[clamp(3.4rem,7vw,6.8rem)] leading-[.92] tracking-[-.055em]">Compare melhor.<br /><em className="font-normal text-[var(--petrol)]">Compre consciente.</em></h1>
            <p className="mt-7 max-w-xl text-base leading-8 text-[var(--muted)] lg:text-lg">Análises objetivas, critérios claros e comparativos úteis para você decidir sem depender de propaganda.</p>
            <form onSubmit={search} className="mt-9 flex max-w-xl items-center rounded-full bg-white p-2 shadow-[0_18px_60px_rgba(20,45,43,.12)]">
              <Search className="ml-4 size-5 text-[var(--muted)]" />
              <input value={query} onChange={event => setQuery(event.target.value)} placeholder="O que você quer comparar?" aria-label="Buscar produtos e análises" className="min-w-0 flex-1 bg-transparent px-3 py-3 text-sm outline-none" />
              <button className="rounded-full bg-[var(--petrol)] px-5 py-3 text-sm font-bold text-white">Buscar</button>
            </form>
            <div className="mt-8 flex flex-wrap gap-x-8 gap-y-3 text-xs font-semibold text-[var(--muted)]"><span className="flex items-center gap-2"><Compass className="size-4 text-[var(--petrol)]" /> Critérios transparentes</span><span className="flex items-center gap-2"><Sparkles className="size-4 text-[var(--gold)]" /> Curadoria editorial</span></div>
          </div>

          {hero && (
            <Link href={`/${hero.slug}`} className="group relative block min-h-[540px] overflow-hidden rounded-[2.5rem] bg-[var(--petrol)] shadow-[0_35px_90px_rgba(20,45,43,.2)]">
              <img src={hero.coverImageUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-75 transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0d2926] via-[#0d2926]/20 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-8 text-white md:p-12">
                <span className="inline-flex rounded-full bg-white/15 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.15em] backdrop-blur">Em destaque</span>
                <h2 className="mt-5 max-w-xl font-display text-4xl leading-[1.05] tracking-[-.04em] md:text-5xl">{hero.title}</h2>
                <span className="mt-6 inline-flex items-center gap-2 text-sm font-bold">Ver análise <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" /></span>
              </div>
            </Link>
          )}
        </div>
      </section>

      <section className="border-y border-black/8 bg-white/55 py-16">
        <div className="container">
          <div className="mb-8 flex items-end justify-between gap-4"><div><span className="eyebrow">Explore por interesse</span><h2 className="mt-3 font-display text-4xl tracking-[-.04em]">Categorias essenciais</h2></div></div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {data?.categories.map((category, index) => (
              <Link key={category.id} href={`/categoria/${category.slug}`} className={`group relative min-h-52 overflow-hidden rounded-[1.5rem] p-5 ${index === 0 ? "lg:col-span-2" : ""}`}>
                {category.imageUrl && <img src={category.imageUrl} alt="" className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="relative flex h-full items-end"><div><span className="text-[10px] font-bold uppercase tracking-[.15em] text-white/65">Categoria</span><h3 className="mt-2 font-display text-2xl text-white">{category.name}</h3></div></div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {data?.featured && data.featured.length > 1 && (
        <section className="py-20">
          <div className="container"><span className="eyebrow">Seleção editorial</span><div className="mt-5 overflow-x-auto pb-6"><div className="grid w-max grid-cols-[repeat(3,minmax(310px,390px))] gap-6">{data.featured.slice(1, 4).map(article => <ArticleCard key={article.id} article={article} />)}</div></div></div>
        </section>
      )}

      <section className="py-20 lg:py-28">
        <div className="container">
          <div className="mb-10 flex items-end justify-between gap-5"><div><span className="eyebrow">Recém-publicados</span><h2 className="mt-3 font-display text-5xl tracking-[-.045em]">Últimas análises</h2></div><Link href="/busca?q=melhor" className="hidden items-center gap-2 text-sm font-bold sm:flex">Ver todas <ArrowRight className="size-4" /></Link></div>
          <div className="grid gap-7 md:grid-cols-2 lg:grid-cols-3">{data?.latest.map(article => <ArticleCard key={article.id} article={article} />)}</div>
        </div>
      </section>
    </>
  );
}

function HomeSkeleton() { return <div className="container py-24"><div className="h-[580px] animate-pulse rounded-[2.5rem] bg-black/5" /><div className="mt-10 grid gap-6 md:grid-cols-3">{[1,2,3].map(item => <div key={item} className="h-96 animate-pulse rounded-[2rem] bg-black/5" />)}</div></div>; }
