import {
  bigint,
  boolean,
  decimal,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  primaryKey,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
  description: text("description").notNull(),
  imageUrl: varchar("imageUrl", { length: 1024 }),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const articles = mysqlTable(
  "articles",
  {
    id: int("id").autoincrement().primaryKey(),
    categoryId: int("categoryId")
      .notNull()
      .references(() => categories.id, { onDelete: "restrict" }),
    title: varchar("title", { length: 240 }).notNull(),
    slug: varchar("slug", { length: 255 }).notNull().unique(),
    excerpt: text("excerpt").notNull(),
    content: text("content").notNull(),
    coverImageUrl: varchar("coverImageUrl", { length: 1024 }).notNull(),
    authorName: varchar("authorName", { length: 120 }).default("Equipe Compare Mais").notNull(),
    status: mysqlEnum("status", ["draft", "published"]).default("draft").notNull(),
    isFeatured: boolean("isFeatured").default(false).notNull(),
    seoTitle: varchar("seoTitle", { length: 180 }).notNull(),
    seoDescription: varchar("seoDescription", { length: 320 }).notNull(),
    quickSummary: text("quickSummary"),
    quickProsJson: text("quickProsJson"),
    quickConsJson: text("quickConsJson"),
    quickSummaryModel: varchar("quickSummaryModel", { length: 120 }),
    quickSummaryGeneratedAt: bigint("quickSummaryGeneratedAt", { mode: "number" }),
    publishedAt: bigint("publishedAt", { mode: "number" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("articles_category_idx").on(table.categoryId), index("articles_status_idx").on(table.status)],
);

export const products = mysqlTable(
  "products",
  {
    id: int("id").autoincrement().primaryKey(),
    articleId: int("articleId")
      .notNull()
      .references(() => articles.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 220 }).notNull(),
    tagline: varchar("tagline", { length: 280 }).notNull(),
    imageUrl: varchar("imageUrl", { length: 1024 }).notNull(),
    featuresJson: text("featuresJson").notNull(),
    estimatedPrice: decimal("estimatedPrice", { precision: 10, scale: 2 }),
    priceNote: varchar("priceNote", { length: 180 }).default("Preço estimado; pode variar.").notNull(),
    badge: varchar("badge", { length: 80 }),
    position: int("position").default(0).notNull(),
    amazonUrl: text("amazonUrl"),
    mercadoLivreUrl: text("mercadoLivreUrl"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("products_article_idx").on(table.articleId)],
);

export const faqs = mysqlTable(
  "faqs",
  {
    id: int("id").autoincrement().primaryKey(),
    articleId: int("articleId")
      .notNull()
      .references(() => articles.id, { onDelete: "cascade" }),
    question: varchar("question", { length: 320 }).notNull(),
    answer: text("answer").notNull(),
    position: int("position").default(0).notNull(),
  },
  table => [index("faqs_article_idx").on(table.articleId)],
);

export const relatedArticles = mysqlTable(
  "relatedArticles",
  {
    articleId: int("articleId")
      .notNull()
      .references(() => articles.id, { onDelete: "cascade" }),
    relatedArticleId: int("relatedArticleId")
      .notNull()
      .references(() => articles.id, { onDelete: "cascade" }),
  },
  table => [primaryKey({ columns: [table.articleId, table.relatedArticleId] })],
);

export const affiliateClicks = mysqlTable(
  "affiliateClicks",
  {
    id: int("id").autoincrement().primaryKey(),
    articleId: int("articleId")
      .notNull()
      .references(() => articles.id, { onDelete: "cascade" }),
    productId: int("productId")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    marketplace: mysqlEnum("marketplace", ["amazon", "mercado_livre"]).notNull(),
    sourcePath: varchar("sourcePath", { length: 512 }),
    referrer: text("referrer"),
    userAgent: text("userAgent"),
    ipHash: varchar("ipHash", { length: 128 }),
    clickedAt: bigint("clickedAt", { mode: "number" }).notNull(),
  },
  table => [
    index("affiliate_clicks_article_idx").on(table.articleId),
    index("affiliate_clicks_product_idx").on(table.productId),
    index("affiliate_clicks_marketplace_idx").on(table.marketplace),
    index("affiliate_clicks_date_idx").on(table.clickedAt),
  ],
);

export type Category = typeof categories.$inferSelect;
export type Article = typeof articles.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Faq = typeof faqs.$inferSelect;
export type AffiliateClick = typeof affiliateClicks.$inferSelect;
