import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Article from "./pages/Article";
import Category from "./pages/Category";
import SearchPage from "./pages/Search";
import { SiteShell } from "./components/site/SiteShell";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminArticleEditor from "./pages/admin/AdminArticleEditor";
import Methodology from "./pages/Methodology";
import Author from "./pages/Author";

function Router() {
  return (
    <Switch>
      <Route path="/">{() => <SiteShell><Home /></SiteShell>}</Route>
      <Route path="/categoria/:slug">{() => <SiteShell><Category /></SiteShell>}</Route>
      <Route path="/busca">{() => <SiteShell><SearchPage /></SiteShell>}</Route>
      <Route path="/metodologia">{() => <SiteShell><Methodology /></SiteShell>}</Route>
      <Route path="/autor/valter">{() => <SiteShell><Author /></SiteShell>}</Route>
      <Route path="/admin/artigo/:id" component={AdminArticleEditor} />
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/:slug">{() => <SiteShell><Article /></SiteShell>}</Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
