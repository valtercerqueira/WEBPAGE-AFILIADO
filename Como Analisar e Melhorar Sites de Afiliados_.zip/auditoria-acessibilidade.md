# Auditoria de acessibilidade

## Escopo

Auditoria executada na página publicada localmente em `http://127.0.0.1:3000/melhor-cafeteira`, com viewport desktop e conteúdo SSR ativo.

## Primeira execução

O Lighthouse registrou pontuação **0,89** e apontou três falhas objetivas: restrição de zoom por `maximum-scale=1`, link de imagem de artigo relacionado sem nome discernível e nome acessível da marca divergente do texto visível.

## Correções aplicadas

O viewport passou a permitir zoom; o link visual do `ArticleCard` recebeu texto exclusivo para leitores de tela; o link da marca passou a derivar seu nome acessível do conteúdo visível. Também foram adicionados `aria-expanded`, `aria-controls` e rótulo dinâmico ao botão do menu mobile, além de rótulo explícito à busca mobile.

## Verificações manuais

A estrutura do artigo contém um único `h1`, títulos de seção em ordem semântica, disclaimer editorial visível antes dos produtos, CTAs com nomes discerníveis (`Ver na Amazon` e `Ver no Mercado Livre`), botões de FAQ nomeados e campo de busca rotulado. A ordem de foco segue cabeçalho, conteúdo, CTAs, FAQ e rodapé.

## Evidência automatizada

O relatório bruto final está em `a11y-lighthouse.json`. A reexecução após as correções obteve pontuação **1,00 (100/100)** na categoria Accessibility do Lighthouse, sem auditorias reprovadas. A mesma rodada executou **10 testes Vitest em 5 arquivos**, todos aprovados, e `tsc --noEmit`, sem erros.
