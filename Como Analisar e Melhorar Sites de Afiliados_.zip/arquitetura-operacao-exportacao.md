# Compare Mais — arquitetura, operação editorial e exportação

**Autor:** Manus AI  
**Data:** 16 de julho de 2026

## 1. Arquitetura entregue

O Compare Mais é uma aplicação editorial SSR. O runtime real não é um projeto Next.js: ele usa **React 19 + Vite 7** no frontend, **Express 4** no servidor, **tRPC** como contrato tipado, **Drizzle ORM** sobre MySQL/TiDB e autenticação administrativa pelo OAuth do Manus. Essa decisão preserva renderização server-side, metadados rastreáveis e uma única aplicação Node.js para páginas, APIs e painel.

| Camada | Implementação | Responsabilidade |
|---|---|---|
| Interface pública | React, Tailwind CSS e componentes Radix | Homepage, categorias, busca, artigo e CTAs afiliados |
| Renderização | Vite SSR + `renderToString` | HTML rastreável, hidratação e dados pré-carregados |
| Servidor | Express | SSR, arquivos estáticos, OAuth, tRPC, SEO e redirecionamento afiliado |
| Contratos | tRPC + Zod | Consultas públicas e operações administrativas validadas |
| Persistência | Drizzle ORM + MySQL/TiDB | Artigos, categorias, produtos, FAQs e cliques |
| Administração | Manus OAuth + controle de papel `admin` | Restringir criação e edição de conteúdo |
| SEO técnico | SSR, canonical, Open Graph, Twitter Cards, JSON-LD, sitemap e robots | Indexação e apresentação consistente em buscadores |

Em produção, `pnpm build` gera os arquivos do cliente em `dist/public`, o renderer SSR em `dist/server` e o servidor Node.js em `dist/index.js`. O comando `pnpm start` inicia esse servidor usando a variável `PORT` fornecida pela plataforma.

## 2. Fluxo editorial

O painel `/admin` é `noindex,nofollow` e exige usuário autenticado com papel `admin`. O fluxo operacional recomendado é publicar apenas conteúdo que tenha intenção de busca definida, critérios verificáveis e links afiliados válidos.

| Etapa | Ação operacional | Critério de saída |
|---|---|---|
| 1. Categoria | Criar ou selecionar a categoria e sua descrição | Slug curto, descrição útil e posição definida |
| 2. Artigo | Preencher título, resumo, corpo, autor e imagem | Título responde à intenção e conteúdo não depende de JavaScript |
| 3. Produtos | Adicionar características, observação de preço e URLs | URLs limitadas à Amazon Brasil e Mercado Livre |
| 4. FAQs | Inserir perguntas reais do processo de compra | Respostas objetivas e coerentes com o artigo |
| 5. SEO | Revisar título SEO e descrição | Canonical correto, uma tag `h1` e descrição específica |
| 6. Publicação | Alterar status de rascunho para publicado | Página aparece no sitemap e nas listagens públicas |
| 7. Medição | Acompanhar cliques por artigo, produto e marketplace | CTR analisado sem alterar ou mascarar o destino do usuário |

> O disclaimer de transparência deve permanecer visível antes dos blocos comerciais. Preço não é tratado como promessa: a interface orienta o leitor a consultar a loja.

## 3. SEO e domínio

Configure `CANONICAL_ORIGIN` com a origem pública definitiva, por exemplo `https://comparemais.com.br`, sem barra final. Sem essa variável, o servidor deriva canonicals do host da requisição; isso é aceitável em desenvolvimento, mas inadequado para ambientes temporários ou proxies.

As páginas de artigo incluem `Article`, `FAQPage` e `BreadcrumbList` em JSON-LD. Busca e painel usam `noindex,nofollow`. O sitemap inclui a homepage, categorias e artigos publicados, enquanto `robots.txt` bloqueia `/admin` e `/busca`.

## 4. Implantação recomendada no Manus

O caminho de menor risco é usar a hospedagem integrada do Manus e associar o domínio pela área **Settings → Domains**. Essa opção preserva banco, OAuth, storage e segredos já conectados. Após cada alteração validada, salve um checkpoint e use o botão **Publish** na interface.

## 5. Exportação para Hostinger

A Hostinger documenta suporte gerenciado a aplicações React, Vite e Express.js nos planos Business e Cloud, com implantação por GitHub, ZIP ou Connector e runtimes Node.js 18, 20, 22 e 24.[1] O fluxo via GitHub permite build e redeploy automáticos.[1] [2]

| Configuração no hPanel | Valor para este projeto |
|---|---|
| Tipo/preset | Express.js; se não detectado, `Other` |
| Node.js | 22.x |
| Gerenciador | pnpm 10 |
| Instalação | `pnpm install --frozen-lockfile` |
| Build | `pnpm build` |
| Start | `pnpm start` |
| Entry file | `dist/index.js` |
| Output | `dist` |
| Health check inicial | `/`, `/robots.txt` e `/sitemap.xml` |

O procedimento é conectar um repositório GitHub ou enviar um ZIP, revisar os comandos acima, cadastrar as variáveis de ambiente, executar a migração do banco e só então apontar o domínio. A Hostinger informa que aplicações de backend são construídas fora de `public_html` e que o roteamento é criado pela própria plataforma.[1]

### Variáveis obrigatórias

| Variável | Finalidade |
|---|---|
| `DATABASE_URL` | Conexão MySQL/TiDB de produção |
| `JWT_SECRET` | Assinatura da sessão administrativa |
| `CANONICAL_ORIGIN` | Origem pública usada em canonical, sitemap e JSON-LD |
| `VITE_APP_ID`, `OAUTH_SERVER_URL`, `VITE_OAUTH_PORTAL_URL` | Fluxo OAuth do painel |
| `OWNER_OPEN_ID`, `OWNER_NAME` | Identificação do proprietário e autorização administrativa |
| `BUILT_IN_FORGE_API_URL`, `BUILT_IN_FORGE_API_KEY` | Serviços server-side integrados do Manus |
| `VITE_FRONTEND_FORGE_API_URL`, `VITE_FRONTEND_FORGE_API_KEY` | Integrações necessárias no cliente |
| `VITE_APP_TITLE`, `VITE_APP_LOGO` | Identidade configurável da aplicação |

Não versione valores secretos. A documentação da Hostinger orienta manter credenciais em variáveis de ambiente e definir um script de inicialização de produção.[2]

### Bloqueadores de portabilidade

O banco atual, os segredos e os usuários **não são transferidos automaticamente** para a Hostinger. É necessário provisionar um MySQL/TiDB acessível, aplicar o schema e importar os registros. O painel também depende do OAuth do Manus; antes de cortar o DNS, valide que o callback público da Hostinger é aceito. Se a intenção for remover essa dependência, substitua o provedor de autenticação antes da migração.

| Risco | Impacto | Tratamento obrigatório |
|---|---|---|
| Banco vazio | Site sem artigos e categorias | Exportar/importar dados e validar contagens |
| Callback OAuth inválido | Painel inacessível | Testar login administrativo no domínio final |
| `CANONICAL_ORIGIN` ausente | Canonicals do host temporário | Definir a variável antes do primeiro crawl |
| Segredos expostos no Git | Comprometimento da aplicação | Cadastrar somente no hPanel |
| Build sem memória suficiente | Falha de implantação | Consultar logs e ajustar plano ou dependências |

## 6. Checklist de corte

Antes de publicar fora do Manus, confirme: build e testes aprovados; banco migrado; login administrativo funcional; domínio e HTTPS ativos; canonical apontando ao domínio final; robots e sitemap respondendo 200; redirecionamentos afiliados retornando 302; um clique de teste registrado; e páginas principais verificadas em desktop e mobile.

## Referências

[1]: https://www.hostinger.com/support/how-to-deploy-a-nodejs-website-in-hostinger/ "How to add a Node.js Web App in Hostinger"
[2]: https://www.hostinger.com/tutorials/deploy-node-js-application "How to deploy a Node.js application"
