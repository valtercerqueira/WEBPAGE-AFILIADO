ALTER TABLE `articles` ADD `quickSummary` text;--> statement-breakpoint
ALTER TABLE `articles` ADD `quickProsJson` text;--> statement-breakpoint
ALTER TABLE `articles` ADD `quickConsJson` text;--> statement-breakpoint
ALTER TABLE `articles` ADD `quickSummaryModel` varchar(120);--> statement-breakpoint
ALTER TABLE `articles` ADD `quickSummaryGeneratedAt` bigint;