import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { publicationIssues } from "../../shared/articleTemplate";
import { adminProcedure, router } from "../_core/trpc";
import { getAdminArticle, getAdminOverview, getEditorialCategory, listAdminArticles, saveArticle, saveCategory } from "../admin";
import { generateArticleQuickSummary } from "../aiSummary";

const marketplaceUrl = (marketplace: "amazon" | "mercadoLivre") =>
  z.string().url().refine(value => {
    const hostname = new URL(value).hostname.toLowerCase();
    return marketplace === "amazon"
      ? hostname === "amzn.to" || hostname === "amazon.com.br" || hostname.endsWith(".amazon.com.br")
      : hostname === "meli.la" || hostname === "mercadolivre.com.br" || hostname.endsWith(".mercadolivre.com.br");
  }, marketplace === "amazon" ? "Use uma URL válida da Amazon Brasil." : "Use uma URL válida do Mercado Livre Brasil.");

const productSchema = z.object({
  id: z.number().int().positive().optional(),
  name: z.string().min(2).max(220),
  tagline: z.string().min(2).max(280),
  imageUrl: z.string().url().max(1024),
  features: z.array(z.string().min(1).max(180)).max(12),
  estimatedPrice: z.string().regex(/^\d{1,8}(\.\d{1,2})?$/).nullable().optional(),
  priceNote: z.string().min(2).max(180),
  badge: z.string().max(80).nullable().optional(),
  position: z.number().int().min(0).max(100),
  amazonUrl: marketplaceUrl("amazon").nullable().optional(),
  mercadoLivreUrl: marketplaceUrl("mercadoLivre").nullable().optional(),
});

export const articleSchema = z.object({
  id: z.number().int().positive().optional(),
  categoryId: z.number().int().positive(),
  title: z.string().min(8).max(240),
  slug: z.string().min(3).max(255).regex(/^(melhor-)?[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use apenas letras minúsculas, números e hífens; o prefixo melhor- é automático."),
  excerpt: z.string().min(40).max(1000),
  content: z.string().min(80).max(50000),
  coverImageUrl: z.string().url().max(1024),
  authorName: z.string().min(2).max(120),
  status: z.enum(["draft", "published"]),
  isFeatured: z.boolean(),
  seoTitle: z.string().min(10).max(180),
  seoDescription: z.string().min(40).max(320),
  quickSummary: z.string().max(600).nullable().optional(),
  quickPros: z.array(z.string().min(2).max(180)).max(6),
  quickCons: z.array(z.string().min(2).max(180)).max(6),
  quickSummaryModel: z.string().max(120).nullable().optional(),
  quickSummaryGeneratedAt: z.number().int().positive().nullable().optional(),
  products: z.array(productSchema).max(20),
  faqs: z
    .array(
      z.object({
        id: z.number().int().positive().optional(),
        question: z.string().min(8).max(320),
        answer: z.string().min(20).max(4000),
        position: z.number().int().min(0).max(100),
      }),
    )
    .max(20),
});

export const adminRouter = router({
  overview: adminProcedure.query(() => getAdminOverview()),
  articles: adminProcedure.query(() => listAdminArticles()),
  article: adminProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(({ input }) => getAdminArticle(input.id)),
  generateQuickSummary: adminProcedure
    .input(
      z.object({
        title: z.string().min(8).max(240),
        excerpt: z.string().min(40).max(1000),
        content: z.string().min(80).max(50000),
        products: z
          .array(
            z.object({
              name: z.string().min(2).max(220),
              tagline: z.string().min(2).max(280),
              features: z.array(z.string().min(1).max(180)).max(12),
            }),
          )
          .max(20),
      }),
    )
    .mutation(({ input }) => generateArticleQuickSummary(input)),
  saveArticle: adminProcedure.input(articleSchema).mutation(async ({ input }) => {
    if (input.status === "published") {
      const category = await getEditorialCategory(input.categoryId);
      if (!category) throw new TRPCError({ code: "BAD_REQUEST", message: "Publicação bloqueada: categoria editorial inexistente." });
      const issues = publicationIssues({ ...input, categorySlug: category.slug });
      if (issues.length) throw new TRPCError({ code: "BAD_REQUEST", message: `Publicação bloqueada: ${issues.join(" ")}` });
    }
    return saveArticle(input);
  }),
  saveCategory: adminProcedure
    .input(
      z.object({
        id: z.number().int().positive().optional(),
        name: z.string().min(2).max(120),
        slug: z.string().min(2).max(140),
        description: z.string().min(20).max(2000),
        imageUrl: z.string().url().max(1024).nullable().optional(),
        isFeatured: z.boolean(),
        sortOrder: z.number().int().min(0).max(999),
      }),
    )
    .mutation(({ input }) => saveCategory(input)),
});
