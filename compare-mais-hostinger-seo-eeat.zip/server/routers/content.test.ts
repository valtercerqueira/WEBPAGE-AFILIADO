import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("../content", () => ({
  getCategoryPage: vi.fn(),
  getPublishedArticleBySlug: vi.fn(),
  listCategories: vi.fn(),
  listPublishedArticles: vi.fn(),
  searchContent: vi.fn(),
  trackAffiliateClick: vi.fn(),
}));

import {
  getCategoryPage,
  getPublishedArticleBySlug,
  listCategories,
  listPublishedArticles,
  searchContent,
  trackAffiliateClick,
} from "../content";
import { contentRouter } from "./content";

const mocked = {
  getCategoryPage: vi.mocked(getCategoryPage),
  getPublishedArticleBySlug: vi.mocked(getPublishedArticleBySlug),
  listCategories: vi.mocked(listCategories),
  listPublishedArticles: vi.mocked(listPublishedArticles),
  searchContent: vi.mocked(searchContent),
  trackAffiliateClick: vi.mocked(trackAffiliateClick),
};

function createCaller() {
  return contentRouter.createCaller({
    req: { get: vi.fn((name: string) => name === "referer" ? "/melhor-cafeteira" : "Vitest"), ip: "127.0.0.1" },
    res: {},
    user: null,
  } as never);
}

describe("consultas públicas de conteúdo", () => {
  beforeEach(() => vi.clearAllMocks());

  it("compõe a homepage com destaques, recentes e categorias editoriais", async () => {
    mocked.listPublishedArticles
      .mockResolvedValueOnce([{ id: 1, title: "Destaque" }] as never)
      .mockResolvedValueOnce([{ id: 2, title: "Recente" }] as never);
    mocked.listCategories.mockResolvedValue([
      { id: 1, name: "Casa", isFeatured: true },
      { id: 2, name: "Outros", isFeatured: false },
    ] as never);

    const result = await createCaller().home();

    expect(result.featured).toHaveLength(1);
    expect(result.latest).toHaveLength(1);
    expect(result.categories).toEqual([expect.objectContaining({ name: "Casa" })]);
    expect(mocked.listPublishedArticles).toHaveBeenNthCalledWith(1, { featuredOnly: true, limit: 6 });
    expect(mocked.listPublishedArticles).toHaveBeenNthCalledWith(2, { limit: 12 });
  });

  it("encaminha categoria, artigo e busca aos serviços com entradas validadas", async () => {
    mocked.getCategoryPage.mockResolvedValue({ category: { slug: "casa-e-cozinha" }, articles: [] } as never);
    mocked.getPublishedArticleBySlug.mockResolvedValue({ slug: "melhor-cafeteira" } as never);
    mocked.searchContent.mockResolvedValue({ articles: [], products: [] } as never);
    const caller = createCaller();

    await expect(caller.category({ slug: "casa-e-cozinha" })).resolves.toBeTruthy();
    await expect(caller.article({ slug: "cafeteira" })).resolves.toBeTruthy();
    await expect(caller.search({ term: "cafeteira" })).resolves.toBeTruthy();
    expect(mocked.getCategoryPage).toHaveBeenCalledWith("casa-e-cozinha");
    expect(mocked.getPublishedArticleBySlug).toHaveBeenCalledWith("cafeteira");
    expect(mocked.searchContent).toHaveBeenCalledWith("cafeteira");
  });

  it("registra clique com origem e metadados básicos da requisição", async () => {
    mocked.trackAffiliateClick.mockResolvedValue({ url: "https://amzn.to/exemplo" });

    await expect(createCaller().trackClick({
      articleId: 1,
      productId: 2,
      marketplace: "amazon",
      sourcePath: "/melhor-cafeteira",
    })).resolves.toEqual({ url: "https://amzn.to/exemplo" });

    expect(mocked.trackAffiliateClick).toHaveBeenCalledWith(expect.objectContaining({
      articleId: 1,
      productId: 2,
      marketplace: "amazon",
      referrer: "/melhor-cafeteira",
      userAgent: "Vitest",
      ip: "127.0.0.1",
    }));
  });
});
