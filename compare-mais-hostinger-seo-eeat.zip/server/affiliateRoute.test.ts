import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./content", () => ({ trackAffiliateClick: vi.fn() }));

import { trackAffiliateClick } from "./content";
import { registerAffiliateRoute } from "./affiliateRoute";

const mockedTrack = vi.mocked(trackAffiliateClick);

function setupRoute() {
  let handler: (req: any, res: any) => Promise<void> = async () => undefined;
  const app = { get: vi.fn((_path: string, routeHandler: typeof handler) => { handler = routeHandler; }) };
  registerAffiliateRoute(app as never);
  return { app, run: (req: any, res: any) => handler(req, res) };
}

function responseDouble() {
  return {
    status: vi.fn().mockReturnThis(),
    send: vi.fn().mockReturnThis(),
    setHeader: vi.fn(),
    redirect: vi.fn(),
  };
}

describe("redirecionamento afiliado", () => {
  beforeEach(() => vi.clearAllMocks());

  it("registra o clique, desativa cache e responde com HTTP 302", async () => {
    mockedTrack.mockResolvedValue({ url: "https://amzn.to/exemplo" });
    const { app, run } = setupRoute();
    const res = responseDouble();

    await run({
      query: { articleId: "1", productId: "2", marketplace: "amazon", source: "/melhor-cafeteira" },
      get: vi.fn(() => undefined),
      ip: "127.0.0.1",
    }, res);

    expect(app.get).toHaveBeenCalledWith("/api/out", expect.any(Function));
    expect(mockedTrack).toHaveBeenCalledWith(expect.objectContaining({ articleId: 1, productId: 2, marketplace: "amazon" }));
    expect(res.setHeader).toHaveBeenCalledWith("Cache-Control", "no-store");
    expect(res.redirect).toHaveBeenCalledWith(302, "https://amzn.to/exemplo");
  });

  it("rejeita parâmetros inválidos antes de acessar o serviço", async () => {
    const { run } = setupRoute();
    const res = responseDouble();

    await run({ query: { articleId: "0", productId: "x", marketplace: "outro" }, get: vi.fn(), ip: "127.0.0.1" }, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(mockedTrack).not.toHaveBeenCalled();
  });
});
