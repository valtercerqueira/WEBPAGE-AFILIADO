import type { Request, Response } from "express";
import { appRouter } from "../routers";
import { createContext } from "./context";

export async function buildSsrPrefetch(req: Request, res: Response) {
  const ctx = await createContext({ req, res, info: {} as never });
  const caller = appRouter.createCaller(ctx);
  return {
    categories: () => caller.content.categories(),
    home: () => caller.content.home(),
    category: (input: { slug: string }) => caller.content.category(input),
    article: (input: { slug: string }) => caller.content.article(input),
    search: (input: { term: string }) => caller.content.search(input),
  };
}
