import type { Request } from "express";
import superjson from "superjson";
import type { RenderResult } from "../../client/src/entry-server";

const escapeHtml = (value: string) => value
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

const absoluteUrl = (origin: string, value?: string | null) => {
  if (!value) return undefined;
  try { return new URL(value, origin).toString(); } catch { return undefined; }
};

function absolutizeJsonLd(value: unknown, origin: string): unknown {
  if (Array.isArray(value)) return value.map(item => absolutizeJsonLd(item, origin));
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, child]) => {
    if ((key === "item" || key === "mainEntityOfPage") && typeof child === "string") return [key, absoluteUrl(origin, child) ?? child];
    return [key, absolutizeJsonLd(child, origin)];
  }));
}

export function composeSsrHtml(template: string, result: RenderResult, req: Request) {
  const configuredOrigin = process.env.CANONICAL_ORIGIN?.replace(/\/$/, "");
  const requestOrigin = `${req.protocol}://${req.get("host")}`;
  const origin = configuredOrigin || requestOrigin;
  const canonical = absoluteUrl(origin, result.head.canonicalPath);
  const image = absoluteUrl(origin, result.head.ogImage);
  const robots = result.head.noindex || result.head.notFound ? "noindex,nofollow" : "index,follow,max-image-preview:large";
  const tags = [
    `<title>${escapeHtml(result.head.title)}</title>`,
    `<meta name="description" content="${escapeHtml(result.head.description)}">`,
    `<meta name="robots" content="${robots}">`,
    canonical ? `<link rel="canonical" href="${escapeHtml(canonical)}">` : "",
    `<meta property="og:site_name" content="Compare Mais">`,
    `<meta property="og:locale" content="pt_BR">`,
    `<meta property="og:type" content="${result.head.ogType ?? "website"}">`,
    `<meta property="og:title" content="${escapeHtml(result.head.title)}">`,
    `<meta property="og:description" content="${escapeHtml(result.head.description)}">`,
    canonical ? `<meta property="og:url" content="${escapeHtml(canonical)}">` : "",
    image ? `<meta property="og:image" content="${escapeHtml(image)}">` : "",
    image ? `<meta property="og:image:alt" content="${escapeHtml(result.head.title)}">` : "",
    result.head.publishedTime ? `<meta property="article:published_time" content="${escapeHtml(result.head.publishedTime)}">` : "",
    result.head.modifiedTime ? `<meta property="article:modified_time" content="${escapeHtml(result.head.modifiedTime)}">` : "",
    `<meta name="twitter:card" content="summary_large_image">`,
    `<meta name="twitter:title" content="${escapeHtml(result.head.title)}">`,
    `<meta name="twitter:description" content="${escapeHtml(result.head.description)}">`,
    image ? `<meta name="twitter:image" content="${escapeHtml(image)}">` : "",
    ...(result.head.jsonLd ?? []).map(schema => `<script type="application/ld+json">${JSON.stringify(absolutizeJsonLd(schema, origin)).replaceAll("<", "\\u003c")}</script>`),
  ].filter(Boolean).join("\n    ");
  const serialized = JSON.stringify(superjson.serialize(result.dehydratedState)).replaceAll("<", "\\u003c");
  const withState = template.replace("<!--app-head-->", () => tags).replace("<!--app-html-->", () => result.html);
  return withState.replace("</head>", () => `<script>window.__RQ_STATE__=${serialized}</script>\n  </head>`);
}
