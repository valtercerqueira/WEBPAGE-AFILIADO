import { and, asc, desc, eq, like, ne, or } from "drizzle-orm";
import { createHash } from "node:crypto";
import {
  affiliateClicks,
  articles,
  categories,
  faqs,
  products,
} from "../drizzle/schema";
import { getDb } from "./db";

export const ARTICLE_SLUG_PATTERN = /^melhor-[a-z0-9]+(?:-[a-z0-9]+)*$/;
export const RELATED_ARTICLES_LIMIT = 6;

export function prioritizeRelatedArticles<T extends { categoryId: number }>(
  candidates: T[],
  activeCategoryId: number,
) {
  return candidates
    .map((candidate, index) => ({ candidate, index }))
    .sort((left, right) => {
      const leftPriority = left.candidate.categoryId === activeCategoryId ? 0 : 1;
      const rightPriority = right.candidate.categoryId === activeCategoryId ? 0 : 1;
      return leftPriority - rightPriority || left.index - right.index;
    })
    .slice(0, RELATED_ARTICLES_LIMIT)
    .map(({ candidate }) => candidate);
}

export function normalizeArticleSlug(value: string) {
  const normalized = value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

  const withPrefix = normalized.startsWith("melhor-") ? normalized : `melhor-${normalized}`;
  if (!ARTICLE_SLUG_PATTERN.test(withPrefix)) {
    throw new Error("O slug do artigo deve seguir o padrão melhor-{produto}.");
  }
  return withPrefix;
}

function requireDb<T>(db: T | null): asserts db is T {
  if (!db) throw new Error("Banco de dados indisponível.");
}

export async function listCategories() {
  const db = await getDb();
  requireDb(db);
  return db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.name));
}

export async function getSitemapEntries() {
  const db = await getDb();
  requireDb(db);

  const [publishedArticles, editorialCategories] = await Promise.all([
    db
      .select({ slug: articles.slug, updatedAt: articles.updatedAt })
      .from(articles)
      .where(eq(articles.status, "published"))
      .orderBy(desc(articles.updatedAt)),
    db
      .select({ slug: categories.slug, updatedAt: categories.updatedAt })
      .from(categories)
      .orderBy(asc(categories.sortOrder)),
  ]);

  return { articles: publishedArticles, categories: editorialCategories };
}

export async function getCategoryPage(slug: string) {
  const db = await getDb();
  requireDb(db);
  const [category] = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
  if (!category) return null;
  const categoryArticles = await listPublishedArticles({ categorySlug: slug, limit: 60 });
  return { category, articles: categoryArticles };
}

export async function listPublishedArticles(options?: {
  limit?: number;
  featuredOnly?: boolean;
  categorySlug?: string;
}) {
  const db = await getDb();
  requireDb(db);
  const conditions = [eq(articles.status, "published")];
  if (options?.featuredOnly) conditions.push(eq(articles.isFeatured, true));
  if (options?.categorySlug) conditions.push(eq(categories.slug, options.categorySlug));

  return db
    .select({
      id: articles.id,
      title: articles.title,
      slug: articles.slug,
      excerpt: articles.excerpt,
      coverImageUrl: articles.coverImageUrl,
      authorName: articles.authorName,
      publishedAt: articles.publishedAt,
      isFeatured: articles.isFeatured,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(articles)
    .innerJoin(categories, eq(articles.categoryId, categories.id))
    .where(and(...conditions))
    .orderBy(desc(articles.isFeatured), desc(articles.publishedAt), desc(articles.id))
    .limit(Math.min(options?.limit ?? 24, 60));
}

export async function getPublishedArticleBySlug(rawSlug: string) {
  const db = await getDb();
  requireDb(db);
  const slug = normalizeArticleSlug(rawSlug);
  const [article] = await db
    .select({
      id: articles.id,
      categoryId: articles.categoryId,
      title: articles.title,
      slug: articles.slug,
      excerpt: articles.excerpt,
      content: articles.content,
      coverImageUrl: articles.coverImageUrl,
      authorName: articles.authorName,
      seoTitle: articles.seoTitle,
      seoDescription: articles.seoDescription,
      quickSummary: articles.quickSummary,
      quickProsJson: articles.quickProsJson,
      quickConsJson: articles.quickConsJson,
      quickSummaryModel: articles.quickSummaryModel,
      quickSummaryGeneratedAt: articles.quickSummaryGeneratedAt,
      publishedAt: articles.publishedAt,
      updatedAt: articles.updatedAt,
      categoryName: categories.name,
      categorySlug: categories.slug,
    })
    .from(articles)
    .innerJoin(categories, eq(articles.categoryId, categories.id))
    .where(and(eq(articles.slug, slug), eq(articles.status, "published")))
    .limit(1);

  if (!article) return null;

  const [articleProducts, articleFaqs, relatedCandidates] = await Promise.all([
    db.select().from(products).where(eq(products.articleId, article.id)).orderBy(asc(products.position)),
    db.select().from(faqs).where(eq(faqs.articleId, article.id)).orderBy(asc(faqs.position)),
    db
      .select({
        id: articles.id,
        categoryId: articles.categoryId,
        title: articles.title,
        slug: articles.slug,
        excerpt: articles.excerpt,
        coverImageUrl: articles.coverImageUrl,
        categoryName: categories.name,
      })
      .from(articles)
      .innerJoin(categories, eq(articles.categoryId, categories.id))
      .where(and(eq(articles.status, "published"), ne(articles.id, article.id)))
      .orderBy(desc(articles.publishedAt))
      .limit(60),
  ]);

  const related = prioritizeRelatedArticles(relatedCandidates, article.categoryId);

  return {
    ...article,
    quickPros: safeParseFeatures(article.quickProsJson ?? "[]"),
    quickCons: safeParseFeatures(article.quickConsJson ?? "[]"),
    products: articleProducts.map(product => ({
      ...product,
      features: safeParseFeatures(product.featuresJson),
    })),
    faqs: articleFaqs,
    related,
  };
}

function safeParseFeatures(value: string): string[] {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter(item => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export async function searchContent(term: string) {
  const db = await getDb();
  requireDb(db);
  const query = term.trim().slice(0, 100);
  if (query.length < 2) return { articles: [], products: [] };
  const pattern = `%${query}%`;

  const [articleResults, productResults] = await Promise.all([
    db
      .select({
        id: articles.id,
        title: articles.title,
        slug: articles.slug,
        excerpt: articles.excerpt,
        coverImageUrl: articles.coverImageUrl,
        categoryName: categories.name,
      })
      .from(articles)
      .innerJoin(categories, eq(articles.categoryId, categories.id))
      .where(
        and(
          eq(articles.status, "published"),
          or(like(articles.title, pattern), like(articles.excerpt, pattern)),
        ),
      )
      .limit(20),
    db
      .select({
        id: products.id,
        name: products.name,
        tagline: products.tagline,
        imageUrl: products.imageUrl,
        estimatedPrice: products.estimatedPrice,
        articleSlug: articles.slug,
        articleTitle: articles.title,
      })
      .from(products)
      .innerJoin(articles, eq(products.articleId, articles.id))
      .where(and(eq(articles.status, "published"), or(like(products.name, pattern), like(products.tagline, pattern))))
      .limit(20),
  ]);

  return { articles: articleResults, products: productResults };
}

export const MARKETPLACE_HOSTS = {
  amazon: ["amazon.com.br", "www.amazon.com.br", "amzn.to"],
  mercado_livre: ["mercadolivre.com.br", "www.mercadolivre.com.br", "mercadolivre.com", "www.mercadolivre.com"],
} as const;

export function validateAffiliateDestination(target: string, marketplace: keyof typeof MARKETPLACE_HOSTS) {
  const url = new URL(target);
  if (url.protocol !== "https:" || !MARKETPLACE_HOSTS[marketplace].includes(url.hostname as never)) {
    throw new Error("Destino de afiliado inválido.");
  }
  return url;
}

export async function trackAffiliateClick(input: {
  articleId: number;
  productId: number;
  marketplace: "amazon" | "mercado_livre";
  sourcePath?: string;
  referrer?: string;
  userAgent?: string;
  ip?: string;
}) {
  const db = await getDb();
  requireDb(db);
  const [row] = await db
    .select({
      articleId: articles.id,
      productId: products.id,
      amazonUrl: products.amazonUrl,
      mercadoLivreUrl: products.mercadoLivreUrl,
    })
    .from(products)
    .innerJoin(articles, eq(products.articleId, articles.id))
    .where(
      and(
        eq(products.id, input.productId),
        eq(articles.id, input.articleId),
        eq(articles.status, "published"),
      ),
    )
    .limit(1);

  if (!row) throw new Error("Produto ou artigo não encontrado.");
  const target = input.marketplace === "amazon" ? row.amazonUrl : row.mercadoLivreUrl;
  if (!target) throw new Error("Link de afiliado indisponível.");
  const url = validateAffiliateDestination(target, input.marketplace);

  const ipHash = input.ip
    ? createHash("sha256").update(`${process.env.JWT_SECRET ?? "compare-mais"}:${input.ip}`).digest("hex")
    : null;

  await db.insert(affiliateClicks).values({
    articleId: input.articleId,
    productId: input.productId,
    marketplace: input.marketplace,
    sourcePath: input.sourcePath?.slice(0, 512),
    referrer: input.referrer?.slice(0, 2000),
    userAgent: input.userAgent?.slice(0, 2000),
    ipHash,
    clickedAt: Date.now(),
  });

  return { url: url.toString() };
}
