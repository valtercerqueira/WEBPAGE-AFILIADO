import { afterEach, describe, expect, it, vi } from "vitest";
import { diagnoseDatabaseConnection } from "./dbDiagnostics";
import { systemRouter } from "./_core/systemRouter";

vi.mock("./dbDiagnostics", () => ({
  diagnoseDatabaseConnection: vi.fn(),
}));

const originalToken = process.env.DB_DIAGNOSTIC_TOKEN;

afterEach(() => {
  vi.clearAllMocks();
  if (originalToken === undefined) delete process.env.DB_DIAGNOSTIC_TOKEN;
  else process.env.DB_DIAGNOSTIC_TOKEN = originalToken;
});

const context = {
  req: {} as never,
  res: {} as never,
  user: null,
};

describe("system.databaseHealth", () => {
  it("nega token inválido sem executar a conexão", async () => {
    process.env.DB_DIAGNOSTIC_TOKEN = "token-correto-com-mais-de-trinta-e-dois-caracteres";
    const caller = systemRouter.createCaller(context);

    await expect(
      caller.databaseHealth({ token: "token-incorreto-com-mais-de-trinta-e-dois-caracteres" }),
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(diagnoseDatabaseConnection).not.toHaveBeenCalled();
  });

  it("retorna somente o diagnóstico sanitizado com token válido", async () => {
    const token = "token-seguro-com-mais-de-trinta-e-dois-caracteres";
    process.env.DB_DIAGNOSTIC_TOKEN = token;
    vi.mocked(diagnoseDatabaseConnection).mockResolvedValue({
      enabled: true,
      configured: true,
      ok: false,
      category: "access_denied",
      code: "ER_ACCESS_DENIED_ERROR",
      errno: 1045,
      sqlState: "28000",
    });
    const caller = systemRouter.createCaller(context);

    const result = await caller.databaseHealth({ token });
    const serialized = JSON.stringify(result);

    expect(result).toEqual({
      enabled: true,
      configured: true,
      ok: false,
      category: "access_denied",
      code: "ER_ACCESS_DENIED_ERROR",
      errno: 1045,
      sqlState: "28000",
    });
    expect(serialized).not.toContain("message");
    expect(serialized).not.toContain("mysql://");
    expect(serialized).not.toContain(token);
  });
});
