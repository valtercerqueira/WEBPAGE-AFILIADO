import type { Express, Request } from "express";
import { getSitemapEntries } from "./content";

function getOrigin(req: Request) {
  const forwardedProtocol = req.headers["x-forwarded-proto"];
  const protocol = typeof forwardedProtocol === "string" ? forwardedProtocol.split(",")[0] : req.protocol;
  return `${protocol}://${req.get("host")}`;
}

function escapeXml(value: string) {
  return value.replace(/[<>&'\"]/g, character => ({
    "<": "&lt;",
    ">": "&gt;",
    "&": "&amp;",
    "'": "&apos;",
    '"': "&quot;",
  })[character] ?? character);
}

export function registerSeoRoutes(app: Express) {
  app.get("/robots.txt", (req, res) => {
    const origin = getOrigin(req);
    res.type("text/plain").send([
      "User-agent: *",
      "Allow: /",
      "Disallow: /admin",
      "Disallow: /busca",
      `Sitemap: ${origin}/sitemap.xml`,
      "",
    ].join("\n"));
  });

  app.get("/sitemap.xml", async (req, res, next) => {
    try {
      const origin = getOrigin(req);
      const entries = await getSitemapEntries();
      const urls = [
        { path: "/", lastmod: new Date() },
        ...entries.categories.map(category => ({ path: `/categoria/${category.slug}`, lastmod: category.updatedAt })),
        ...entries.articles.map(article => ({ path: `/${article.slug}`, lastmod: article.updatedAt })),
      ];
      const xml = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
        ...urls.map(entry => [
          "  <url>",
          `    <loc>${escapeXml(`${origin}${entry.path}`)}</loc>`,
          `    <lastmod>${new Date(entry.lastmod).toISOString()}</lastmod>`,
          "  </url>",
        ].join("\n")),
        "</urlset>",
      ].join("\n");
      res.type("application/xml").send(xml);
    } catch (error) {
      next(error);
    }
  });
}
