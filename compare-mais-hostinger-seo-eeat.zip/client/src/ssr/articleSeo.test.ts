import { describe, expect, it } from "vitest";
import { articleSchemas } from "./prefetch";

const article = {
  id: 1,
  slug: "melhor-cafeteira",
  title: "Melhor cafeteira",
  excerpt: "Comparativo editorial de cafeteiras.",
  content: "Melhor cafeteira depende da rotina.",
  coverImageUrl: "https://cdn.example.com/cafeteira.jpg",
  authorName: "Valter",
  categoryName: "Casa e Cozinha",
  categorySlug: "casa-e-cozinha",
  publishedAt: new Date("2026-07-01T00:00:00Z"),
  updatedAt: new Date("2026-07-16T00:00:00Z"),
  seoDescription: "Compare cafeteiras por método, capacidade, manutenção, custo recorrente e praticidade antes de decidir qual modelo atende melhor à sua rotina.",
  products: [
    { id: 1, name: "Cafeteira A", tagline: "Compacta", imageUrl: "https://cdn.example.com/a.jpg", features: ["Cápsulas"], estimatedPrice: "499.90", amazonUrl: "https://amazon.com.br/dp/A", mercadoLivreUrl: null },
    { id: 2, name: "Cafeteira B", tagline: "Versátil", imageUrl: "https://cdn.example.com/b.jpg", features: ["Espresso"], estimatedPrice: null, amazonUrl: null, mercadoLivreUrl: "https://produto.mercadolivre.com.br/B" },
  ],
  faqs: [],
} as any;

describe("articleSchemas", () => {
  it("gera um único @graph honesto, sem Review ou rating fabricado", () => {
    const schemas = articleSchemas(article);
    const serialized = JSON.stringify(schemas);

    expect(schemas).toHaveLength(1);
    expect(schemas[0]).toMatchObject({ "@context": "https://schema.org" });
    expect(schemas[0]["@graph"].map((item: any) => item["@type"])).toEqual(["Article", "BreadcrumbList", "ItemList", "FAQPage"]);
    expect(serialized).not.toContain('"Review"');
    expect(serialized).not.toContain("ratingValue");
    expect(serialized).not.toContain("reviewCount");
    expect(serialized).not.toContain('"Brand"');
    expect((schemas[0]["@graph"][3] as any).mainEntity.length).toBeGreaterThanOrEqual(5);
  });
});
