import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { QuickSummary } from "@/components/site/QuickSummary";

describe("QuickSummary SSR", () => {
  it("inclui a síntese, os prós, os contras e a hierarquia acessível no HTML inicial", () => {
    const html = renderToStaticMarkup(
      createElement(QuickSummary, {
        summary: "Síntese útil para decidir rapidamente qual perfil de produto merece análise detalhada.",
        pros: ["Fácil manutenção", "Critérios claros"],
        cons: ["Exige confirmar o preço"],
      }),
    );

    expect(html).toContain("Resumo rápido");
    expect(html).toContain("Principais prós");
    expect(html).toContain("Pontos de atenção");
    expect(html).toContain("aria-labelledby=\"quick-summary-title\"");
    expect(html).toContain("Fácil manutenção");
  });
});
