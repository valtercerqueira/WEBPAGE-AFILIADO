import { BookOpenCheck, Database, Scale, ShieldCheck } from "lucide-react";

export default function Methodology() {
  return <main className="container py-16 lg:py-24"><span className="eyebrow">Transparência editorial</span><h1 className="mt-5 max-w-4xl font-display text-5xl tracking-[-.05em] lg:text-7xl">Como o Compare Mais analisa produtos</h1><p className="mt-6 max-w-3xl text-lg leading-8 text-[var(--muted)]">Nossa curadoria organiza especificações públicas, fontes regulatórias aplicáveis, manuais e adequação a diferentes perfis de uso. Quando não existe teste físico próprio, declaramos isso de forma explícita.</p><div className="mt-12 grid gap-6 md:grid-cols-2">{[
    [Database, "Coleta", "Consultamos páginas e manuais de fabricantes, fontes públicas aplicáveis e informações disponíveis nos marketplaces."],
    [Scale, "Comparação", "Organizamos critérios relevantes ao uso, limites, manutenção e custo. Preço e estoque devem ser confirmados na loja."],
    [BookOpenCheck, "Revisão", "Separamos fatos publicados, inferências editoriais e lacunas de dados. Não transformamos ausência de informação em certeza."],
    [ShieldCheck, "Afiliados", "Links podem gerar comissão sem custo adicional. A remuneração não autoriza notas, avaliações ou testes inventados."],
  ].map(([Icon, title, text]) => <section key={String(title)} className="rounded-[2rem] bg-white p-7 shadow-[0_20px_60px_rgba(20,45,43,.07)]"><Icon className="size-7 text-[var(--petrol)]" /><h2 className="mt-5 font-display text-3xl">{String(title)}</h2><p className="mt-3 leading-7 text-[var(--muted)]">{String(text)}</p></section>)}</div></main>;
}
