import { AlertCircle } from "lucide-react";
import { useParams } from "wouter";
import { ArticleCard } from "@/components/site/ArticleCard";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { trpc } from "@/lib/trpc";

export default function Category() {
  const { slug } = useParams<{ slug: string }>();
  const { data, isLoading } = trpc.content.category.useQuery({ slug });
  if (isLoading) return <div className="container py-24"><div className="h-96 animate-pulse rounded-[2rem] bg-black/5" /></div>;
  if (!data) return <div className="container py-28 text-center"><AlertCircle className="mx-auto size-9" /><h1 className="mt-5 font-display text-4xl">Categoria não encontrada</h1></div>;
  return <><header className="relative overflow-hidden bg-[var(--petrol)] py-20 text-white lg:py-28"><div className="pointer-events-none absolute -right-32 -top-56 size-[520px] rounded-full bg-[var(--sage)]/30 blur-3xl" /><div className="container relative"><Breadcrumbs items={[{ label: data.category.name }]} /><span className="mt-12 block text-[10px] font-bold uppercase tracking-[.2em] text-[var(--gold)]">Guias por categoria</span><h1 className="mt-4 max-w-3xl font-display text-[clamp(3.5rem,8vw,7rem)] leading-[.92] tracking-[-.055em]">{data.category.name}</h1><p className="mt-6 max-w-2xl text-base leading-8 text-white/65">{data.category.description}</p></div></header><section className="container py-20"><div className="mb-9 flex items-end justify-between"><div><span className="eyebrow">Biblioteca editorial</span><h2 className="mt-3 font-display text-4xl">{data.articles.length} {data.articles.length === 1 ? "análise publicada" : "análises publicadas"}</h2></div></div>{data.articles.length ? <div className="grid gap-7 md:grid-cols-2 lg:grid-cols-3">{data.articles.map(article => <ArticleCard key={article.id} article={article} />)}</div> : <div className="rounded-[2rem] bg-white p-12 text-center text-[var(--muted)]">Novos guias desta categoria estão em preparação.</div>}</section></>;
}
