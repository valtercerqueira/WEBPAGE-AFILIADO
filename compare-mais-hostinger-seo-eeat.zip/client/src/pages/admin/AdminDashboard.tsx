import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { ArrowUpRight, FileText, MousePointerClick, Package, Plus } from "lucide-react";
import { useLocation } from "wouter";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const overview = trpc.admin.overview.useQuery(undefined, { enabled: user?.role === "admin" });
  const articles = trpc.admin.articles.useQuery(undefined, { enabled: user?.role === "admin" });

  if (user && user.role !== "admin") {
    return (
      <DashboardLayout>
        <div className="mx-auto max-w-2xl py-20 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary">Acesso restrito</p>
          <h1 className="mt-4 font-display text-4xl font-semibold text-foreground">Esta conta não possui permissão editorial.</h1>
          <p className="mt-4 text-muted-foreground">Solicite ao proprietário do projeto a promoção da conta para o perfil administrador.</p>
        </div>
      </DashboardLayout>
    );
  }

  const metrics = [
    { label: "Artigos", value: overview.data?.articleCount, icon: FileText },
    { label: "Produtos", value: overview.data?.productCount, icon: Package },
    { label: "Cliques afiliados", value: overview.data?.clickCount, icon: MousePointerClick },
  ];

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-7xl space-y-8 p-2 md:p-6">
        <header className="flex flex-col justify-between gap-5 border-b border-border/70 pb-7 md:flex-row md:items-end">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary">Operação editorial</p>
            <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">Painel Compare Mais</h1>
            <p className="mt-2 text-muted-foreground">Gerencie conteúdo, produtos, links afiliados e acompanhe os cliques registrados.</p>
          </div>
          <Button size="lg" onClick={() => navigate("/admin/artigo/novo")} className="gap-2">
            <Plus className="size-4" /> Novo artigo
          </Button>
        </header>

        <section className="grid gap-4 md:grid-cols-3">
          {metrics.map(metric => (
            <Card key={metric.label} className="border-border/70 shadow-sm">
              <CardContent className="flex items-center justify-between p-6">
                <div>
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                  {overview.isLoading ? <Skeleton className="mt-3 h-9 w-20" /> : <p className="mt-2 font-display text-4xl font-semibold">{metric.value ?? 0}</p>}
                </div>
                <div className="grid size-12 place-items-center rounded-full bg-primary/10 text-primary"><metric.icon className="size-5" /></div>
              </CardContent>
            </Card>
          ))}
        </section>

        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.5fr)_minmax(320px,.7fr)]">
          <Card className="border-border/70 shadow-sm">
            <CardHeader className="flex-row items-center justify-between">
              <div>
                <CardTitle className="font-display text-2xl">Artigos</CardTitle>
                <p className="mt-1 text-sm text-muted-foreground">Conteúdo publicado e em preparação.</p>
              </div>
            </CardHeader>
            <CardContent>
              {articles.isLoading ? (
                <div className="space-y-3">{[1, 2, 3].map(item => <Skeleton key={item} className="h-16 w-full" />)}</div>
              ) : (
                <div className="divide-y divide-border/70">
                  {articles.data?.map(article => (
                    <button key={article.id} onClick={() => navigate(`/admin/artigo/${article.id}`)} className="flex w-full items-center justify-between gap-4 py-4 text-left transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                      <div className="min-w-0">
                        <p className="truncate font-medium text-foreground">{article.title}</p>
                        <p className="mt-1 text-xs text-muted-foreground">{article.categoryName} · /{article.slug}</p>
                      </div>
                      <div className="flex shrink-0 items-center gap-3">
                        <Badge variant={article.status === "published" ? "default" : "secondary"}>{article.status === "published" ? "Publicado" : "Rascunho"}</Badge>
                        <ArrowUpRight className="size-4" />
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/70 shadow-sm">
            <CardHeader><CardTitle className="font-display text-2xl">Cliques recentes</CardTitle></CardHeader>
            <CardContent>
              {!overview.data?.recentClicks.length ? (
                <p className="rounded-xl bg-muted/60 p-5 text-sm text-muted-foreground">Os primeiros cliques aparecerão aqui quando visitantes usarem os CTAs dos produtos.</p>
              ) : (
                <div className="space-y-4">
                  {overview.data.recentClicks.map(click => (
                    <div key={click.id} className="border-b border-border/70 pb-4 last:border-0">
                      <div className="flex items-center justify-between gap-3">
                        <p className="truncate text-sm font-medium">{click.productName}</p>
                        <Badge variant="outline">{click.marketplace === "amazon" ? "Amazon" : "Mercado Livre"}</Badge>
                      </div>
                      <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{click.articleTitle}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
