import { Search as SearchIcon } from "lucide-react";
import { FormEvent, useState } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { trpc } from "@/lib/trpc";

export default function SearchPage() {
  const queryString = useSearch();
  const initialQuery = new URLSearchParams(queryString).get("q") ?? "";
  const [term, setTerm] = useState(initialQuery);
  const [, navigate] = useLocation();
  const { data, isLoading } = trpc.content.search.useQuery({ term: initialQuery }, { enabled: initialQuery.trim().length >= 2 });
  const results = [
    ...(data?.articles.map(article => ({ kind: "article" as const, id: article.id, articleSlug: article.slug, imageUrl: article.coverImageUrl, categoryName: article.categoryName, title: article.title, description: article.excerpt })) ?? []),
    ...(data?.products.map(product => ({ kind: "product" as const, id: product.id, articleSlug: product.articleSlug, imageUrl: product.imageUrl, categoryName: "Produto encontrado", title: product.name, description: product.articleTitle })) ?? []),
  ];
  function submit(event: FormEvent) { event.preventDefault(); if (term.trim().length >= 2) navigate(`/busca?q=${encodeURIComponent(term.trim())}`); }
  return <div className="container py-14 lg:py-20"><Breadcrumbs items={[{ label: "Busca" }]} /><div className="mx-auto mt-12 max-w-3xl text-center"><span className="eyebrow">Pesquisa interna</span><h1 className="mt-4 font-display text-5xl tracking-[-.05em] md:text-6xl">Encontre a análise certa</h1><form onSubmit={submit} className="mt-8 flex items-center rounded-full bg-white p-2 shadow-[0_18px_60px_rgba(20,45,43,.1)]"><SearchIcon className="ml-4 size-5 text-[var(--muted)]" /><input value={term} onChange={event => setTerm(event.target.value)} className="min-w-0 flex-1 bg-transparent px-3 py-3 outline-none" placeholder="Produto, categoria ou característica" /><button className="rounded-full bg-[var(--petrol)] px-6 py-3 text-sm font-bold text-white">Buscar</button></form></div><div className="mx-auto mt-14 max-w-4xl">{initialQuery.length >= 2 && <p className="mb-6 text-sm font-semibold text-[var(--muted)]">{isLoading ? "Buscando…" : `${results.length} resultado(s) para “${initialQuery}”`}</p>}<div className="grid gap-4">{results.map(result => <Link key={`${result.kind}-${result.id}`} href={`/${result.articleSlug}`} className="group grid gap-5 rounded-[1.5rem] bg-white p-4 shadow-[0_12px_40px_rgba(20,45,43,.06)] sm:grid-cols-[140px_1fr]"><img src={result.imageUrl} alt="" className="aspect-[4/3] w-full rounded-[1rem] object-cover" /><div className="self-center py-2"><span className="eyebrow">{result.categoryName}</span><h2 className="mt-2 font-display text-2xl tracking-[-.03em] group-hover:text-[var(--petrol)]">{result.title}</h2><p className="mt-2 line-clamp-2 text-sm leading-6 text-[var(--muted)]">{result.description}</p></div></Link>)}</div>{!isLoading && initialQuery.length >= 2 && results.length === 0 && <div className="rounded-[2rem] bg-white p-12 text-center text-[var(--muted)]">Nenhum conteúdo encontrado. Tente um termo mais amplo.</div>}</div></div>;
}
