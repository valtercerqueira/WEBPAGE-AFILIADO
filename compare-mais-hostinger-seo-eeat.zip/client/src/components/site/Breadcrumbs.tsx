import { ChevronRight, Home } from "lucide-react";
import { Link } from "wouter";

export function Breadcrumbs({ items }: { items: Array<{ label: string; href?: string }> }) {
  return <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-2 text-xs font-semibold text-[var(--muted)]"><Link href="/" aria-label="Início"><Home className="size-3.5" /></Link>{items.map((item, index) => <span key={`${item.label}-${index}`} className="flex items-center gap-2"><ChevronRight className="size-3" />{item.href ? <Link href={item.href} className="hover:text-[var(--petrol)]">{item.label}</Link> : <span aria-current="page">{item.label}</span>}</span>)}</nav>;
}
