# Rastreabilidade do modelo SEO/E-E-A-T

Este documento liga os requisitos do `template-pagina-produto-seo-eeat.md` à implementação verificável do Compare Mais. O objetivo é impedir que uma exigência editorial fique apenas na interface sem correspondente em dados, SSR ou testes.

| Requisito | Dados e regras | Interface | SSR e dados estruturados | Validação |
|---|---|---|---|---|
| Breadcrumb, H1, autoria, datas e tempo de leitura | `TemplateArticle`, `resolveAuthor()` e datas reais do artigo | `Article.tsx` | `prefetch.ts` e `ssrHtml.ts` | `articleTemplate.test.ts`, screenshots desktop/mobile |
| Destaques e sumário com âncoras | `parseEditorialContent()` e `slugifyAnchor()` | `Article.tsx` | Conteúdo renderizado no HTML inicial | `articleTemplate.test.ts` |
| Metodologia honesta e disclaimer | `methodologyText()` proíbe alegação de teste físico | `Article.tsx` e `/metodologia` | Texto presente no SSR | `articleTemplate.test.ts` |
| Comparativo rápido e critérios | `buildSelectionCriteria()` e preços estimados | `Article.tsx` | Conteúdo rastreável no HTML | Testes do template e validação visual |
| Cards técnicos, prós, contras e CTAs | Campos de produto, `productLimitations()` e `directMarketplaceUrl()` | `ProductCard.tsx` | Produtos no SSR e no `ItemList` | Testes do template e afiliados |
| Seções educativas | `parseEditorialContent()` | `Article.tsx` | HTML inicial | `articleTemplate.test.ts` |
| FAQ com 5–8 perguntas | `expandedFaqs()` e `publicationIssues()` | Accordion em `Article.tsx` | `FAQPage` no `@graph` | Testes do template e SSR |
| Fontes identificadas | `authoritySources()` e `hasVerifiableAuthoritySource()` | Bloco de fontes em `Article.tsx` | Links presentes no HTML | Publicação bloqueada sem URL HTTPS oficial |
| Biografia verificável | `resolveAuthor()` | `Article.tsx` e `/autor/valter` | Autor no `Article` JSON-LD | Testes do template e rota pública |
| Até seis relacionados reais | `prioritizeRelatedArticles()` prioriza categoria e aplica fallback | Grade em `Article.tsx` | Links internos no HTML | `content.related.test.ts` e screenshot |
| JSON-LD sem avaliações fabricadas | Dados reais do artigo, produtos e FAQs | Não aplicável | Um `@graph`: `Article`, `BreadcrumbList`, `ItemList`/`Product`, `FAQPage` | `prefetch.test.ts` e inspeção SSR sem `Review`/rating |
| Keyword, title, meta e canonical | `articleTopic()`, `articleSeoTitle()`, `articleSeoDescription()` e `keywordFirstParagraph()` | H1 e primeiro parágrafo | Meta tags e canonical absoluto | Testes do template e `curl` do HTML SSR |
| Bloqueios editoriais | `publicationIssues()` | Erro explícito no painel | Publicação não é persistida | `articleTemplate.test.ts` e testes do admin |

> **Regra central:** o site descreve análise documental; não inventa testes físicos, notas, avaliações, depoimentos ou métricas de desempenho.
