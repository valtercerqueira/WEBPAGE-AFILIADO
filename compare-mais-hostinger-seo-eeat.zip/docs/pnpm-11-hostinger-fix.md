# Correção de implantação Hostinger — pnpm 11

Em 16 de julho de 2026, a primeira implantação por ZIP falhou antes do build porque o `package.json` exigia `pnpm@10.18.0`, enquanto o ambiente da Hostinger executava pnpm `11.13.1` por meio do Corepack.

A correção aplicada foi alinhar `packageManager` para `pnpm@11.13.1` e substituir `onlyBuiltDependencies`, removido no pnpm 11, pelo mapa `allowBuilds` em `pnpm-workspace.yaml`. Foram autorizados apenas `@tailwindcss/oxide` e `esbuild`, dependências necessárias ao build.

## Referências oficiais

- [pnpm 11.0 — release e breaking changes](https://pnpm.io/blog/releases/11.0)
- [pnpm settings](https://pnpm.io/settings)
- [pnpm approve-builds](https://pnpm.io/cli/approve-builds)
- [Hostinger — detalhes do banco MySQL](https://www.hostinger.com/support/1583552-how-to-find-your-mysql-database-details-in-hostinger/)
- [Hostinger — porta MySQL](https://www.hostinger.com/support/1583223-what-mysql-port-is-used-at-hostinger/)
- [Hostinger — conexão MySQL em aplicação Node.js](https://www.hostinger.com/support/connecting-a-hostinger-mysql-database-to-a-node-js-application/)
